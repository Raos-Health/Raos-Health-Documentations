
import React, { useState, useEffect, createContext, useContext, useRef } from 'react';
import { HashRouter, Routes, Route, Navigate, Link, useLocation, useNavigate } from 'react-router-dom';
import { supabase } from './supabase';
import { Profile, UserRole } from './types';
import { 
  Users, Calendar, UserCircle, LogOut, CreditCard, 
  Settings, Search, Bell, Inbox, Zap, HeartPulse, PieChart as ChartIcon,
  Activity, ShieldAlert, Smartphone, BarChart3, Tag, DollarSign, Timer,
  Command, ChevronRight, PlusCircle, ArrowRightCircle, FilePlus, Sparkles, FileText, Layers, LayoutGrid, TrendingUp, Target
} from 'lucide-react';

// --- Views ---
import ExecutiveDashboard from './views/ExecutiveDashboard';
import Patients from './views/Patients';
import Appointments from './views/Appointments';
import AppointmentControlCenter from './views/AppointmentControlCenter';
import Billing from './views/Billing';
import AuditLogs from './views/AuditLogs';
import UserManagement from './views/UserManagement';
import ClinicalNotes from './views/ClinicalNotes';
import SettingsView from './views/Settings';
import StaffInbox from './views/StaffInbox';
import NoShowDashboard from './views/NoShowDashboard';
import ClinicalFlow from './views/ClinicalFlow';
import LeakageDetector from './views/LeakageDetector';
import MobileMode from './views/MobileMode';
import PricingEngine from './views/PricingEngine';
import CollectionAccelerator from './views/CollectionAccelerator';
import WaitingAnalytics from './views/WaitingAnalytics';
import ClinicalTemplates from './views/ClinicalTemplates';
import ROIAnalytics from './views/ROIAnalytics';
import RAOSDashboard from './views/RAOSDashboard';

export const AuthContext = createContext({ user: null, profile: null, loading: true, signOut: async () => {} });

const SidebarItem = ({ to, icon: Icon, label, active, badge }: { to: string, icon: any, label: string, active: boolean, badge?: number }) => (
  <Link 
    to={to} 
    className={`flex items-center justify-between px-5 py-3.5 rounded-xl transition-all duration-200 group ${
      active ? 'sidebar-item-active text-white shadow-inner' : 'text-slate-300 hover:bg-white/5 hover:text-white'
    }`}
  >
    <div className="flex items-center gap-4">
      <Icon size={20} className={active ? 'text-[#E4C19D]' : 'text-slate-400 group-hover:text-[#E4C19D] transition-colors'} />
      <span className="font-semibold text-sm tracking-wide">{label}</span>
    </div>
    {badge && badge > 0 && (
      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${active ? 'bg-[#E4C19D] text-[#07363c]' : 'bg-rose-500 text-white'}`}>
        {badge}
      </span>
    )}
  </Link>
);

const CommandItem = ({ icon: Icon, label, shortcut, onClick, danger, sub }: any) => (
  <button 
    onClick={onClick}
    className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-slate-50 transition-all group text-left border border-transparent hover:border-slate-100"
  >
    <div className="flex items-center gap-4">
      <div className={`p-2 rounded-xl ${danger ? 'bg-rose-50 text-rose-500' : 'bg-slate-100 text-[#07363c] group-hover:bg-[#07363c] group-hover:text-white transition-colors'}`}>
        <Icon size={18} />
      </div>
      <div>
        <span className={`font-bold text-sm block ${danger ? 'text-rose-600' : 'text-[#07363c]'}`}>{label}</span>
        {sub && <span className="text-[10px] font-medium text-slate-400 uppercase tracking-widest">{sub}</span>}
      </div>
    </div>
    {shortcut && <kbd className="px-2 py-1 bg-slate-100 border border-slate-200 rounded text-[10px] font-black text-slate-400">{shortcut}</kbd>}
  </button>
);

const Sidebar = ({ role }: { role: UserRole }) => {
  const location = useLocation();
  const path = location.pathname;

  return (
    <aside className="w-72 bg-[#07363c] flex flex-col h-screen fixed left-0 top-0 z-40 print:hidden border-r border-white/5 shadow-2xl">
      <div className="p-8 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="bg-[#E4C19D] p-2 rounded-xl shadow-lg">
            <HeartPulse className="text-[#07363c]" size={24} />
          </div>
          <div className="flex flex-col">
            <span className="text-white font-black text-xl leading-none">STH<span className="text-[#E4C19D]">Pro</span></span>
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.2em] mt-1">Solutions That Heal</span>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-5 space-y-1.5 overflow-y-auto custom-scrollbar">
        <SidebarItem to="/" icon={BarChart3} label="Executive Paneli" active={path === '/'} />
        <SidebarItem to="/raos" icon={Target} label="RAOS No-Show" active={path === '/raos'} />
        <SidebarItem to="/inbox" icon={Inbox} label="Görev Kutusu" active={path === '/inbox'} badge={7} />
        
        <div className="py-4 px-5 text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Klinik Operasyon</div>
        <SidebarItem to="/randevu-kontrol" icon={LayoutGrid} label="Kontrol Merkezi" active={path === '/randevu-kontrol'} />
        <SidebarItem to="/muayene" icon={FileText} label="Muayene Notu" active={path === '/muayene'} />
        <SidebarItem to="/akistakip" icon={Activity} label="Klinik Akış Ölçer" active={path === '/akistakip'} />
        <SidebarItem to="/hastalar" icon={Users} label="Hasta 360" active={path.startsWith('/hastalar')} />
        <SidebarItem to="/randevular" icon={Calendar} label="Randevular" active={path.startsWith('/randevular')} />
        
        <div className="py-4 px-5 text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Yönetim & Mali</div>
        <SidebarItem to="/fiyatlandirma" icon={Tag} label="Fiyat & Paket Motoru" active={path === '/fiyatlandirma'} />
        <SidebarItem to="/tahsilat" icon={DollarSign} label="Tahsilat Hızlandırıcı" active={path === '/tahsilat'} />
        <SidebarItem to="/noshow-analiz" icon={ChartIcon} label="No-Show Analiz" active={path === '/noshow-analiz'} />
        <SidebarItem to="/sizinti" icon={ShieldAlert} label="Gelir Sızıntısı" active={path === '/sizinti'} />
        <SidebarItem to="/roi" icon={TrendingUp} label="ROI Raporu" active={path === '/roi'} />

        {(role === UserRole.SUPER_ADMIN || role === UserRole.ADMIN) && (
          <>
            <div className="py-4 px-5 text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Sistem</div>
            <SidebarItem to="/kullanicilar" icon={UserCircle} label="Personel" active={path.startsWith('/kullanicilar')} />
            <SidebarItem to="/ayarlar" icon={Settings} label="Ayarlar" active={path.startsWith('/ayarlar')} />
          </>
        )}
      </nav>
      
      <div className="p-6 bg-black/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#E4C19D] flex items-center justify-center font-black text-[#07363c]">AD</div>
          <div className="flex-1 min-w-0 text-white">
            <p className="text-xs font-bold truncate">Dr. Ahmet Demir</p>
            <p className="text-[10px] opacity-60 uppercase font-black tracking-tighter">Süper Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default function App() {
  const [profile, setProfile] = useState({ id: 'demo', full_name: 'Dr. Ahmet Demir', role: UserRole.SUPER_ADMIN, email: 'ahmet@solutionsheal.com' });
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [commandSearch, setCommandSearch] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
      if (e.key === 'Escape') {
        setIsSearchOpen(false);
        setCommandSearch('');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleCommand = (route: string) => {
    window.location.hash = route;
    setIsSearchOpen(false);
    setCommandSearch('');
  };

  const filteredCommands = [
    { icon: Target, label: "RAOS No-Show Yönetimi", sub: "Kapasite Koruma", route: "/raos", key: "r" },
    { icon: LayoutGrid, label: "Randevu Kontrol Merkezi", sub: "Hızlı Yönetim", route: "/randevu-kontrol", key: "k" },
    { icon: FileText, label: "Muayene Notu Yaz", sub: "Hızlı Giriş", route: "/muayene", key: "m" },
    { icon: Users, label: "Hasta Ara: Mehmet...", sub: "Veri Merkezi", route: "/hastalar", key: "h" },
    { icon: DollarSign, label: "Tahsilat Al", sub: "Finans", route: "/tahsilat", key: "t" },
  ].filter(c => c.label.toLowerCase().includes(commandSearch.toLowerCase()));

  return (
    <AuthContext.Provider value={{ user: {id: 'demo'}, profile, loading: false, signOut: async () => {} }}>
      <HashRouter>
        <Sidebar role={profile.role} />
        <div className="flex flex-col flex-1 min-h-screen">
          <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-30 flex items-center justify-between px-10 ml-72 print:hidden">
            <div className="flex-1 max-w-xl">
              <div 
                className="relative group cursor-pointer" 
                onClick={() => setIsSearchOpen(true)}
              >
                <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-hover:text-[#07363c] transition-colors" />
                <div className="w-full pl-12 pr-4 py-2.5 bg-slate-100 rounded-xl border-2 border-transparent group-hover:border-slate-200 text-slate-400 text-sm font-medium flex items-center justify-between transition-all">
                  <span>Süper Erişim (Kısayol: ⌘K)...</span>
                  <div className="flex items-center gap-1">
                    <kbd className="px-2 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-black text-slate-400">⌘</kbd>
                    <kbd className="px-2 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-black text-slate-400">K</kbd>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 bg-emerald-50 px-4 py-2 rounded-xl text-emerald-700 border border-emerald-100">
                <Sparkles size={16} className="text-emerald-500" />
                <span className="text-[10px] font-black uppercase tracking-widest">Klinik Kalite Aktif</span>
              </div>
              <button className="p-2.5 bg-slate-100 text-slate-500 rounded-xl hover:text-[#07363c] transition-colors relative">
                <Bell size={20} />
                <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
              </button>
              <button className="p-2.5 bg-slate-100 text-slate-500 rounded-xl hover:text-rose-600 transition-colors">
                <LogOut size={20} />
              </button>
            </div>
          </header>
          
          <main className="ml-72 p-10 min-h-[calc(100vh-80px)]">
            <Routes>
              <Route path="/" element={<ExecutiveDashboard />} />
              <Route path="/raos" element={<RAOSDashboard />} />
              <Route path="/roi" element={<ROIAnalytics />} />
              <Route path="/inbox" element={<StaffInbox />} />
              <Route path="/hastalar" element={<Patients />} />
              <Route path="/randevular" element={<Appointments />} />
              <Route path="/randevu-kontrol" element={<AppointmentControlCenter />} />
              <Route path="/muayene" element={<ClinicalNotes />} />
              <Route path="/sablonlar" element={<ClinicalTemplates />} />
              <Route path="/fiyatlandirma" element={<PricingEngine />} />
              <Route path="/tahsilat" element={<CollectionAccelerator />} />
              <Route path="/bekleme-analizi" element={<WaitingAnalytics />} />
              <Route path="/noshow-analiz" element={<NoShowDashboard />} />
              <Route path="/akistakip" element={<ClinicalFlow />} />
              <Route path="/sizinti" element={<LeakageDetector />} />
              <Route path="/faturalama" element={<Billing />} />
              <Route path="/denetim" element={<AuditLogs />} />
              <Route path="/kullanicilar" element={<UserManagement />} />
              <Route path="/ayarlar" element={<SettingsView />} />
              <Route path="/mobile" element={<MobileMode />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
        </div>

        {/* Command Palette */}
        {isSearchOpen && (
          <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xl flex items-start justify-center pt-[10vh] p-4 animate-in fade-in duration-300" onClick={() => { setIsSearchOpen(false); setCommandSearch(''); }}>
            <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden border border-white/20" onClick={e => e.stopPropagation()}>
              <div className="p-8 border-b border-slate-100 flex items-center gap-4 bg-slate-50/50">
                <Command className="text-[#07363c] opacity-40" size={28} />
                <input 
                  autoFocus
                  ref={searchInputRef}
                  placeholder="Hızlı komut yazın..." 
                  className="flex-1 bg-transparent border-none outline-none text-2xl font-black text-[#07363c]"
                  value={commandSearch}
                  onChange={(e) => setCommandSearch(e.target.value)}
                />
              </div>
              <div className="p-4 max-h-[60vh] overflow-y-auto">
                 {filteredCommands.map((cmd) => (
                   <CommandItem key={cmd.route} icon={cmd.icon} label={cmd.label} sub={cmd.sub} shortcut={cmd.key.toUpperCase()} onClick={() => handleCommand(cmd.route)} />
                 ))}
              </div>
            </div>
          </div>
        )}
      </HashRouter>
    </AuthContext.Provider>
  );
}
