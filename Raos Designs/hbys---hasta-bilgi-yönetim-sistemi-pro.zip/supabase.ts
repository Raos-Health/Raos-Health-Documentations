
import { createClient } from '@supabase/supabase-js';
import { Appointment, NoShowRiskScore, TaskType, AppointmentStatus } from './types';

const supabaseUrl = 'https://urhfnvjwmprhytdzsgsv.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVyaGZudmp3bXByaHl0ZHpzZ3N2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc1NjI4MDYsImV4cCI6MjA4MzEzODgwNn0.Te16tNs3-NCahTtG_sc9l1BQjaceDaQTuzIuQQwPD7w';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * No-Show Risk Skorlama Motoru (Heuristic tabanlı)
 */
export function calculateRiskScore(appointment: Partial<Appointment>, patientHistory: any): NoShowRiskScore {
  let score = 10; // Baz puan
  const reasons: { code: string; label: string; weight: number }[] = [];

  // 1. Geçmiş No-Show Kontrolü
  if (patientHistory?.no_show_count > 0) {
    const weight = patientHistory.no_show_count * 25;
    score += weight;
    reasons.push({ code: 'PAST_NOSHOW', label: `Geçmişte ${patientHistory.no_show_count} kez gelmedi`, weight });
  }

  // 2. Randevu Zamanı Analizi (Çok erken veya çok geç saatler)
  const hour = new Date(appointment.appointment_date!).getHours();
  if (hour < 9 || hour > 17) {
    score += 15;
    reasons.push({ code: 'TIME_EXTREME', label: 'Randevu mesai dışı/kenar saatte', weight: 15 });
  }

  // 3. Randevu Oluşturma Süresi (Çok ileri tarihli randevular unutulma riski taşır)
  const daysDiff = Math.floor((new Date(appointment.appointment_date!).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
  if (daysDiff > 14) {
    score += 10;
    reasons.push({ code: 'LEAD_TIME_HIGH', label: 'Randevu çok ileri tarihli (>14 gün)', weight: 10 });
  }

  // 4. Onay Durumu (Simülasyon: Henüz onaylanmamışsa yüksek risk)
  if (appointment.status === AppointmentStatus.CONFIRM_PENDING) {
    score += 20;
    reasons.push({ code: 'UNCONFIRMED', label: 'Henüz onay verilmedi', weight: 20 });
  }

  score = Math.min(score, 100);
  
  return {
    score,
    tier: score > 60 ? 'Yüksek' : score > 30 ? 'Orta' : 'Düşük',
    reasons
  };
}

/**
 * Akıllı Slot Bulucu (Top 3 Öneri)
 */
export async function findSmartSlots(doctorId: string, preferredDate?: string) {
  // Simüle edilmiş verimli slot bulma mantığı
  return [
    { time: '09:30', date: 'Yarın', type: 'Düşük Yoğunluk', success_rate: '%98' },
    { time: '14:15', date: 'Yarın', type: 'Doktor Tercihi', success_rate: '%95' },
    { time: '11:00', date: 'Cuma', type: 'En Popüler', success_rate: '%92' }
  ];
}

/**
 * Görev Oluşturma
 */
export async function createNoShowTask(type: TaskType, appointmentId: string, priority: string = 'Normal') {
  const { data: authData } = await supabase.auth.getUser();
  const userId = authData?.user?.id || 'demo-user-id';

  return supabase.from('tasks').insert({
    type,
    appointment_id: appointmentId,
    status: 'Açık',
    priority,
    due_at: new Date(Date.now() + 15 * 60000).toISOString(), // 15 dk içinde
    created_at: new Date().toISOString()
  });
}

export async function logAuditEvent(action: string, entityType: string, entityId: string, details: any) {
  const { data: authData } = await supabase.auth.getUser();
  const userId = authData?.user?.id || 'demo-user-id';
  
  return supabase.from('audit_logs').insert({
    actor_id: userId,
    actor_role: 'ADMIN',
    action,
    entity_type: entityType,
    entity_id: entityId,
    details,
    timestamp: new Date().toISOString()
  });
}
