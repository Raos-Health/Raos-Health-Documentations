
export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ADMIN = 'YÖNETİCİ',
  DOCTOR = 'DOKTOR',
  NURSE = 'HEMŞİRE',
  REGISTRAR = 'KAYIT GÖREVLİSİ',
  ACCOUNTANT = 'MUHASEBE',
  READ_ONLY = 'OKUMA'
}

export enum AppointmentStatus {
  SCHEDULED = 'Planlandı',
  CONFIRM_PENDING = 'Onay Bekliyor',
  CONFIRMED = 'Onaylandı',
  WAITING = 'Bekliyor',
  IN_ROOM = 'Muayenede',
  ARRIVED = 'Geldi',
  NO_SHOW = 'Gelmedi',
  CANCELLED = 'İptal',
  COMPLETED = 'Tamamlandı',
  GAP = 'BOŞLUK'
}

export enum ConfirmationStatus {
  PENDING = 'Beklemede',
  CONFIRMED = 'Onaylandı',
  REJECTED = 'Reddedildi',
  UNREACHABLE = 'Ulaşılamadı'
}

export interface RAOSConfirmation {
  id: string;
  appointment_id: string;
  status: ConfirmationStatus;
  t24_sent_at?: string;
  t6_sent_at?: string;
  t1_sent_at?: string;
}

export interface WaitlistEntry {
  id: string;
  patient_id: string;
  department_id?: string;
  doctor_id?: string;
  is_active: boolean;
}

/**
 * Task types for clinical operations
 */
export enum TaskType {
  CONFIRM_CALL = 'ONAY ARAMASI',
  NO_SHOW_RECOVERY = 'NO-SHOW GERİ KAZANIM',
  DELAY_MANAGEMENT = 'GECİKME YÖNETİMİ',
  PAYMENT_FOLLOWUP = 'ÖDEME TAKİBİ',
  LEAKAGE_FIX = 'SIZINTI GİDERME',
  WAITLIST_REFILL = 'BOŞLUK DOLDURMA'
}

export enum PatientRiskFlag {
  NO_SHOW_HIGH = 'Yüksek No-Show Riski',
  PAYMENT_OVERDUE = 'Gecikmiş Ödeme',
  VIP = 'VIP'
}

export enum PipelineStage {
  SCHEDULED = 'Randevu Alındı',
  ARRIVED = 'Klinikte',
  IN_EXAM = 'Muayenede',
  PENDING_PROCEDURE = 'İşlem Bekliyor',
  COMPLETED = 'Tamamlandı'
}

export enum OfferStatus {
  SENT = 'GÖNDERİLDİ',
  VIEWED = 'GÖRÜLDÜ',
  ACCEPTED = 'ONAYLANDI',
  REJECTED = 'REDDEDİLDİ'
}

export interface Patient {
  id: string;
  tc_no: string;
  first_name: string;
  last_name: string;
  phone: string;
  risk_score?: number;
  pipeline_stage?: PipelineStage;
  flags?: PatientRiskFlag[];
}

export interface Profile {
  id: string;
  full_name: string;
  role: UserRole;
  email: string;
  is_active: boolean;
}

export interface Department {
  id: string;
  name: string;
}

export interface NoShowRiskScore {
  score: number;
  tier: 'Düşük' | 'Orta' | 'Yüksek';
  reasons: { code: string; label: string; weight: number }[];
}

export interface Appointment {
  id: string;
  patient_id: string;
  doctor_id: string;
  department_id: string;
  appointment_date: string;
  duration_minutes: number;
  status: AppointmentStatus;
  patient?: Patient;
  doctor?: Profile;
  department?: Department;
  arrived_at?: string;
  started_at?: string;
  completed_at?: string;
  risk_data?: NoShowRiskScore;
  payment_status?: string;
  last_message_at?: string;
  risk_score?: number;
  risk_reasons?: string[];
  raos_confirmation?: RAOSConfirmation;
}

export interface Task {
  id: string;
  type: TaskType;
  priority: string;
  status: string;
  due_at: string;
  created_at: string;
  appointment_id: string;
  appointment?: Appointment;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor_id: string;
  actor_role: string;
  action: string;
  entity_type: string;
  entity_id: string;
  details: any;
}

export interface Invoice {
  id: string;
  patient_id: string;
  total_amount: number;
  status: string;
  created_at: string;
  patient?: Patient;
}

export interface ClinicalTemplateField {
  id: string;
  label: string;
  type: 'checkbox' | 'select' | 'textarea';
  required: boolean;
  options?: string[];
}

export interface ClinicalNextStep {
  type: 'control' | 'billing' | 'instruction';
  label: string;
}

export interface ClinicalTemplate {
  id: string;
  name: string;
  branch: string;
  fields: ClinicalTemplateField[];
  next_steps: ClinicalNextStep[];
}

export interface ClinicalNote {
  id: string;
  appointment_id: string;
  patient_id: string;
  doctor_id: string;
  template_id?: string;
  form_data: any;
  complaint: string;
  diagnosis: string;
  created_at: string;
  patient?: Patient;
}

export interface LeakageEvent {
  id: string;
  rule_code: string;
  title: string;
  description: string;
  patient: string;
  amount: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'DETECTED' | 'RESOLVED';
}

export interface Service {
  id: string;
  name: string;
  price: number;
  kdv_rate: number;
  duration_mins: number;
  category: string;
}

export interface Package {
  id: string;
  name: string;
  services: string[];
  total_price: number;
  discounted_price: number;
  description: string;
}

export interface Offer {
  id: string;
  patient_id: string;
  doctor_id: string;
  total_amount: number;
  discount_amount: number;
  final_amount: number;
  status: OfferStatus;
  created_at: string;
  expires_at: string;
  patient?: Patient;
}

export interface ROIDailyAggregate {
  id: string;
  day_date: string;
  scope_type: 'Genel' | 'Departman' | 'Doktor';
  scope_id?: string;
  total_appointments: number;
  confirmed_t24: number;
  arrived: number;
  no_show: number;
  canceled: number;
  slots_filled_from_waitlist: number;
  tasks_closed: number;
  avg_task_close_minutes: number;
  estimated_value_saved: number; // Önlenen No-Show TL
  estimated_revenue_gained: number; // Dolan boşluk TL
}

export interface ROIValueConfig {
  avg_value_per_appointment: number;
  avg_value_per_filled_slot: number;
  avg_value_per_no_show_prevented: number;
  staff_minute_value: number;
  currency: string;
}

export interface ROIInsight {
  id: string;
  insight_code: string;
  title: string;
  body: string;
  severity: 'Bilgi' | 'Uyarı' | 'Önemli';
}
