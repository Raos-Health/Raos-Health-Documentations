
import React, { useState } from 'react';
import { 
  CheckCircle, Clock, Send, MessageSquare, AlertCircle, 
  MapPin, X, Trash2, Calendar, PhoneCall, Zap, Share2
} from 'lucide-react';
import { ConfirmationStatus } from '../types';

interface Props {
  appointment: any;
  onUpdate: () => void;
}

export default function NoShowActionPanel({ appointment, onUpdate }: Props) {
  const [loading, setLoading] = useState(false);

  const sendMessage = (type: string) => {
    setLoading(true);
    setTimeout(() => {
      alert(`${type} mesajı hastaya iletildi.`);
      setLoading(false);
      onUpdate();
    }, 1000);
  };

  const steps = [
    { label: 'T-24 Hatırlatıcı', status: appointment.raos_confirmation?.t24_sent_at ? 'SENT' : 'PENDING' },
    { label: 'T-6 İnteraktif Onay', status: appointment.raos_confirmation?.status === 'Onaylandı' ? 'CONFIRMED' : 'PENDING' },
    { label: 'T-1 Konum Hatırlatıcı', status: appointment.raos_confirmation?.t1_sent_at ? 'SENT' : 'PENDING' },
  ];

  return (
    <div className="bg-white rounded-[40px] border border-slate-200 shadow-sm overflow-hidden">
       <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
             <div className="p-3 bg-[#E4C19D]/20 text-[#07363c] rounded-2xl"><Zap size={24} fill="currentColor" /></div>
             <h3 className="text-xl font-black text-[#07363c] tracking-tight">RAOS — No-Show Kontrolü</h3>
          </div>
          <span className={`px-4 py-1.5 rounded-2xl text-[10px] font-black uppercase tracking-widest border ${
            appointment.raos_confirmation?.status === 'Onaylandı' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'
          }`}>
            {appointment.raos_confirmation?.status || 'Onay Bekliyor'}
          </span>
       </div>

       <div className="p-8 space-y-10">
          {/* Timeline View */}
          <div className="relative">
             <div className="absolute top-5 left-1 w-full h-0.5 bg-slate-100"></div>
             <div className="relative z-10 flex justify-between">
                {steps.map((step, i) => (
                  <div key={i} className="flex flex-col items-center gap-3 group">
                     <div className={`w-10 h-10 rounded-full border-4 flex items-center justify-center transition-all ${
                       step.status === 'CONFIRMED' ? 'bg-emerald-600 border-emerald-100 text-white' :
                       step.status === 'SENT' ? 'bg-indigo-600 border-indigo-100 text-white' :
                       'bg-white border-slate-100 text-slate-300'
                     }`}>
                        {step.status === 'CONFIRMED' ? <CheckCircle size={18}/> : <Clock size={18}/>}
                     </div>
                     <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 group-hover:text-[#07363c] transition-colors">{step.label}</span>
                  </div>
                ))}
             </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <button 
              onClick={() => sendMessage('T-24 Onay')}
              className="flex items-center justify-center gap-3 p-5 bg-[#07363c] text-white rounded-[24px] font-black uppercase text-xs tracking-widest hover:scale-[1.02] transition-all shadow-xl shadow-[#07363c]/10"
             >
                <MessageSquare size={18} /> T-24 Gönder
             </button>
             <button 
              onClick={() => sendMessage('Konum')}
              className="flex items-center justify-center gap-3 p-5 bg-white border-2 border-slate-100 text-slate-600 rounded-[24px] font-black uppercase text-xs tracking-widest hover:border-[#E4C19D] transition-all"
             >
                <MapPin size={18} /> Konum At
             </button>
             <button 
              onClick={() => sendMessage('Özel İptal Linki')}
              className="flex items-center justify-center gap-3 p-5 bg-rose-50 text-rose-600 rounded-[24px] font-black uppercase text-xs tracking-widest hover:bg-rose-100 transition-all border border-rose-100"
             >
                <Trash2 size={18} /> İptal Linki
             </button>
             <button 
              onClick={() => alert("Arama listesine eklendi.")}
              className="flex items-center justify-center gap-3 p-5 bg-emerald-50 text-emerald-600 rounded-[24px] font-black uppercase text-xs tracking-widest hover:bg-emerald-100 transition-all border border-emerald-100"
             >
                <PhoneCall size={18} /> Manuel Ara
             </button>
          </div>

          <div className="bg-slate-50 p-6 rounded-[32px] space-y-4">
             <div className="flex items-center justify-between">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Mesaj Geçmişi</h4>
                <Share2 size={14} className="text-slate-300" />
             </div>
             <div className="space-y-3">
                <div className="flex items-start gap-3">
                   <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5"></div>
                   <div className="flex-1">
                      <p className="text-xs font-bold text-[#07363c]">T-24 Hatırlatıcı Okundu</p>
                      <p className="text-[9px] font-medium text-slate-400 uppercase">2 SAAT ÖNCE • WHATSAPP</p>
                   </div>
                </div>
                <div className="flex items-start gap-3">
                   <div className="w-2 h-2 rounded-full bg-slate-300 mt-1.5"></div>
                   <div className="flex-1">
                      <p className="text-xs font-bold text-slate-400">T-6 Onay Mesajı Gönderildi</p>
                      <p className="text-[9px] font-medium text-slate-400 uppercase">10 DAKİKA ÖNCE • SMS</p>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </div>
  );
}
