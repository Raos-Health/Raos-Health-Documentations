
import React, { useState } from 'react';
import { supabase } from '../supabase';
import { HeartPulse, Lock, Mail, AlertCircle, ArrowRight } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      setError('Hatalı e-posta veya şifre. Lütfen tekrar deneyiniz.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex overflow-hidden bg-white">
      {/* Left Side: Branding */}
      <div className="hidden lg:flex w-1/2 bg-[#07363c] p-16 flex-col justify-between relative overflow-hidden">
        {/* Background Patterns */}
        <div className="absolute inset-0 opacity-5">
           <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
             <defs>
               <pattern id="sth-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                 <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1"/>
               </pattern>
             </defs>
             <rect width="100%" height="100%" fill="url(#sth-grid)" />
           </svg>
        </div>
        
        <div className="flex items-center gap-4 text-white font-black text-3xl z-10">
          <div className="bg-[#E4C19D] p-3 rounded-3xl shadow-2xl">
            <HeartPulse className="text-[#07363c]" size={32} />
          </div>
          <div className="flex flex-col">
            <span className="tracking-tighter">Solutions That Heal</span>
            <span className="text-xs font-black text-[#E4C19D] uppercase tracking-[0.5em]">HBYS PRO SİSTEMİ</span>
          </div>
        </div>

        <div className="z-10 max-w-lg">
          <h1 className="text-5xl font-black text-white mb-8 leading-[1.1] tracking-tight">
            Şifa Veren Teknolojilerle <span className="text-[#E4C19D]">Sağlıkta Dönüşüm.</span>
          </h1>
          <p className="text-slate-300 text-xl leading-relaxed font-medium">
            Hasta odaklı yaklaşım, akıllı veri analitiği ve kusursuz operasyon yönetimi için STH Pro yanınızda.
          </p>
          
          <div className="mt-12 flex gap-6">
             <div className="bg-white/5 border border-white/10 p-6 rounded-[32px] backdrop-blur-xl">
               <p className="text-3xl font-black text-white">100%</p>
               <p className="text-[10px] font-black text-[#E4C19D] uppercase tracking-widest mt-1">Veri Güvenliği</p>
             </div>
             <div className="bg-white/5 border border-white/10 p-6 rounded-[32px] backdrop-blur-xl">
               <p className="text-3xl font-black text-white">2.4k</p>
               <p className="text-[10px] font-black text-[#E4C19D] uppercase tracking-widest mt-1">Akıllı Tanı</p>
             </div>
          </div>
        </div>

        <div className="z-10 text-slate-400 text-xs font-black uppercase tracking-[0.3em]">
          © 2024 SOLUTIONS THAT HEAL - TÜM HAKLARI SAKLIDIR
        </div>
      </div>

      {/* Right Side: Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-12 bg-slate-50/50">
        <div className="w-full max-w-md space-y-10 animate-in slide-in-from-right-12 duration-1000">
          <div className="text-center">
             <h2 className="text-4xl font-black text-[#07363c] mb-4">Panele Giriş</h2>
             <p className="text-slate-500 font-medium">STH Pro ekosistemine hoş geldiniz.</p>
          </div>

          <div className="bg-white p-12 rounded-[48px] shadow-2xl shadow-slate-200 border border-slate-100">
            {error && (
              <div className="mb-8 bg-rose-50 border border-rose-100 text-rose-600 p-5 rounded-3xl flex items-start gap-4 text-sm font-bold animate-shake">
                <AlertCircle className="shrink-0" size={20} />
                <p>{error}</p>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Kurumsal E-posta</label>
                <div className="relative group">
                  <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#07363c] transition-colors" size={22} />
                  <input 
                    type="email" 
                    required 
                    placeholder="isim@solutionsheal.com"
                    className="w-full pl-14 pr-6 py-5 rounded-[24px] border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-[#07363c]/5 focus:border-[#07363c] outline-none transition-all font-bold"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center px-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Güvenli Şifre</label>
                  <button type="button" className="text-[10px] font-black text-[#07363c] hover:underline uppercase tracking-widest">Şifremi Unuttum</button>
                </div>
                <div className="relative group">
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#07363c] transition-colors" size={22} />
                  <input 
                    type="password" 
                    required 
                    placeholder="••••••••"
                    className="w-full pl-14 pr-6 py-5 rounded-[24px] border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-[#07363c]/5 focus:border-[#07363c] outline-none transition-all font-bold"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-[#07363c] text-white py-6 rounded-[28px] font-black text-lg hover:bg-slate-900 transition-all flex items-center justify-center gap-3 group disabled:opacity-70 shadow-2xl shadow-[#07363c]/20"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    Sisteme Giriş Yap
                    <ArrowRight className="group-hover:translate-x-1 transition-transform" size={24} />
                  </>
                )}
              </button>
            </form>

            <div className="mt-12 text-center">
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
                Erişim sorunu yaşıyorsanız <br/>
                <button className="text-[#07363c] hover:underline">Bilgi İşlem Merkezi</button> ile görüşün.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
