
import React from 'react';
import { 
  Users, TrendingUp, Clock, ArrowUpRight, ArrowDownRight, Zap, Activity, Timer, Heart
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';

const StatCard = ({ title, value, sub, icon: Icon, color, trend, alert }: any) => (
  <div className={`bg-white p-6 rounded-3xl border-2 ${alert ? 'border-rose-400 bg-rose-50/10' : 'border-slate-100'} shadow-sm hover:shadow-xl transition-all group card-hover`}>
    <div className="flex justify-between items-start mb-6">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-20 text-slate-700`}>
        <Icon size={24} className="text-[#07363c]" />
      </div>
      {trend && (
        <span className={`flex items-center gap-1 text-[10px] font-black px-2 py-1 rounded-full ${trend > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'} uppercase tracking-widest`}>
          {trend > 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {Math.abs(trend)}%
        </span>
      )}
    </div>
    <h3 className="text-slate-500 text-[10px] font-black uppercase tracking-[0.1em] mb-1">{title}</h3>
    <div className="flex items-baseline gap-2">
      <span className="text-3xl font-black text-[#07363c] tracking-tight">{value}</span>
      <span className="text-xs text-slate-500 font-bold uppercase">{sub}</span>
    </div>
  </div>
);

export default function Dashboard() {
  const chartData = [
    { name: 'Pzt', randevular: 45, gelir: 8500 },
    { name: 'Sal', randevular: 52, gelir: 9200 },
    { name: 'Çar', randevular: 38, gelir: 7100 },
    { name: 'Per', randevular: 65, gelir: 12000 },
    { name: 'Cum', randevular: 48, gelir: 8900 },
    { name: 'Cmt', randevular: 24, gelir: 4500 },
    { name: 'Paz', randevular: 12, gelir: 2200 },
  ];

  const pieData = [
    { name: 'Planlandı', value: 40, color: '#07363c' },
    { name: 'Tamamlandı', value: 35, color: '#E4C19D' },
    { name: 'Gelmedi', value: 15, color: '#94a3b8' },
    { name: 'İptal', value: 10, color: '#cbd5e1' },
  ];

  const handleExport = () => alert("Excel raporu hazırlanıyor ve otomatik indirilecek.");

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-[#07363c] tracking-tight">Kurumsal Performans Paneli</h1>
          <p className="text-slate-500 font-medium">STH Pro: Şifa Odaklı Akıllı Veri Yönetimi</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={handleExport} className="px-6 py-3 bg-[#07363c] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg shadow-[#07363c]/20 hover:scale-105 transition-all">Excel Raporu</button>
          <button className="px-6 py-3 bg-white text-[#07363c] border-2 border-slate-200 rounded-2xl text-xs font-black uppercase tracking-widest hover:border-[#07363c] transition-all">Haftalık</button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Kayıtlı Hasta" value="1.420" sub="Aktif" icon={Users} color="bg-indigo-50" trend={12} />
        <StatCard title="Bekleme Süresi" value="14dk" sub="Ortalama" icon={Timer} color="bg-amber-50" trend={-8} />
        <StatCard title="Sızıntı Tespiti" value="4.250 ₺" sub="Risk Altında" icon={Zap} color="bg-rose-50" alert={true} />
        <StatCard title="Hasta Sadakati" value="%94" sub="Puan" icon={Heart} color="bg-emerald-50" trend={2} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-[32px] border-2 border-slate-100 shadow-sm">
          <h3 className="text-xl font-black text-[#07363c] mb-8">Randevu & Hasta Akışı</h3>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="sthColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#07363c" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#07363c" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b', fontWeight: 700}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b', fontWeight: 700}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="randevular" stroke="#07363c" strokeWidth={4} fillOpacity={1} fill="url(#sthColor)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border-2 border-slate-100 shadow-sm flex flex-col items-center">
          <h3 className="text-xl font-black text-[#07363c] mb-8 w-full">Randevu Durumu</h3>
          <div className="h-[250px] w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} innerRadius={70} outerRadius={90} paddingAngle={8} dataKey="value">
                  {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-2xl font-black text-[#07363c]">%85</span>
              <span className="text-[10px] font-black text-slate-500 uppercase">Verimlilik</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 mt-8 w-full">
            {pieData.map((item) => (
              <div key={item.name} className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-500 uppercase leading-none">{item.name}</span>
                  <span className="text-sm font-black text-[#07363c]">%{item.value}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
