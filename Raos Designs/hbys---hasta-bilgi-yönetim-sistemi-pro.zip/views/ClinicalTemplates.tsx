
import React, { useState } from 'react';
import { 
  FileText, Plus, Search, Layers, Briefcase, 
  Settings, CheckCircle, Trash2, Edit2, ChevronRight,
  ShieldCheck, Zap, Sparkles
} from 'lucide-react';

export default function ClinicalTemplates() {
  const [templates] = useState([
    { id: '1', name: 'Genel Muayene', branch: 'Dahiliye', fields: 8, usage: 1240 },
    { id: '2', name: 'Post-Op Takip', branch: 'Genel Cerrahi', fields: 12, usage: 450 },
    { id: '3', name: 'Kardiyolojik Kontrol', branch: 'Kardiyoloji', fields: 6, usage: 890 },
    { id: '4', name: 'Acil Müdahale', branch: 'Acil Servis', fields: 15, usage: 2100 }
  ]);

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Şablon & Standart Yönetimi</h1>
          <p className="text-slate-500 font-medium">Klinik dokümantasyon kalitesini merkezden yönetin.</p>
        </div>
        <button className="flex items-center gap-2 bg-[#07363c] text-white px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-[#07363c]/20 hover:-translate-y-1 transition-all">
          <Plus size={18} /> Yeni Şablon Tasarla
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm flex items-center justify-between group">
           <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Aktif Şablonlar</p>
              <p className="text-3xl font-black text-[#07363c]">{templates.length}</p>
           </div>
           <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl group-hover:rotate-12 transition-transform"><Layers size={24} /></div>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm flex items-center justify-between group">
           <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Kullanım Oranı</p>
              <p className="text-3xl font-black text-[#07363c]">%92</p>
           </div>
           <div className="p-4 bg-emerald-50 text-emerald-600 rounded-2xl group-hover:rotate-12 transition-transform"><CheckCircle size={24} /></div>
        </div>
        <div className="bg-[#07363c] p-8 rounded-[40px] text-white flex items-center justify-between relative overflow-hidden group">
           <Sparkles className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10" />
           <div className="relative z-10">
              <p className="text-white/40 text-[10px] font-black uppercase tracking-widest mb-1">Standardizasyon Skoru</p>
              <p className="text-3xl font-black">4.8/5.0</p>
           </div>
           <ShieldCheck size={40} className="text-[#E4C19D] relative z-10" />
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between px-4">
           <h3 className="text-2xl font-black text-[#07363c]">Prosedür Kütüphanesi</h3>
           <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#07363c]" size={16} />
              <input className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none" placeholder="Branş veya Şablon Ara..." />
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {templates.map(t => (
             <div key={t.id} className="bg-white p-8 rounded-[40px] border-2 border-slate-100 hover:border-[#07363c] transition-all group cursor-pointer shadow-sm hover:shadow-2xl">
                <div className="flex justify-between items-start mb-6">
                   <div className="flex items-center gap-4">
                      <div className="p-4 bg-slate-50 rounded-2xl group-hover:bg-[#07363c] group-hover:text-white transition-all">
                        <FileText size={24} />
                      </div>
                      <div>
                         <h4 className="text-xl font-black text-[#07363c]">{t.name}</h4>
                         <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.branch}</p>
                      </div>
                   </div>
                   <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 text-slate-400 hover:text-indigo-600"><Edit2 size={18}/></button>
                      <button className="p-2 text-slate-400 hover:text-rose-600"><Trash2 size={18}/></button>
                   </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 border-t border-slate-50 pt-6">
                   <div className="text-center">
                      <p className="text-[9px] font-black text-slate-400 uppercase">Alan Sayısı</p>
                      <p className="text-lg font-black text-[#07363c]">{t.fields}</p>
                   </div>
                   <div className="text-center border-x border-slate-50">
                      <p className="text-[9px] font-black text-slate-400 uppercase">Aylık Kullanım</p>
                      <p className="text-lg font-black text-[#07363c]">{t.usage}</p>
                   </div>
                   <div className="flex items-center justify-center">
                      <button className="p-2 bg-slate-100 rounded-full text-slate-400 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-all">
                         <ChevronRight size={20} />
                      </button>
                   </div>
                </div>
             </div>
           ))}
        </div>
      </div>

      <div className="bg-[#E4C19D]/10 p-10 rounded-[48px] border border-[#E4C19D]/30 flex flex-col md:flex-row items-center gap-10">
         <div className="w-24 h-24 bg-[#E4C19D] rounded-[32px] flex items-center justify-center text-[#07363c] shadow-2xl">
            <Zap size={48} fill="currentColor" />
         </div>
         <div className="flex-1 space-y-2">
            <h4 className="text-2xl font-black text-[#07363c]">Akıllı Öneri Motoru</h4>
            <p className="text-slate-600 font-medium leading-relaxed">Şablonlarınızdaki boş alanları analiz ederek doktorlara en uygun tanı kodlarını ve tetkikleri saniyeler içinde önerebilirsiniz.</p>
         </div>
         <button className="px-10 py-5 bg-[#07363c] text-white rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-105 transition-all">Motoru Yapılandır</button>
      </div>
    </div>
  );
}
