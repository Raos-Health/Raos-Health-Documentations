
import React from 'react';
import { 
  Users, Calendar, CheckCircle, Search, 
  Smartphone, MessageSquare, Plus, Bell
} from 'lucide-react';

export default function MobileMode() {
  return (
    <div className="max-w-md mx-auto space-y-8 animate-in slide-in-from-bottom-12 duration-500">
      <div className="bg-[#07363c] p-8 rounded-[40px] text-white shadow-2xl">
         <div className="flex justify-between items-start mb-8">
            <Smartphone className="text-[#E4C19D]" size={32} />
            <Bell size={24} className="opacity-40" />
         </div>
         <h1 className="text-3xl font-black tracking-tighter">Hızlı Mod</h1>
         <p className="text-white/60 font-medium">Personel Hızlı Erişim Paneli</p>
      </div>

      <div className="grid grid-cols-2 gap-4 px-2">
         <button className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm flex flex-col items-center gap-4 group active:scale-95 transition-all">
            <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center"><Calendar size={28}/></div>
            <span className="text-xs font-black uppercase tracking-widest text-[#07363c]">Randevular</span>
         </button>
         <button className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm flex flex-col items-center gap-4 group active:scale-95 transition-all">
            <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center"><Users size={28}/></div>
            <span className="text-xs font-black uppercase tracking-widest text-[#07363c]">Hasta Bul</span>
         </button>
         <button className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm flex flex-col items-center gap-4 group active:scale-95 transition-all col-span-2">
            <div className="w-14 h-14 bg-[#E4C19D]/20 text-[#07363c] rounded-2xl flex items-center justify-center"><MessageSquare size={28}/></div>
            <span className="text-xs font-black uppercase tracking-widest text-[#07363c]">Hızlı Onay Gönder</span>
         </button>
      </div>

      <div className="px-4 space-y-4 pb-12">
         <h2 className="text-sm font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Bekleyen 3 Görev</h2>
         {[1, 2, 3].map(i => (
           <div key={i} className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-4">
              <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center font-black text-xs text-[#07363c]">PA</div>
              <div className="flex-1">
                 <p className="font-bold text-sm text-[#07363c]">Pınar Aydın</p>
                 <p className="text-[10px] font-black text-slate-400">Yarın 10:30 • Onay Araması</p>
              </div>
              <button className="p-3 bg-emerald-600 text-white rounded-2xl shadow-lg shadow-emerald-600/20"><CheckCircle size={20}/></button>
           </div>
         ))}
      </div>
    </div>
  );
}
