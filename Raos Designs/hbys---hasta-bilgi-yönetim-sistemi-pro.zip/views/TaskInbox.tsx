
import React, { useState } from 'react';
import { Inbox, AlertTriangle, Zap, Calendar, User, CheckCircle2, ArrowRight, ShieldAlert, X } from 'lucide-react';

export default function TaskInbox() {
  const [tasks, setTasks] = useState([
    {
      id: '1',
      title: 'Faturasız Muayene Tespiti',
      description: 'Dün gerçekleşen Dr. Ahmet Demir muayenesi (Hasta: Can Yılmaz) için fatura kesilmemiş.',
      type: 'LEAKAGE',
      priority: 'HIGH',
      patient: 'Can Yılmaz',
      date: 'Dün, 14:30',
      status: 'PENDING'
    },
    {
      id: '2',
      title: 'Yüksek Gelmeme Riski',
      description: 'Yarınki randevusu olan Elif Kaya daha önceki 2 randevusuna gelmedi. Teyit araması yapılmalı.',
      type: 'NO_SHOW',
      priority: 'HIGH',
      patient: 'Elif Kaya',
      date: 'Yarın, 10:00',
      status: 'PENDING'
    },
    {
      id: '3',
      title: 'Eksik Onam Formu',
      description: 'Cerrahi işlem planlanan Ayşe Tekin için dijital onam formu henüz imzalanmadı.',
      type: 'DOCUMENT',
      priority: 'MEDIUM',
      patient: 'Ayşe Tekin',
      date: '20 Ocak',
      status: 'PENDING'
    }
  ]);

  const resolveTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
    alert("Görev başarıyla tamamlandı ve sızıntı kapatıldı.");
  };

  return (
    <div className="max-w-5xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">Akıllı Görev Merkezi</h1>
          <p className="text-slate-500 font-medium">Sistem tarafından tespit edilen operasyonel eksiklikler.</p>
        </div>
        <div className="flex items-center gap-3 bg-white px-5 py-3 rounded-2xl border border-slate-200 shadow-sm">
          <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Canlı Denetim Aktif</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="bg-rose-600 p-8 rounded-[40px] text-white shadow-2xl shadow-rose-600/20 relative overflow-hidden group">
          <ShieldAlert className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10 group-hover:scale-110 transition-transform" />
          <p className="text-rose-100 text-[10px] font-black uppercase tracking-widest mb-2">Gelir Kaybı</p>
          <p className="text-4xl font-black">4.250 ₺</p>
          <p className="text-xs font-bold mt-3 text-rose-100">Engellenebilir Sızıntı</p>
        </div>
        <div className="bg-amber-500 p-8 rounded-[40px] text-white shadow-2xl shadow-amber-500/20 relative overflow-hidden group">
          <Calendar className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10 group-hover:scale-110 transition-transform" />
          <p className="text-amber-100 text-[10px] font-black uppercase tracking-widest mb-2">No-Show Riski</p>
          <p className="text-4xl font-black">{tasks.filter(t => t.type === 'NO_SHOW').length}</p>
          <p className="text-xs font-bold mt-3 text-amber-100">Kritik Hasta Tespiti</p>
        </div>
        <div className="bg-slate-900 p-8 rounded-[40px] text-white shadow-2xl shadow-slate-900/20 col-span-2 relative overflow-hidden group">
          <div className="relative z-10">
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-2">Sistem Verimliliği</p>
            <p className="text-4xl font-black">%{100 - tasks.length * 5}</p>
            <p className="text-xs font-bold mt-3 text-slate-400">Genel Operasyonel Sağlık</p>
          </div>
          <Zap className="absolute -right-6 -top-6 w-40 h-40 opacity-5 group-hover:rotate-12 transition-transform" />
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between px-4">
          <h2 className="text-xl font-black text-slate-900 tracking-tight">Bekleyen Aksiyonlar</h2>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{tasks.length} Bekleyen</span>
        </div>
        
        {tasks.length === 0 ? (
          <div className="bg-white p-20 rounded-[48px] border border-slate-200 text-center space-y-4">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto"><CheckCircle2 size={40}/></div>
            <h3 className="text-xl font-black text-slate-900">Harika! Bekleyen görev yok.</h3>
            <p className="text-slate-500 max-w-xs mx-auto">Tüm sızıntılar kapatıldı ve sistem tam verimlilikle çalışıyor.</p>
          </div>
        ) : tasks.map((task) => (
          <div key={task.id} className="bg-white rounded-[40px] border border-slate-200 p-8 flex flex-col md:flex-row items-start md:items-center gap-8 group hover:border-indigo-400 hover:shadow-2xl transition-all duration-300">
            <div className={`p-6 rounded-[32px] shrink-0 transition-transform group-hover:scale-110 ${
              task.type === 'LEAKAGE' ? 'bg-rose-50 text-rose-600 shadow-lg shadow-rose-100' : 
              task.type === 'NO_SHOW' ? 'bg-amber-50 text-amber-600 shadow-lg shadow-amber-100' : 'bg-indigo-50 text-indigo-600 shadow-lg shadow-indigo-100'
            }`}>
              {task.type === 'LEAKAGE' ? <Zap size={32} /> : 
               task.type === 'NO_SHOW' ? <AlertTriangle size={32} /> : <Inbox size={32} />}
            </div>
            
            <div className="flex-1 space-y-3">
              <div className="flex items-center gap-4">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">{task.title}</h3>
                <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                  task.priority === 'HIGH' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {task.priority === 'HIGH' ? 'ACİL' : 'NORMAL'}
                </span>
              </div>
              <p className="text-lg text-slate-500 font-medium leading-relaxed">{task.description}</p>
              <div className="flex items-center gap-6 pt-2">
                <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest">
                  <User size={16} className="text-indigo-400" /> {task.patient}
                </div>
                <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest">
                  <Calendar size={16} className="text-indigo-400" /> {task.date}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto pt-6 md:pt-0">
              <button onClick={() => resolveTask(task.id)} className="flex-1 md:flex-none px-8 py-4 bg-slate-900 text-white font-black uppercase tracking-widest rounded-[24px] flex items-center justify-center gap-3 hover:bg-indigo-600 transition-all shadow-xl shadow-slate-900/10 group/btn">
                Çözümle <ArrowRight size={20} className="group-hover/btn:translate-x-1 transition-transform" />
              </button>
              <button onClick={() => resolveTask(task.id)} className="p-4 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-[24px] border border-slate-200 transition-all">
                <CheckCircle2 size={32} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
