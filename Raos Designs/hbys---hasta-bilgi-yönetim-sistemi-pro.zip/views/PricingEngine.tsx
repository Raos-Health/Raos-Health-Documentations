
import React, { useState, useEffect } from 'react';
import { 
  Tag, Plus, Search, FileText, Send, CheckCircle, 
  XCircle, Filter, Banknote, ArrowRight, Package,
  MessageSquare, ExternalLink, Trash2, Edit2, TrendingUp, X
} from 'lucide-react';
import { supabase, logAuditEvent } from '../supabase';
import { Service, Package as PackageType, Offer, OfferStatus } from '../types';

export default function PricingEngine() {
  const [activeTab, setActiveTab] = useState<'offers' | 'services' | 'packages'>('offers');
  const [loading, setLoading] = useState(false);

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Fiyat & Paket Motoru</h1>
          <p className="text-slate-500 font-medium">Standart tekliflerinizi ve hizmet maliyetlerini (₺) yönetin.</p>
        </div>
        <button 
          onClick={() => alert("Yeni teklif modülü yükleniyor...")}
          className="px-8 py-5 bg-[#07363c] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl hover:scale-105 transition-all flex items-center gap-3"
        >
          <Plus size={18} /> Yeni Teklif Oluştur
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm flex items-center justify-between card-hover">
           <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Teklif Dönüşüm</p>
              <p className="text-3xl font-black text-[#07363c]">%74</p>
           </div>
           <div className="p-4 bg-emerald-100 text-emerald-700 rounded-3xl"><TrendingUp size={28} /></div>
        </div>
        <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm flex items-center justify-between card-hover">
           <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Ort. İndirim</p>
              <p className="text-3xl font-black text-[#07363c]">%12.4</p>
           </div>
           <div className="p-4 bg-indigo-100 text-indigo-700 rounded-3xl font-black text-2xl flex items-center justify-center w-14 h-14 currency-symbol">₺</div>
        </div>
        <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm flex items-center justify-between card-hover">
           <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Popüler Paket</p>
              <p className="text-xl font-black text-[#07363c]">Gold Check-Up</p>
           </div>
           <div className="p-4 bg-amber-100 text-amber-700 rounded-3xl"><Package size={28} /></div>
        </div>
      </div>

      <div className="bg-white rounded-[40px] border-2 border-slate-200 overflow-hidden shadow-sm">
         <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <h3 className="text-lg font-black text-[#07363c]">Tanımlı Hizmet Listesi</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none" placeholder="Hizmet ara..." />
            </div>
         </div>
         <table className="w-full text-left font-bold">
            <thead className="bg-slate-50 border-b border-slate-100">
               <tr>
                  <th className="px-10 py-6 text-[10px] text-slate-500 uppercase tracking-widest">Hizmet Adı</th>
                  <th className="px-10 py-6 text-[10px] text-slate-500 uppercase tracking-widest">Kategori</th>
                  <th className="px-10 py-6 text-right text-[10px] text-slate-500 uppercase tracking-widest">Fiyat (₺)</th>
               </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
               {[
                 { name: 'Dahiliye Muayene', cat: 'Muayene', price: '1.200' },
                 { name: 'Kardiyoloji EKG', cat: 'Tetkik', price: '650' },
                 { name: 'Tam Kan Sayımı', cat: 'Laboratuvar', price: '450' },
               ].map((s, i) => (
                 <tr key={i} className="hover:bg-slate-50 transition-colors">
                    <td className="px-10 py-6 text-[#07363c]">{s.name}</td>
                    <td className="px-10 py-6"><span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-[10px] font-black uppercase text-slate-400">{s.cat}</span></td>
                    <td className="px-10 py-6 text-right font-black text-[#07363c]">{s.price} ₺</td>
                 </tr>
               ))}
            </tbody>
         </table>
      </div>
    </div>
  );
}
