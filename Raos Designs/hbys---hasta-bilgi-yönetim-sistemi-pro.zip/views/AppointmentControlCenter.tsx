
import React, { useState, useEffect } from 'react';
import { supabase, logAuditEvent } from '../supabase';
import { Appointment, AppointmentStatus, PatientRiskFlag } from '../types';
import { 
  Calendar, Clock, CheckCircle, AlertCircle, MessageSquare, 
  PhoneCall, Users, Zap, Filter, Search, ChevronLeft, ChevronRight,
  UserPlus, Mail, DollarSign, LayoutList, CalendarDays, MoreHorizontal,
  RefreshCw, TrendingUp, X
} from 'lucide-react';

export default function AppointmentControlCenter() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');
  const [activeDate, setActiveDate] = useState(new Date());
  const [filter, setFilter] = useState<'all' | 'risk' | 'unconfirmed' | 'gaps'>('all');
  const [showGapModal, setShowGapModal] = useState(false);

  useEffect(() => {
    fetchData();
  }, [activeDate, filter]);

  async function fetchData() {
    setLoading(true);
    // Mocking high-utility data for demo
    const { data } = await supabase
      .from('appointments')
      .select('*, patient:patients(*), doctor:profiles!appointments_doctor_id_fkey(*), department:departments(*)')
      .order('appointment_date', { ascending: true });

    if (data) {
      let enriched: Appointment[] = data.map(apt => ({
        ...apt,
        risk_data: {
          score: Math.floor(Math.random() * 100),
          tier: 'Orta',
          reasons: []
        } as any,
        payment_status: Math.random() > 0.5 ? 'ÖDENDİ' : 'BEKLEYEN',
        last_message_at: new Date(Date.now() - 3600000).toISOString()
      }));

      // Intersperse Gaps for demo if "gaps" filter is active or for capacity view
      if (filter === 'gaps') {
        const gap: Appointment = {
           id: 'gap-1',
           status: AppointmentStatus.GAP,
           appointment_date: new Date(Date.now() + 7200000).toISOString(),
           duration_minutes: 30,
           doctor: enriched[0]?.doctor
        } as any;
        enriched = [gap, ...enriched];
      }

      if (filter === 'risk') enriched = enriched.filter(a => a.risk_data!.score > 60);
      if (filter === 'unconfirmed') enriched = enriched.filter(a => a.status === AppointmentStatus.CONFIRM_PENDING);

      setAppointments(enriched);
    }
    setLoading(false);
  }

  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      {/* Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Randevu Kontrol Merkezi</h1>
          <p className="text-slate-500 font-medium italic">Onayla, Riskleri Yönet ve Kapasiteyi Doldur.</p>
        </div>
        
        <div className="flex items-center gap-4 bg-white p-2 rounded-[28px] border border-slate-100 shadow-sm">
           <div className="flex p-1 bg-slate-50 rounded-2xl">
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2.5 rounded-xl transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-[#07363c]' : 'text-slate-400'}`}
              >
                <LayoutList size={20} />
              </button>
              <button 
                onClick={() => setViewMode('calendar')}
                className={`p-2.5 rounded-xl transition-all ${viewMode === 'calendar' ? 'bg-white shadow-sm text-[#07363c]' : 'text-slate-400'}`}
              >
                <CalendarDays size={20} />
              </button>
           </div>
           <div className="h-8 w-px bg-slate-100 mx-2"></div>
           <button className="flex items-center gap-2 bg-[#07363c] text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-all">
              <UserPlus size={18} /> Hızlı Kayıt
           </button>
        </div>
      </div>

      {/* Date Navigation Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 no-scrollbar">
         {days.map((date, i) => (
           <button 
            key={i}
            onClick={() => setActiveDate(date)}
            className={`flex flex-col items-center min-w-[100px] p-4 rounded-[28px] border-2 transition-all ${
              activeDate.toDateString() === date.toDateString() 
                ? 'bg-[#07363c] border-[#07363c] text-white shadow-xl -translate-y-1' 
                : 'bg-white border-slate-100 text-slate-400 hover:border-[#E4C19D]'
            }`}
           >
              <span className="text-[10px] font-black uppercase tracking-widest opacity-60">
                {date.toLocaleDateString('tr-TR', { weekday: 'short' })}
              </span>
              <span className="text-xl font-black">{date.getDate()}</span>
           </button>
         ))}
      </div>

      {/* Filters & KPI Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
         <button onClick={() => setFilter('risk')} className={`p-6 rounded-[32px] border-2 transition-all text-left group ${filter === 'risk' ? 'border-rose-500 bg-rose-50/30' : 'bg-white border-slate-100'}`}>
            <AlertCircle className={`mb-4 ${filter === 'risk' ? 'text-rose-500' : 'text-slate-300'}`} size={24} />
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Yüksek Risk</p>
            <p className="text-2xl font-black text-[#07363c]">12 Randevu</p>
         </button>
         <button onClick={() => setFilter('unconfirmed')} className={`p-6 rounded-[32px] border-2 transition-all text-left group ${filter === 'unconfirmed' ? 'border-amber-500 bg-amber-50/30' : 'bg-white border-slate-100'}`}>
            <Clock className={`mb-4 ${filter === 'unconfirmed' ? 'text-amber-500' : 'text-slate-300'}`} size={24} />
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Onay Bekleyen</p>
            <p className="text-2xl font-black text-[#07363c]">8 Randevu</p>
         </button>
         <button onClick={() => setFilter('gaps')} className={`p-6 rounded-[32px] border-2 transition-all text-left group ${filter === 'gaps' ? 'border-indigo-500 bg-indigo-50/30' : 'bg-white border-slate-100'}`}>
            <Zap className={`mb-4 ${filter === 'gaps' ? 'text-indigo-500' : 'text-slate-300'}`} size={24} />
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Boş Slotlar</p>
            <p className="text-2xl font-black text-[#07363c]">4 Arıza/Boşluk</p>
         </button>
         <div className="bg-[#E4C19D] p-6 rounded-[32px] text-[#07363c] flex flex-col justify-center">
            <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-1">Genel Doluluk</p>
            <div className="flex items-baseline gap-2">
               <span className="text-3xl font-black">%92</span>
               <TrendingUp size={16} className="text-emerald-700" />
            </div>
            <div className="h-1.5 bg-white/30 rounded-full mt-4 overflow-hidden">
               <div className="h-full bg-[#07363c]" style={{ width: '92%' }}></div>
            </div>
         </div>
      </div>

      {/* Main Content Area */}
      <div className="bg-white rounded-[48px] border border-slate-200 overflow-hidden shadow-sm">
         <div className="p-8 border-b border-slate-100 bg-slate-50/30 flex items-center justify-between">
            <div className="flex items-center gap-6">
               <div className="relative group">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <input className="pl-12 pr-6 py-3 bg-white border border-slate-200 rounded-2xl outline-none font-bold text-sm w-80 focus:border-[#07363c] transition-all" placeholder="Liste içinde ara..." />
               </div>
               <button onClick={() => setFilter('all')} className={`text-xs font-black uppercase tracking-widest ${filter === 'all' ? 'text-[#07363c]' : 'text-slate-400'}`}>Tümünü Göster</button>
            </div>
            <div className="flex gap-2">
               <button className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#07363c] transition-all"><RefreshCw size={18}/></button>
               <button className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#07363c] transition-all"><Filter size={18}/></button>
            </div>
         </div>

         <div className="overflow-x-auto">
            <table className="w-full text-left">
               <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-100">
                     <th className="px-8 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Saat / Hasta</th>
                     <th className="px-8 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Onay / Risk</th>
                     <th className="px-8 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Son İletişim</th>
                     <th className="px-8 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Tahsilat</th>
                     <th className="px-8 py-6 text-right text-[10px] font-black text-[#07363c] uppercase tracking-widest">Aksiyonlar</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                  {appointments.map((apt) => (
                    <tr key={apt.id} className={`group transition-all ${apt.status === AppointmentStatus.GAP ? 'bg-indigo-50/30' : 'hover:bg-slate-50/80'}`}>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-5">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-sm ${
                            apt.status === AppointmentStatus.GAP ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-[#07363c]'
                          }`}>
                            {new Date(apt.appointment_date).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                          <div>
                             {apt.status === AppointmentStatus.GAP ? (
                               <span className="font-black text-indigo-600 uppercase text-sm italic">BOŞ SLOT • KAPASİTE ARTIYOR</span>
                             ) : (
                               <>
                                 <p className="font-black text-[#07363c]">{apt.patient?.first_name} {apt.patient?.last_name}</p>
                                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">DR. {apt.doctor?.full_name}</p>
                               </>
                             )}
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                         {apt.status === AppointmentStatus.GAP ? (
                           <button 
                            onClick={() => setShowGapModal(true)}
                            className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-200 hover:scale-105 transition-all"
                           >
                              Bekleme Listesinden Doldur
                           </button>
                         ) : (
                           <div className="flex items-center gap-4">
                              <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ${
                                apt.status === AppointmentStatus.CONFIRMED ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                              }`}>
                                {apt.status}
                              </span>
                              <div className="flex flex-col gap-1 w-20">
                                 <div className="flex justify-between text-[8px] font-black text-slate-400 uppercase">
                                    <span>Risk</span>
                                    <span>%{apt.risk_data?.score}</span>
                                 </div>
                                 <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
                                    <div className={`h-full ${apt.risk_data!.score > 60 ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{ width: `${apt.risk_data?.score}%` }}></div>
                                 </div>
                              </div>
                           </div>
                         )}
                      </td>
                      <td className="px-8 py-6">
                        {apt.status !== AppointmentStatus.GAP && (
                          <div className="flex flex-col">
                             <span className="text-xs font-bold text-slate-600 flex items-center gap-1"><Mail size={12}/> WhatsApp • Okundu</span>
                             <span className="text-[10px] font-bold text-slate-400 uppercase">1 SAAT ÖNCE</span>
                          </div>
                        )}
                      </td>
                      <td className="px-8 py-6">
                        {apt.status !== AppointmentStatus.GAP && (
                           <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase border ${
                             apt.payment_status === 'ÖDENDİ' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-50 text-slate-400 border-slate-100'
                           }`}>
                             {apt.payment_status}
                           </span>
                        )}
                      </td>
                      <td className="px-8 py-6 text-right">
                        {apt.status !== AppointmentStatus.GAP && (
                          <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                             <button onClick={() => alert("WhatsApp Onay Mesajı Gönderildi")} className="p-2.5 bg-white border border-slate-200 text-slate-400 hover:text-emerald-600 hover:border-emerald-200 rounded-xl shadow-sm transition-all" title="WhatsApp Onay"><MessageSquare size={16}/></button>
                             <button onClick={() => alert("Arama görevi oluşturuldu")} className="p-2.5 bg-white border border-slate-200 text-slate-400 hover:text-indigo-600 hover:border-indigo-200 rounded-xl shadow-sm transition-all" title="Ara"><PhoneCall size={16}/></button>
                             <button onClick={() => alert("Erteleme ekranı açıldı")} className="p-2.5 bg-white border border-slate-200 text-slate-400 hover:text-amber-600 hover:border-amber-200 rounded-xl shadow-sm transition-all" title="Ertele"><RefreshCw size={16}/></button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>

      {/* Gap Filler Modal (Waitlist Management) */}
      {showGapModal && (
        <div className="fixed inset-0 z-[110] bg-[#07363c]/90 backdrop-blur-xl flex items-center justify-center p-4">
           <div className="bg-white w-full max-w-2xl rounded-[48px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-10 bg-indigo-600 text-white relative">
                 <Zap className="absolute -right-10 -top-10 w-64 h-64 opacity-10 rotate-12" />
                 <div className="flex justify-between items-start mb-6">
                    <div className="p-3 bg-white/20 rounded-2xl"><Users size={28} fill="currentColor" /></div>
                    <button onClick={() => setShowGapModal(false)} className="text-white/40 hover:text-white transition-colors"><X size={32} /></button>
                 </div>
                 <h2 className="text-4xl font-black tracking-tighter mb-2">Boşluğu Doldur</h2>
                 <p className="text-indigo-100 font-bold text-lg">Bu saat için bekleme listesinde uygun 3 hasta bulundu:</p>
              </div>

              <div className="p-10 space-y-4">
                 {[
                   { name: 'Selin Araz', detail: 'Öncelikli • Kontrol Muayenesi', waitDays: 4 },
                   { name: 'Murat Yıldız', detail: 'Hızlı İşlem • Tetkik Sonucu', waitDays: 12 },
                   { name: 'Esra Bilgiç', detail: 'Vip • Yeni Kayıt', waitDays: 2 }
                 ].map((p, i) => (
                   <button 
                      key={i} 
                      onClick={() => { alert(`${p.name} randevuya atandı. Bildirim gönderiliyor.`); setShowGapModal(false); fetchData(); }}
                      className="w-full flex items-center justify-between p-6 rounded-[28px] border-2 border-slate-100 hover:border-indigo-600 hover:bg-indigo-50 group transition-all text-left"
                   >
                      <div className="flex items-center gap-5">
                         <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center font-black text-[#07363c] group-hover:bg-indigo-600 group-hover:text-white transition-all">{p.name[0]}</div>
                         <div>
                            <p className="font-black text-[#07363c] text-lg">{p.name}</p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{p.detail}</p>
                         </div>
                      </div>
                      <div className="text-right">
                         <p className="text-xs font-black text-indigo-600 uppercase">{p.waitDays} GÜNDÜR BEKLİYOR</p>
                      </div>
                   </button>
                 ))}
                 
                 <div className="pt-8 flex flex-col gap-3">
                    <button onClick={() => setShowGapModal(false)} className="w-full py-5 bg-[#07363c] text-white rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl">İptal, Boş Kalsın</button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}
