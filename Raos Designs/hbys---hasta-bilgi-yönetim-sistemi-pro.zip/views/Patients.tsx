
import React, { useEffect, useState, useMemo, useRef } from 'react';
import { supabase } from '../supabase';
import { Patient, PatientRiskFlag, PipelineStage } from '../types';
import { 
  Search, Plus, Edit2, Trash2, ShieldAlert, CreditCard, 
  Calendar, ClipboardList, UserCheck, Activity, Target, MessageSquare, History,
  CheckSquare, Square, Download, Send, PhoneCall, Zap, X, AlertTriangle, UserPlus, Sparkles
} from 'lucide-react';

export default function Patients() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [show360, setShow360] = useState<Patient | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBulkMode, setIsBulkMode] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newPatient, setNewPatient] = useState({ tc_no: '', first_name: '', last_name: '', phone: '' });
  
  const tcInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchPatients();
  }, [searchTerm]);

  async function fetchPatients() {
    setLoading(true);
    let query = supabase.from('patients').select('*').order('created_at', { ascending: false });
    if (searchTerm) {
      query = query.or(`first_name.ilike.%${searchTerm}%,last_name.ilike.%${searchTerm}%,tc_no.ilike.%${searchTerm}%`);
    }
    const { data } = await query;
    const enriched = (data || []).map(p => ({
      ...p,
      risk_score: Math.floor(Math.random() * 100),
      flags: Math.random() > 0.6 ? [PatientRiskFlag.NO_SHOW_HIGH, PatientRiskFlag.PAYMENT_OVERDUE] : [],
      pipeline_stage: PipelineStage.SCHEDULED
    }));
    setPatients(enriched);
    setLoading(false);
  }

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const toggleAll = () => {
    if (selectedIds.length === patients.length) setSelectedIds([]);
    else setSelectedIds(patients.map(p => p.id));
  };

  const duplicatePatient = useMemo(() => {
    if (newPatient.tc_no.length === 11) {
      return patients.find(p => p.tc_no === newPatient.tc_no);
    }
    return null;
  }, [newPatient.tc_no, patients]);

  const bulkExport = () => {
    alert(`${selectedIds.length} hasta verisi CSV olarak hazırlandı.`);
    setSelectedIds([]);
  };

  const handleQuickRegister = async () => {
    if (duplicatePatient) return;
    // Logic to save patient would go here
    alert("Hasta başarıyla kaydedildi.");
    setShowAddModal(false);
    setNewPatient({ tc_no: '', first_name: '', last_name: '', phone: '' });
    fetchPatients();
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Hasta Veri Merkezi</h1>
          <p className="text-slate-500 font-medium italic flex items-center gap-2">
            <Sparkles size={16} className="text-[#E4C19D]" /> 
            Sıfır Sürtünmeli Arayüz & Akıllı Validasyon
          </p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setIsBulkMode(!isBulkMode)}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${
              isBulkMode ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'bg-white border border-slate-200 text-slate-400 hover:bg-slate-50'
            }`}
          >
            {isBulkMode ? <CheckSquare size={16} /> : <Square size={16} />} {isBulkMode ? 'Toplu Seçim Aktif' : 'Toplu İşlem'}
          </button>
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-[#07363c] text-white px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-[#07363c]/20 transition-all hover:-translate-y-1 active:scale-95"
          >
            <UserPlus size={18} /> Yeni Kayıt (N)
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[48px] border border-slate-200 overflow-hidden shadow-sm relative">
        <div className="p-8 border-b border-slate-100 bg-slate-50/30 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="relative w-full max-w-xl group">
            <Search size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#07363c] transition-colors" />
            <input 
              type="text" placeholder="İsim, TC No veya Telefon Ara..." 
              className="w-full pl-16 pr-8 py-5 rounded-[28px] border-2 border-transparent bg-white shadow-inner outline-none text-base font-bold transition-all focus:border-[#07363c] focus:ring-8 focus:ring-[#07363c]/5"
              value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-8">
            <div className="text-center group cursor-pointer">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 group-hover:text-[#07363c] transition-colors">Aktif Havuz</p>
              <p className="text-2xl font-black text-[#07363c]">{patients.length}</p>
            </div>
            <div className="w-px h-10 bg-slate-200"></div>
            <div className="text-center group cursor-pointer">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 group-hover:text-[#E4C19D] transition-colors">Bugün Kayıt</p>
              <p className="text-2xl font-black text-[#E4C19D]">14</p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                {isBulkMode && (
                  <th className="px-8 py-6 w-12 text-center">
                    <button onClick={toggleAll} className="text-[#07363c] hover:scale-110 transition-transform">
                      {selectedIds.length === patients.length ? <CheckSquare size={20} /> : <Square size={20} />}
                    </button>
                  </th>
                )}
                <th className="px-8 py-6 text-[11px] font-black text-[#07363c] uppercase tracking-widest">Hasta Kimliği</th>
                <th className="px-8 py-6 text-[11px] font-black text-[#07363c] uppercase tracking-widest">Risk & Finans</th>
                <th className="px-8 py-6 text-[11px] font-black text-[#07363c] uppercase tracking-widest">Durum (Pipeline)</th>
                <th className="px-8 py-6 text-right text-[11px] font-black text-[#07363c] uppercase tracking-widest">Süper Aksiyonlar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                Array(5).fill(0).map((_, i) => <tr key={i} className="animate-pulse h-24"><td colSpan={5}></td></tr>)
              ) : patients.map((p) => (
                <tr 
                  key={p.id} 
                  className={`transition-all duration-200 group cursor-pointer ${
                    selectedIds.includes(p.id) ? 'bg-indigo-50/50' : 'hover:bg-slate-50/80'
                  }`}
                  onClick={() => isBulkMode ? toggleSelect(p.id) : setShow360(p)}
                >
                  {isBulkMode && (
                    <td className="px-8 py-6 text-center" onClick={e => e.stopPropagation()}>
                       <button onClick={() => toggleSelect(p.id)} className={selectedIds.includes(p.id) ? 'text-indigo-600' : 'text-slate-300'}>
                        {selectedIds.includes(p.id) ? <CheckSquare size={20} /> : <Square size={20} />}
                      </button>
                    </td>
                  )}
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-5">
                      <div className="w-14 h-14 rounded-[24px] bg-[#07363c]/5 text-[#07363c] flex items-center justify-center font-black text-xl group-hover:scale-110 group-hover:bg-[#07363c] group-hover:text-white transition-all">
                        {p.first_name[0]}{p.last_name[0]}
                      </div>
                      <div>
                        <p className="font-black text-[#07363c] text-lg leading-none mb-1">{p.first_name} {p.last_name}</p>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{p.tc_no}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex flex-col gap-2 max-w-[160px]">
                      <div className="flex justify-between items-center text-[10px] font-black text-slate-400 uppercase">
                        <span>Risk</span>
                        <span className={p.risk_score! > 70 ? 'text-rose-600' : 'text-emerald-600'}>%{p.risk_score}</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className={`h-full transition-all duration-1000 ${p.risk_score! > 70 ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{ width: `${p.risk_score}%` }}></div>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="px-4 py-1.5 bg-white border border-slate-200 text-slate-500 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-sm group-hover:border-[#07363c] transition-colors">
                      {p.pipeline_stage}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right" onClick={e => e.stopPropagation()}>
                    <div className="flex justify-end gap-2 sm:opacity-0 group-hover:opacity-100 transition-all sm:translate-x-4 group-hover:translate-x-0">
                      <button onClick={() => alert("Hızlı onay SMS'i gönderildi.")} className="p-3 bg-white border border-slate-200 text-slate-400 rounded-xl hover:text-indigo-600 hover:border-indigo-200 hover:shadow-lg transition-all" title="Randevu Onay"><Calendar size={18}/></button>
                      <button onClick={() => alert("Arama listesine eklendi.")} className="p-3 bg-white border border-slate-200 text-slate-400 rounded-xl hover:text-emerald-600 hover:border-emerald-200 hover:shadow-lg transition-all" title="Hızlı Arama"><PhoneCall size={18}/></button>
                      <button onClick={() => setShow360(p)} className="p-3 bg-white border border-slate-200 text-slate-400 rounded-xl hover:text-[#07363c] hover:border-[#07363c] hover:shadow-lg transition-all" title="Tam Detay"><Zap size={18}/></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Floating Bulk Action Bar (Massive Time Saver) */}
      {selectedIds.length > 0 && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[60] bg-[#07363c] text-white px-10 py-6 rounded-[32px] shadow-2xl flex items-center gap-10 animate-in slide-in-from-bottom-20 duration-500 border border-white/10 backdrop-blur-md">
           <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-widest opacity-40">Seçili Hasta</span>
              <span className="text-2xl font-black">{selectedIds.length}</span>
           </div>
           <div className="w-px h-12 bg-white/10"></div>
           <div className="flex gap-3">
              <button onClick={bulkExport} className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                <Download size={16} /> Veriyi Aktar
              </button>
              <button onClick={() => { alert("Toplu bilgilendirme mesajları kuyruğa alındı."); setSelectedIds([]); }} className="flex items-center gap-2 px-6 py-3 bg-indigo-500 hover:bg-indigo-600 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                <Send size={16} /> Toplu Mesaj
              </button>
              <button onClick={() => setSelectedIds([])} className="flex items-center gap-2 px-6 py-3 bg-rose-500 hover:bg-rose-600 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                <Trash2 size={16} /> Toplu Sil
              </button>
           </div>
           <button onClick={() => setSelectedIds([])} className="p-2 text-white/30 hover:text-white transition-colors"><X size={24} /></button>
        </div>
      )}

      {/* Add Patient Modal (Zero-Friction Entry + Duplicate Detection) */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] bg-[#07363c]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-[48px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-white/10">
             <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
               <div>
                 <h2 className="text-3xl font-black text-[#07363c] tracking-tight">Hızlı Kayıt</h2>
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Saniyeler İçinde Giriş Yapın</p>
               </div>
               <button onClick={() => setShowAddModal(false)} className="p-3 hover:bg-slate-200 rounded-2xl transition-all"><X size={28} /></button>
             </div>
             
             <div className="p-10 space-y-8">
               {duplicatePatient && (
                 <div className="p-6 bg-rose-50 border-2 border-rose-100 rounded-[32px] flex items-start gap-4 animate-shake">
                    <AlertTriangle className="text-rose-600 shrink-0" size={24} />
                    <div className="flex-1">
                      <p className="font-black text-rose-600">Bu TC Kimlik Numarası Zaten Kayıtlı!</p>
                      <p className="text-xs font-bold text-rose-500 mt-1">"{duplicatePatient.first_name} {duplicatePatient.last_name}" isimli hasta ile çakışıyor.</p>
                    </div>
                    <button 
                      onClick={() => { setShow360(duplicatePatient); setShowAddModal(false); }}
                      className="text-[10px] font-black uppercase bg-white px-4 py-2 rounded-xl border border-rose-200 hover:bg-rose-600 hover:text-white hover:border-rose-600 transition-all shadow-sm"
                    >
                      Kaydı Aç
                    </button>
                 </div>
               )}

               <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">TC Kimlik No</label>
                   <input 
                    autoFocus
                    ref={tcInputRef}
                    maxLength={11}
                    className="w-full px-6 py-4 bg-slate-100 border-2 border-transparent rounded-[24px] outline-none font-bold text-lg focus:bg-white focus:border-[#07363c] transition-all" 
                    placeholder="11 Haneli TC"
                    value={newPatient.tc_no}
                    onChange={(e) => setNewPatient({...newPatient, tc_no: e.target.value.replace(/\D/g,'')})}
                   />
                 </div>
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Telefon No</label>
                   <input 
                    className="w-full px-6 py-4 bg-slate-100 border-2 border-transparent rounded-[24px] outline-none font-bold text-lg focus:bg-white focus:border-[#07363c] transition-all" 
                    placeholder="05XX XXX XX XX"
                    value={newPatient.phone}
                    onChange={(e) => setNewPatient({...newPatient, phone: e.target.value})}
                   />
                 </div>
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Ad</label>
                   <input 
                    className="w-full px-6 py-4 bg-slate-100 border-2 border-transparent rounded-[24px] outline-none font-bold text-lg focus:bg-white focus:border-[#07363c] transition-all" 
                    placeholder="Ad"
                    value={newPatient.first_name}
                    onChange={(e) => setNewPatient({...newPatient, first_name: e.target.value})}
                   />
                 </div>
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Soyad</label>
                   <input 
                    className="w-full px-6 py-4 bg-slate-100 border-2 border-transparent rounded-[24px] outline-none font-bold text-lg focus:bg-white focus:border-[#07363c] transition-all" 
                    placeholder="Soyad"
                    value={newPatient.last_name}
                    onChange={(e) => setNewPatient({...newPatient, last_name: e.target.value})}
                   />
                 </div>
               </div>

               <div className="pt-6">
                 <button 
                  onClick={handleQuickRegister}
                  disabled={!!duplicatePatient || !newPatient.tc_no || !newPatient.first_name}
                  className="w-full py-6 bg-[#07363c] text-white rounded-[32px] font-black uppercase text-xs tracking-[0.2em] shadow-2xl shadow-[#07363c]/20 hover:scale-[1.02] transition-all disabled:opacity-30 disabled:hover:scale-100 flex items-center justify-center gap-3"
                 >
                    Kaydı Tamamla <Zap size={18} fill="currentColor" />
                 </button>
                 <p className="text-center text-[10px] font-bold text-slate-400 uppercase mt-4">Kısayol: Kayıt sırasında ENTER tuşuna basabilirsiniz</p>
               </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
