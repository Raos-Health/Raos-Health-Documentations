
import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
// Task is now exported from types.ts
import { Task, TaskType, AppointmentStatus } from '../types';
import { 
  Phone, CheckCircle, XCircle, Clock, AlertTriangle, 
  MessageSquare, User, Calendar, ShieldAlert, ChevronRight, PlayCircle
} from 'lucide-react';

export default function NoShowInbox() {
  /* Fix: Corrected state type to Task[] */
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState<any | null>(null);

  useEffect(() => {
    fetchTasks();
  }, []);

  async function fetchTasks() {
    setLoading(true);
    // Simüle edilmiş canlı veri birleşimi
    const { data } = await supabase
      .from('tasks')
      .select('*, appointment:appointments(*, patient:patients(*), doctor:profiles(*))')
      .eq('status', 'Açık')
      .order('priority', { ascending: false });
    
    // Demo verisi eğer DB boşsa
    if (!data || data.length === 0) {
      /* Fix: Aligned demo data with Task interface */
      setTasks([
        {
          id: 't1',
          type: TaskType.CONFIRM_CALL,
          priority: 'Yüksek',
          status: 'Açık',
          due_at: new Date(Date.now() + 86400000).toISOString(),
          created_at: new Date().toISOString(),
          appointment_id: 'apt1',
          appointment: {
            appointment_date: new Date(Date.now() + 86400000).toISOString(),
            patient: { first_name: 'Mehmet', last_name: 'Yılmaz', phone: '0532 000 00 01', tc_no: '12345678901' },
            doctor: { full_name: 'Dr. Canan Erçetin' },
            risk_score: 75,
            risk_reasons: ['Geçmişte 2 No-Show', 'Onay Mesajına Dönmedi']
          } as any
        },
        {
          id: 't2',
          type: TaskType.NO_SHOW_RECOVERY,
          priority: 'Acil',
          status: 'Açık',
          due_at: new Date().toISOString(),
          created_at: new Date().toISOString(),
          appointment_id: 'apt2',
          appointment: {
            appointment_date: new Date(Date.now() - 3600000).toISOString(),
            patient: { first_name: 'Ayşe', last_name: 'Kaya', phone: '0544 111 22 33', tc_no: '98765432109' },
            doctor: { full_name: 'Dr. Selim Akın' },
            risk_score: 90,
            risk_reasons: ['Bugünkü randevuya gelmedi']
          } as any
        }
      ]);
    } else {
      setTasks(data);
    }
    setLoading(false);
  }

  const handleOutcome = async (id: string, outcome: string) => {
    alert(`${outcome} işlemi kaydedildi. Görev kapatılıyor.`);
    setTasks(tasks.filter(t => t.id !== id));
    setSelectedTask(null);
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-120px)] gap-8 animate-in fade-in duration-500">
      {/* Task List */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-black text-[#07363c] tracking-tight">Görev Kutusu</h1>
            <p className="text-slate-500 font-medium">No-Show riski taşıyan operasyonel aksiyonlar.</p>
          </div>
          <div className="bg-white px-4 py-2 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Canlı Akış Aktif</span>
          </div>
        </div>

        {tasks.map((task) => (
          <div 
            key={task.id} 
            onClick={() => setSelectedTask(task)}
            className={`bg-white p-6 rounded-[32px] border-2 transition-all cursor-pointer group flex items-center gap-6 ${
              selectedTask?.id === task.id ? 'border-[#07363c] shadow-2xl' : 'border-slate-100 hover:border-slate-300 shadow-sm'
            }`}
          >
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 ${
              task.priority === 'Acil' ? 'bg-rose-50 text-rose-600' : 
              task.priority === 'Yüksek' ? 'bg-amber-50 text-amber-600' : 'bg-[#07363c]/5 text-[#07363c]'
            }`}>
              {task.type === TaskType.CONFIRM_CALL ? <Phone size={28} /> : <AlertTriangle size={28} />}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{task.type}</span>
                <span className={`px-2 py-0.5 rounded-lg text-[8px] font-black uppercase ${
                  task.priority === 'Acil' ? 'bg-rose-600 text-white' : 'bg-slate-200 text-slate-600'
                }`}>{task.priority}</span>
              </div>
              <h3 className="text-xl font-black text-[#07363c] leading-none mb-2">
                {task.appointment?.patient?.first_name} {task.appointment?.patient?.last_name}
              </h3>
              <div className="flex items-center gap-4 text-xs font-bold text-slate-400">
                <div className="flex items-center gap-1"><Clock size={14} className="text-[#E4C19D]" /> {task.appointment?.appointment_date ? new Date(task.appointment.appointment_date).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : '-'}</div>
                <div className="flex items-center gap-1"><User size={14} className="text-[#E4C19D]" /> {task.appointment?.doctor?.full_name}</div>
              </div>
            </div>

            <div className="text-right">
               <p className={`text-2xl font-black ${(task.appointment as any)?.risk_score > 70 ? 'text-rose-600' : 'text-[#07363c]'}`}>
                 %{(task.appointment as any)?.risk_score || 0}
               </p>
               <p className="text-[8px] font-black text-slate-400 uppercase">Risk Skoru</p>
            </div>
            <ChevronRight className="text-slate-200 group-hover:text-[#07363c] transition-colors" />
          </div>
        ))}
      </div>

      {/* Task Details / Action Panel */}
      <div className="w-full lg:w-[450px] space-y-6">
        {selectedTask ? (
          <div className="bg-white rounded-[40px] border border-slate-200 shadow-2xl overflow-hidden sticky top-0 animate-in slide-in-from-right-8 duration-300">
             <div className="p-8 bg-[#07363c] text-white">
                <div className="flex justify-between items-start mb-6">
                   <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md"><ShieldAlert size={24} className="text-[#E4C19D]" /></div>
                   <div className="text-right">
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Beklenen Süre</p>
                      <p className="text-xl font-black">2.5 Dakika</p>
                   </div>
                </div>
                <h2 className="text-3xl font-black tracking-tight mb-2">{selectedTask.appointment.patient.first_name} {selectedTask.appointment.patient.last_name}</h2>
                <p className="text-[#E4C19D] font-bold text-lg">{selectedTask.appointment.patient.phone}</p>
             </div>

             <div className="p-8 space-y-8">
                <div className="space-y-4">
                   <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b pb-2">Arama Senaryosu (Türkçe)</h4>
                   <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 italic text-sm text-slate-600 leading-relaxed relative">
                      "Merhaba {selectedTask.appointment.patient.first_name} Hanım/Bey, Solutions That Heal'den arıyorum. Yarın saat {new Date(selectedTask.appointment.appointment_date).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })} randevunuzu teyit etmek için rahatsız ettim..."
                      <PlayCircle className="absolute -right-2 -bottom-2 text-[#07363c] bg-white rounded-full cursor-pointer hover:scale-110 transition-transform" size={32} />
                   </div>
                </div>

                <div className="space-y-4">
                   <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b pb-2">Risk Nedenleri</h4>
                   <div className="flex flex-wrap gap-2">
                      {selectedTask.appointment.risk_reasons.map((r: string, i: number) => (
                        <span key={i} className="px-3 py-1 bg-rose-50 text-rose-600 rounded-lg text-[10px] font-black border border-rose-100">{r}</span>
                      ))}
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                   <button onClick={() => handleOutcome(selectedTask.id, 'Onaylandı')} className="col-span-2 p-5 bg-emerald-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-emerald-600/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                      <CheckCircle size={20} /> Ulaşıldı - Onayladı
                   </button>
                   <button onClick={() => handleOutcome(selectedTask.id, 'Erteledi')} className="p-5 bg-amber-500 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-amber-500/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                      <Clock size={20} /> Erteledi
                   </button>
                   <button onClick={() => handleOutcome(selectedTask.id, 'İptal')} className="p-5 bg-rose-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-rose-600/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                      <XCircle size={20} /> İptal Etti
                   </button>
                   <button onClick={() => handleOutcome(selectedTask.id, 'Ulaşılamadı')} className="col-span-2 p-5 bg-slate-100 text-slate-600 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-slate-200 transition-all">
                      Ulaşılamadı - Tekrar Denenecek
                   </button>
                </div>
             </div>
          </div>
        ) : (
          <div className="h-full bg-slate-100 rounded-[40px] border-4 border-dashed border-slate-200 flex flex-col items-center justify-center p-12 text-center text-slate-400 space-y-4">
             <MessageSquare size={64} className="opacity-20" />
             <h3 className="text-xl font-black text-slate-500">Görev Detayı İçin Seçim Yapın</h3>
             <p className="text-sm font-medium">Aksiyon almak için sol listeden bir görev seçmeniz gerekmektedir.</p>
          </div>
        )}
      </div>
    </div>
  );
}
