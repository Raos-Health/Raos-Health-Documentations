
import React, { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { supabase, logAuditEvent } from '../supabase';
import { Appointment, AppointmentStatus, Profile, Department } from '../types';
import { 
  Calendar, Clock, MapPin, User, Plus, ChevronLeft, ChevronRight,
  CheckCircle, Zap, Play, ArrowRight, Search, Timer, AlertCircle, Check,
  MoreVertical, Send, Phone, Trash2, CheckSquare, Square, X, Download, RefreshCcw, Sparkles
} from 'lucide-react';

export default function Appointments() {
  const [searchParams] = useSearchParams();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [doctors, setDoctors] = useState<Profile[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSlotFinder, setShowSlotFinder] = useState(false);
  const [showAptModal, setShowAptModal] = useState(false);
  const [newApt, setNewApt] = useState<Partial<Appointment>>({ duration_minutes: 20, status: AppointmentStatus.SCHEDULED });
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBulkMode, setIsBulkMode] = useState(false);

  useEffect(() => {
    fetchInitialData();
    fetchAppointments();
    
    // Smart Memory: Remember last used doctor/dept from localStorage
    const savedDoctor = localStorage.getItem('sth_last_dr');
    const savedDept = localStorage.getItem('sth_last_dept');
    if (savedDoctor || savedDept) {
      setNewApt(prev => ({ ...prev, doctor_id: savedDoctor || '', department_id: savedDept || '' }));
    }
  }, [searchParams]);

  async function fetchInitialData() {
    const { data: drcs } = await supabase.from('profiles').select('*').eq('role', 'DOKTOR');
    const { data: depts } = await supabase.from('departments').select('*');
    if (drcs) setDoctors(drcs);
    if (depts) setDepartments(depts);
  }

  async function fetchAppointments() {
    setLoading(true);
    const drQuery = searchParams.get('dr');
    let query = supabase
      .from('appointments')
      .select('*, patient:patients(*), doctor:profiles!appointments_doctor_id_fkey(*), department:departments(*)')
      .order('appointment_date', { ascending: true });
    
    if (drQuery) {
      query = query.ilike('doctor.full_name', `%${drQuery}%`);
    }

    const { data } = await query;
    if (data) setAppointments(data);
    setLoading(false);
  }

  const handleFlowAction = async (id: string, newStatus: AppointmentStatus) => {
    // Optimistic Update for speed feel
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: newStatus } : a));
    
    const { error } = await supabase.from('appointments').update({ status: newStatus }).eq('id', id);
    if (!error) {
      await logAuditEvent('UPDATE', 'appointment_flow', id, { new_status: newStatus });
    } else {
      fetchAppointments(); // Revert on error
    }
  };

  const handleSaveApt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newApt.patient_id || !newApt.doctor_id) return alert("Lütfen hasta ve doktor seçin.");
    
    // Save to memory for zero-friction next entry
    if (newApt.doctor_id) localStorage.setItem('sth_last_dr', newApt.doctor_id);
    if (newApt.department_id) localStorage.setItem('sth_last_dept', newApt.department_id);

    const { data, error } = await supabase.from('appointments').insert([newApt]).select();
    if (!error) {
      await logAuditEvent('INSERT', 'appointment', data[0].id, newApt);
      setShowAptModal(false);
      fetchAppointments();
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Akış & Planlama</h1>
          <p className="text-slate-500 font-medium italic flex items-center gap-2">
            <Sparkles size={16} className="text-[#E4C19D]" /> 
            Süper Kısayollar: Tek tıkla tam operasyon yönetimi.
          </p>
        </div>
        <div className="flex items-center gap-3 bg-white p-2 rounded-[28px] shadow-sm border border-slate-100">
          <button 
            onClick={() => setIsBulkMode(!isBulkMode)}
            className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
              isBulkMode ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'
            }`}
          >
            {isBulkMode ? 'Kapat' : 'Toplu İşlem'}
          </button>
          <button 
            onClick={() => setShowSlotFinder(true)}
            className="flex items-center gap-2 bg-emerald-50 text-emerald-600 px-6 py-3 rounded-2xl text-[10px] font-black uppercase border border-emerald-100 hover:bg-emerald-100 transition-all shadow-sm"
          >
            <Zap size={16} fill="currentColor" /> Akıllı Slot Öner (S)
          </button>
          <button onClick={() => setShowAptModal(true)} className="flex items-center gap-2 bg-[#07363c] text-white px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] hover:-translate-y-1 transition-all shadow-xl shadow-[#07363c]/20">
            <Plus size={18} /> Yeni Randevu (R)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm group hover:shadow-xl transition-all">
          <div className="w-16 h-16 bg-amber-50 rounded-[28px] flex items-center justify-center text-amber-600 mb-6 group-hover:rotate-12 transition-transform"><Timer size={32}/></div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Ort. Bekleme</p>
          <p className="text-3xl font-black text-[#07363c]">14dk</p>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm group hover:shadow-xl transition-all">
          <div className="w-16 h-16 bg-indigo-50 rounded-[28px] flex items-center justify-center text-indigo-600 mb-6 group-hover:rotate-12 transition-transform"><AlertCircle size={32}/></div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Bekleyen Hasta</p>
          <p className="text-3xl font-black text-[#07363c]">4 Kişi</p>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm group hover:shadow-xl transition-all">
          <div className="w-16 h-16 bg-emerald-50 rounded-[28px] flex items-center justify-center text-emerald-600 mb-6 group-hover:rotate-12 transition-transform"><CheckCircle size={32}/></div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Tamamlanan</p>
          <p className="text-3xl font-black text-[#07363c]">12 / 24</p>
        </div>
        <div className="bg-slate-900 p-8 rounded-[40px] text-white flex flex-col justify-center relative overflow-hidden group shadow-2xl">
           <Zap className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10 group-hover:scale-110 transition-transform" />
           <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Geri Kazanım</p>
           <p className="text-3xl font-black">4 Hasta</p>
           <button className="mt-4 text-[9px] font-black uppercase tracking-widest text-[#E4C19D] hover:text-white flex items-center gap-1 transition-colors">Takip Listesi <ArrowRight size={12} /></button>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm">
          <button className="p-4 rounded-2xl hover:bg-slate-50 text-slate-400 transition-all active:scale-95"><ChevronLeft size={24}/></button>
          <div className="flex flex-col items-center">
             <h2 className="font-black text-[#07363c] text-xl uppercase tracking-[0.2em]">{new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}</h2>
             <span className="text-[10px] font-bold text-slate-400 uppercase mt-1">Bugün • {appointments.length} Randevu</span>
          </div>
          <button className="p-4 rounded-2xl hover:bg-slate-50 text-slate-400 transition-all active:scale-95"><ChevronRight size={24}/></button>
        </div>

        <div className="space-y-4 relative">
          {appointments.length === 0 ? (
            <div className="bg-white py-24 rounded-[48px] border-4 border-dashed border-slate-100 flex flex-col items-center justify-center text-slate-300 gap-6">
              <Calendar size={80} className="opacity-10" />
              <div className="text-center">
                 <p className="font-black text-2xl text-slate-400">Veri Bulunamadı</p>
                 <p className="text-sm font-medium">Randevu kaydı mevcut değil.</p>
              </div>
              <button onClick={() => setShowAptModal(true)} className="px-8 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl">Hemen Randevu Ekle</button>
            </div>
          ) : appointments.map((apt) => (
            <div 
              key={apt.id} 
              className={`bg-white rounded-[40px] border-2 p-8 flex flex-col lg:flex-row items-center gap-10 group transition-all duration-300 ${
                selectedIds.includes(apt.id) ? 'border-indigo-600 bg-indigo-50/20' : 'border-slate-100 hover:border-[#E4C19D] hover:shadow-2xl'
              }`}
              onClick={() => isBulkMode && toggleSelect(apt.id)}
            >
              {isBulkMode && (
                <div className="shrink-0" onClick={e => e.stopPropagation()}>
                   <button onClick={() => toggleSelect(apt.id)} className={selectedIds.includes(apt.id) ? 'text-indigo-600' : 'text-slate-300'}>
                    {selectedIds.includes(apt.id) ? <CheckSquare size={28} /> : <Square size={28} />}
                  </button>
                </div>
              )}

              <div className="flex flex-col items-center justify-center bg-slate-50 px-10 py-6 rounded-[32px] border border-slate-100 min-w-[160px] shadow-inner group-hover:bg-[#07363c] group-hover:text-white transition-all duration-500">
                <span className="text-4xl font-black leading-none">{new Date(apt.appointment_date).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}</span>
                <span className="text-[10px] font-black opacity-40 uppercase tracking-widest mt-3">{apt.duration_minutes} DK</span>
              </div>

              <div className="flex-1 space-y-4 text-center lg:text-left">
                <div className="flex flex-col lg:flex-row items-center gap-5">
                  <h3 className="text-2xl font-black text-[#07363c] tracking-tight">{apt.patient?.first_name} {apt.patient?.last_name}</h3>
                  <div className="flex gap-2">
                    <span className={`px-4 py-1.5 rounded-2xl text-[10px] font-black border uppercase tracking-widest shadow-sm transition-all ${
                      apt.status === AppointmentStatus.WAITING ? 'bg-amber-500 text-white border-amber-600 animate-pulse' :
                      apt.status === AppointmentStatus.IN_ROOM ? 'bg-indigo-600 text-white border-indigo-700' :
                      apt.status === AppointmentStatus.COMPLETED ? 'bg-emerald-600 text-white border-emerald-700' :
                      'bg-slate-100 text-slate-500 border-slate-200'
                    }`}>
                      {apt.status}
                    </span>
                    {apt.patient?.risk_score! > 70 && (
                       <span className="px-4 py-1.5 bg-rose-50 text-rose-600 rounded-2xl text-[10px] font-black border border-rose-100 uppercase tracking-widest">Kritik Risk</span>
                    )}
                  </div>
                </div>
                <div className="flex flex-wrap justify-center lg:justify-start gap-8">
                  <div className="flex items-center gap-3 text-sm font-bold text-slate-500"><User size={20} className="text-[#E4C19D]"/> Dr. {apt.doctor?.full_name}</div>
                  <div className="flex items-center gap-3 text-sm font-bold text-slate-500"><MapPin size={20} className="text-[#E4C19D]"/> {apt.department?.name}</div>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full lg:w-auto" onClick={e => e.stopPropagation()}>
                {apt.status === AppointmentStatus.SCHEDULED && (
                  <button onClick={() => handleFlowAction(apt.id, AppointmentStatus.WAITING)} className="flex-1 lg:flex-none px-10 py-5 bg-amber-500 text-white font-black uppercase tracking-widest rounded-[24px] shadow-xl shadow-amber-500/20 hover:scale-105 transition-all flex items-center justify-center gap-3">
                    <Play size={20} fill="currentColor" /> Giriş
                  </button>
                )}
                {apt.status === AppointmentStatus.WAITING && (
                  <button onClick={() => handleFlowAction(apt.id, AppointmentStatus.IN_ROOM)} className="flex-1 lg:flex-none px-10 py-5 bg-[#07363c] text-white font-black uppercase tracking-widest rounded-[24px] shadow-xl shadow-[#07363c]/20 hover:scale-105 transition-all flex items-center justify-center gap-3">
                     <ArrowRight size={20}/> Muayene
                  </button>
                )}
                {apt.status === AppointmentStatus.IN_ROOM && (
                  <button onClick={() => handleFlowAction(apt.id, AppointmentStatus.COMPLETED)} className="flex-1 lg:flex-none px-10 py-5 bg-emerald-600 text-white font-black uppercase tracking-widest rounded-[24px] shadow-xl shadow-emerald-600/20 hover:scale-105 transition-all flex items-center justify-center gap-3">
                    <Check size={20} strokeWidth={4} /> Bitir
                  </button>
                )}
                <div className="relative group/menu">
                   <button className="p-5 bg-white text-slate-300 rounded-[24px] border border-slate-200 hover:text-[#07363c] hover:border-[#07363c] transition-all shadow-sm"><MoreVertical size={24}/></button>
                   <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-[32px] shadow-2xl border border-slate-100 p-4 opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all z-20 translate-y-2 group-hover/menu:translate-y-0">
                      <button onClick={() => alert("Geri arama görevi oluşturuldu.")} className="w-full flex items-center gap-3 p-3 text-left text-xs font-black text-[#07363c] hover:bg-slate-50 rounded-xl transition-all uppercase tracking-widest"><Phone size={16}/> Ara Görevi</button>
                      <button onClick={() => alert("Onay mesajı SMS olarak gönderildi.")} className="w-full flex items-center gap-3 p-3 text-left text-xs font-black text-[#07363c] hover:bg-slate-50 rounded-xl transition-all uppercase tracking-widest"><Send size={16}/> Onay SMS Gönder</button>
                      <button onClick={() => handleFlowAction(apt.id, AppointmentStatus.CANCELLED)} className="w-full flex items-center gap-3 p-3 text-left text-xs font-black text-rose-500 hover:bg-rose-50 rounded-xl transition-all uppercase tracking-widest"><Trash2 size={16}/> İptal Et</button>
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bulk Action Bar - Zero friction multiple updates */}
      {selectedIds.length > 0 && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[60] bg-[#07363c] text-white px-10 py-6 rounded-[32px] shadow-2xl flex items-center gap-10 animate-in slide-in-from-bottom-20 duration-500 border border-white/10 backdrop-blur-md">
           <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-widest opacity-40">Seçili</span>
              <span className="text-2xl font-black">{selectedIds.length} Randevu</span>
           </div>
           <div className="w-px h-12 bg-white/10"></div>
           <div className="flex gap-3">
              <button onClick={() => { alert("Toplu teyit aramaları görev listesine eklendi."); setSelectedIds([]); }} className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                <CheckCircle size={16} /> Toplu Teyit
              </button>
              <button onClick={() => { alert("Tüm seçili hastalara hatırlatıcı gönderildi."); setSelectedIds([]); }} className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                <Send size={16} /> Hatırlatıcı
              </button>
              <button onClick={() => setSelectedIds([])} className="p-2 text-white/30 hover:text-white transition-colors"><X size={24} /></button>
           </div>
        </div>
      )}

      {/* Appointment Modal (Last used Memory) */}
      {showAptModal && (
        <div className="fixed inset-0 z-[100] bg-[#07363c]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white rounded-[48px] w-full max-w-xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300 border border-white/20">
             <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
               <div>
                  <h2 className="text-3xl font-black text-[#07363c] tracking-tight">Randevu Kaydı</h2>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Akıllı Hafıza Modu Aktif</p>
               </div>
               <button onClick={() => setShowAptModal(false)} className="p-3 hover:bg-slate-200 rounded-2xl transition-all"><X size={28} /></button>
             </div>
             <form onSubmit={handleSaveApt} className="p-10 space-y-6">
               <div className="space-y-2">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Doktor (Son Seçim Hatırlandı)</label>
                 <select required className="w-full p-5 rounded-[24px] bg-slate-100 border-2 border-transparent outline-none font-bold focus:bg-white focus:border-[#07363c] transition-all" value={newApt.doctor_id} onChange={(e) => setNewApt({...newApt, doctor_id: e.target.value})}>
                   <option value="">Doktor Seçiniz...</option>
                   {doctors.map(d => <option key={d.id} value={d.id}>{d.full_name}</option>)}
                 </select>
               </div>
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Tarih / Saat</label>
                   <input type="datetime-local" required className="w-full p-5 rounded-[24px] bg-slate-100 border-2 border-transparent outline-none font-bold text-sm focus:bg-white focus:border-[#07363c] transition-all" onChange={(e) => setNewApt({...newApt, appointment_date: e.target.value})} />
                 </div>
                 <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Süre (Dk)</label>
                   <input type="number" required className="w-full p-5 rounded-[24px] bg-slate-100 border-2 border-transparent outline-none font-bold focus:bg-white focus:border-[#07363c] transition-all" value={newApt.duration_minutes} onChange={(e) => setNewApt({...newApt, duration_minutes: parseInt(e.target.value)})} />
                 </div>
               </div>
               <div className="pt-6">
                 <button type="submit" className="w-full py-6 bg-[#07363c] text-white font-black uppercase tracking-[0.2em] text-xs rounded-[32px] shadow-2xl shadow-[#07363c]/20 hover:scale-[1.02] active:scale-95 transition-all">Randevuyu Blokla (Enter)</button>
               </div>
             </form>
          </div>
        </div>
      )}

      {/* Smart Slot Finder (High Speed AI Heuristics) */}
      {showSlotFinder && (
        <div className="fixed inset-0 z-[100] bg-[#07363c]/80 backdrop-blur-md p-4" onClick={() => setShowSlotFinder(false)}>
          <div className="bg-white rounded-[48px] w-full max-w-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300 border border-white/20" onClick={e => e.stopPropagation()}>
            <div className="p-10 bg-indigo-600 text-white relative">
              <Sparkles className="absolute -right-10 -top-10 w-64 h-64 opacity-10 rotate-12" />
              <div className="flex justify-between items-start mb-6">
                 <div className="p-3 bg-white/20 rounded-2xl"><Zap size={28} fill="currentColor" /></div>
                 <button onClick={() => setShowSlotFinder(false)} className="text-white/40 hover:text-white transition-colors"><X size={32} /></button>
              </div>
              <h2 className="text-4xl font-black tracking-tighter mb-2">Akıllı Slot Bulucu</h2>
              <p className="text-indigo-100 font-bold text-lg">Yapay zeka en verimli 3 saati öneriyor:</p>
            </div>
            <div className="p-10 space-y-4">
              {[
                { time: '14:30', day: 'Bugün', match: 'Düşük Yoğunluk', score: '98%' },
                { time: '09:15', day: 'Yarın', match: 'Doktor Hafızası', score: '92%' },
                { time: '11:00', day: 'Perşembe', match: 'En Verimli', score: '88%' }
              ].map((slot, i) => (
                <button key={i} onClick={() => { setShowSlotFinder(false); setShowAptModal(true); }} className="w-full flex items-center justify-between p-8 rounded-[32px] border-2 border-slate-100 hover:border-indigo-600 hover:bg-indigo-50 group transition-all text-left active:scale-[0.98]">
                  <div className="flex items-center gap-6">
                    <div className="p-5 bg-indigo-600 text-white rounded-[24px] font-black text-2xl group-hover:scale-110 transition-transform shadow-lg shadow-indigo-200">
                      {slot.time}
                    </div>
                    <div>
                      <p className="font-black text-[#07363c] text-2xl leading-none mb-2">{slot.day}</p>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{slot.match}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-black text-indigo-600">{slot.score}</p>
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">GELME İHTİMALİ</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
