
import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, Zap, Target, DollarSign, Clock, Users, 
  ArrowRight, Download, Filter, Info, Sparkles, ShieldCheck,
  ChevronDown, BarChart3, PieChart as ChartIcon, FileText, CheckCircle2
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie
} from 'recharts';

export default function ROIProofCenter() {
  const [dateRange, setDateRange] = useState('Son 30 Gün');
  const [isExporting, setIsExporting] = useState(false);
  const [showConfig, setShowConfig] = useState(false);

  // Mock Finansal Yapılandırma
  const config = {
    avg_value_per_appointment: 1200,
    avg_value_per_filled_slot: 1000,
    avg_value_per_no_show_prevented: 1200,
    staff_minute_value: 2.5
  };

  // Mock ROI Verileri (Baseline vs Mevcut)
  const stats = {
    noShow: { before: 14.2, after: 6.4, preventedCount: 42 },
    gapFill: { count: 28, revenue: 28000 },
    confirmedRate: { before: 62, after: 88 },
    staffTime: { hoursSaved: 156, tasksResolved: 840 },
    totalImpact: 78400
  };

  const chartData = [
    { name: 'Hafta 1', baseline: 42000, actual: 51000 },
    { name: 'Hafta 2', baseline: 44000, actual: 58000 },
    { name: 'Hafta 3', baseline: 41000, actual: 64000 },
    { name: 'Hafta 4', baseline: 45000, actual: 72000 },
  ];

  const handleExportPDF = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      alert("S&H Pro - ROI Yönetim Raporu PDF olarak indirildi.");
    }, 1500);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-24">
      {/* Header with High-Value UX */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="px-3 py-1 bg-emerald-500 text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20">ROI Proof Engine</div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">Yatırım Geri Dönüş Kanıtı</span>
          </div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Yönetim Raporu & Finansal Kazanım</h1>
          <p className="text-slate-500 font-medium">Sistemin hastane karlılığına olan net etkisini kanıtlayan metrikler.</p>
        </div>
        
        <div className="flex items-center gap-3">
           <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2">
              <Filter size={16} className="text-slate-400 ml-2" />
              <select className="bg-transparent border-none outline-none font-bold text-xs text-[#07363c] pr-8" value={dateRange} onChange={e => setDateRange(e.target.value)}>
                <option>Son 7 Gün</option>
                <option>Son 30 Gün</option>
                <option>Son 3 Ay</option>
              </select>
           </div>
           <button 
            onClick={handleExportPDF}
            disabled={isExporting}
            className="px-8 py-4 bg-[#07363c] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-105 transition-all flex items-center gap-3 disabled:opacity-50"
           >
              {isExporting ? <div className="animate-spin h-4 w-4 border-2 border-white/30 border-t-white rounded-full" /> : <Download size={18} />} 
              Yönetim Özeti (PDF)
           </button>
        </div>
      </div>

      {/* Main ROI Impact Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
         <div className="lg:col-span-3 bg-white rounded-[48px] border border-slate-200 shadow-sm overflow-hidden flex flex-col md:flex-row">
            <div className="flex-1 p-12 space-y-8">
               <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">TOPLAM FİNANSAL KAZANIM (NET IMPACT)</p>
                  <p className="text-6xl font-black text-[#07363c] tracking-tighter">78.400 ₺</p>
                  <div className="flex items-center gap-3 mt-4 text-emerald-600">
                     <TrendingUp size={24} />
                     <span className="font-black text-lg tracking-tight">Sistemsiz döneme göre +%24 verimlilik</span>
                  </div>
               </div>
               <div className="grid grid-cols-3 gap-8 pt-8 border-t border-slate-100">
                  <div>
                    <p className="text-[9px] font-black text-slate-400 uppercase mb-1">No-Show Kaybı Önlenen</p>
                    <p className="text-2xl font-black text-[#07363c]">{stats.noShow.preventedCount * config.avg_value_per_no_show_prevented} ₺</p>
                  </div>
                  <div>
                    <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Boş Slot Doldurma</p>
                    <p className="text-2xl font-black text-[#07363c]">{stats.gapFill.revenue} ₺</p>
                  </div>
                  <div>
                    <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Personel Zaman Tasarrufu</p>
                    <p className="text-2xl font-black text-[#07363c]">Simüle Edildi</p>
                  </div>
               </div>
            </div>
            <div className="w-full md:w-80 bg-slate-900 p-12 text-white flex flex-col justify-center relative overflow-hidden">
               <Sparkles className="absolute -right-10 -bottom-10 w-48 h-48 opacity-10 rotate-12" />
               <div className="relative z-10 space-y-6">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Sistem ROI Çarpanı</span>
                    <Info size={16} className="text-[#E4C19D]" />
                  </div>
                  <p className="text-7xl font-black text-[#E4C19D]">14.2x</p>
                  <p className="text-xs font-medium text-white/60 leading-relaxed italic">
                    Yazılım maliyetine karşılık hastaneye kazandırılan net değer kat sayısı.
                  </p>
               </div>
            </div>
         </div>
         
         <div className="bg-[#E4C19D] p-10 rounded-[48px] text-[#07363c] flex flex-col justify-between shadow-2xl shadow-[#E4C19D]/30 relative overflow-hidden">
            <ShieldCheck className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10" />
            <div>
               <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-2">No-Show Oranı</p>
               <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-black">%{stats.noShow.after}</span>
                  <span className="text-xs font-bold line-through opacity-40">%{stats.noShow.before}</span>
               </div>
            </div>
            <div className="bg-white/30 p-4 rounded-3xl mt-8">
               <p className="text-[10px] font-black uppercase mb-1">Kazanılan Randevu</p>
               <p className="text-2xl font-black">{stats.noShow.preventedCount} Adet</p>
            </div>
         </div>
      </div>

      {/* Funnel & Comparison Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <div className="lg:col-span-2 bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm space-y-10">
            <div className="flex items-center justify-between">
               <div>
                  <h3 className="text-2xl font-black text-[#07363c]">Randevu Dönüşüm Hunisi (Performance Funnel)</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase mt-1">Planlanan → T-24 Onay → Geldi</p>
               </div>
               <div className="flex gap-4">
                  <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-slate-200"></div><span className="text-[10px] font-black uppercase text-slate-400 tracking-tighter">Baseline</span></div>
                  <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-[#10b981]"></div><span className="text-[10px] font-black uppercase text-emerald-600 tracking-tighter">Mevcut</span></div>
               </div>
            </div>
            <div className="h-[350px]">
               <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                     <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#07363c' }} />
                     <YAxis hide />
                     <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }} />
                     <Area type="monotone" dataKey="actual" stroke="#10b981" strokeWidth={5} fillOpacity={0.1} fill="#10b981" />
                     <Area type="monotone" dataKey="baseline" stroke="#cbd5e1" strokeWidth={3} strokeDasharray="10 10" fill="transparent" />
                  </AreaChart>
               </ResponsiveContainer>
            </div>
         </div>

         <div className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm flex flex-col h-full">
            <h3 className="text-2xl font-black text-[#07363c] mb-10 flex items-center gap-3">
               <Target className="text-[#E4C19D]" /> Neler Değişti?
            </h3>
            <div className="space-y-8 flex-1">
               <div className="flex gap-4 group">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-100 group-hover:bg-emerald-600 group-hover:text-white transition-all"><TrendingUp size={20} /></div>
                  <div>
                    <p className="text-sm font-bold text-[#07363c]">Onay Oranı %26 Arttı</p>
                    <p className="text-[10px] text-slate-500 leading-relaxed font-medium mt-1">T-24 ve T-6 otomatik mesajlaşma senaryoları ile manuel arama ihtiyacı minimize edildi.</p>
                  </div>
               </div>
               <div className="flex gap-4 group">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 border border-indigo-100 group-hover:bg-indigo-600 group-hover:text-white transition-all"><Zap size={20} /></div>
                  <div>
                    <p className="text-sm font-bold text-[#07363c]">28 Boş Slot Geri Kazanıldı</p>
                    <p className="text-[10px] text-slate-500 leading-relaxed font-medium mt-1">İptal edilen randevular saniyeler içinde bekleme listesindeki uygun hastalara teklif edildi.</p>
                  </div>
               </div>
               <div className="flex gap-4 group">
                  <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 border border-amber-100 group-hover:bg-amber-600 group-hover:text-white transition-all"><Clock size={20} /></div>
                  <div>
                    <p className="text-sm font-bold text-[#07363c]">DSO: -7 Gün İyileşme</p>
                    <p className="text-[10px] text-slate-500 leading-relaxed font-medium mt-1">Tahsilat hızlandırıcı linkleri sayesinde ortalama ödeme süresi 21 günden 14 güne geriledi.</p>
                  </div>
               </div>
            </div>
            <button className="w-full mt-10 py-5 bg-slate-50 text-[#07363c] border border-slate-200 rounded-[32px] font-black uppercase text-[10px] tracking-widest hover:bg-[#07363c] hover:text-white transition-all flex items-center justify-center gap-2 group/btn">
               Tüm Kanıt Listesini Gör <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
            </button>
         </div>
      </div>

      {/* Evidence Table (Traceability) */}
      <div className="bg-white rounded-[48px] border border-slate-200 overflow-hidden shadow-sm">
         <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/30">
            <h3 className="text-2xl font-black text-[#07363c]">İzlenebilir Değer Kanıtı (Geri Kazanım Olayları)</h3>
            <div className="flex gap-2">
               <button onClick={() => setShowConfig(!showConfig)} className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#07363c]"><BarChart3 size={18}/></button>
            </div>
         </div>
         <div className="overflow-x-auto">
            <table className="w-full text-left">
               <thead>
                  <tr className="bg-slate-100/50 border-b border-slate-100">
                     <th className="px-10 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Olay Tipi</th>
                     <th className="px-10 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Hasta / Randevu</th>
                     <th className="px-10 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Aksiyon / Timeline</th>
                     <th className="px-10 py-6 text-[10px] font-black text-[#07363c] uppercase tracking-widest">Finansal Değer</th>
                     <th className="px-10 py-6 text-right text-[10px] font-black text-[#07363c] uppercase tracking-widest">Kanıt</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                  {[
                    { type: 'NoShowPrevented', patient: 'Murat Yıldız', date: 'Dün 14:30', actions: ['T-24 SMS', 'Arama Görevi', 'Onay Alındı'], value: 1200 },
                    { type: 'SlotFilled', patient: 'Selin Araz', date: 'Bugün 11:00', actions: ['İptal Yakalandı', 'Waitlist Teklifi', 'Kabul'], value: 1000 },
                    { type: 'NoShowPrevented', patient: 'Esra Bilgiç', date: 'Yarın 09:15', actions: ['T-48 Risk Skoru: 92', 'VIP Teyit', 'Onay'], value: 1200 },
                  ].map((row, i) => (
                    <tr key={i} className="hover:bg-slate-50/80 transition-colors group">
                       <td className="px-10 py-6">
                          <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ${
                            row.type === 'NoShowPrevented' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-indigo-50 text-indigo-600 border-indigo-100'
                          }`}>
                            {row.type === 'NoShowPrevented' ? 'Kurtarılan No-Show' : 'Doldurulan Boşluk'}
                          </span>
                       </td>
                       <td className="px-10 py-6">
                          <p className="font-black text-[#07363c]">{row.patient}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase">{row.date}</p>
                       </td>
                       <td className="px-10 py-6">
                          <div className="flex items-center gap-2">
                             {row.actions.map((a, j) => (
                               <span key={j} className="text-[9px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md flex items-center gap-1 border border-slate-200">
                                 <CheckCircle2 size={10} className="text-emerald-500" /> {a}
                               </span>
                             ))}
                          </div>
                       </td>
                       <td className="px-10 py-6 font-black text-[#07363c]">
                          {row.value.toLocaleString()} ₺
                       </td>
                       <td className="px-10 py-6 text-right">
                          <button className="p-3 bg-white border border-slate-200 rounded-xl text-slate-300 hover:text-[#07363c] hover:border-[#07363c] opacity-0 group-hover:opacity-100 transition-all shadow-sm">
                             <FileText size={18} />
                          </button>
                       </td>
                    </tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>

      {/* Config Overlay - Only for Admins to justify ROI better */}
      {showConfig && (
        <div className="fixed inset-0 z-[120] bg-[#07363c]/90 backdrop-blur-xl flex items-center justify-center p-4" onClick={() => setShowConfig(false)}>
           <div className="bg-white w-full max-w-xl rounded-[48px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300" onClick={e => e.stopPropagation()}>
              <div className="p-10 bg-[#E4C19D] text-[#07363c]">
                 <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-white/20 rounded-2xl"><DollarSign size={24} /></div>
                    <button onClick={() => setShowConfig(false)} className="text-[#07363c]/40 hover:text-[#07363c]"><ChevronDown size={32} /></button>
                 </div>
                 <h2 className="text-3xl font-black tracking-tight">Finansal Değer Parametreleri</h2>
                 <p className="text-[#07363c]/60 font-bold text-sm uppercase tracking-widest mt-1">ROI Hesaplama Formülünü Belirleyin</p>
              </div>
              <div className="p-10 space-y-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Muayene Başına Ort. Gelir (₺)</label>
                    <input type="number" className="w-full p-5 bg-slate-50 border-2 border-transparent rounded-[24px] outline-none font-bold text-lg focus:bg-white focus:border-[#07363c] transition-all" defaultValue={1200} />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Önlenen Her No-Show'un Değeri (₺)</label>
                    <input type="number" className="w-full p-5 bg-slate-50 border-2 border-transparent rounded-[24px] outline-none font-bold text-lg focus:bg-white focus:border-[#07363c] transition-all" defaultValue={1200} />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Waitlist ile Dolan Slot Değeri (₺)</label>
                    <input type="number" className="w-full p-5 bg-slate-50 border-2 border-transparent rounded-[24px] outline-none font-bold text-lg focus:bg-white focus:border-[#07363c] transition-all" defaultValue={1000} />
                 </div>
                 <button onClick={() => setShowConfig(false)} className="w-full py-6 bg-[#07363c] text-white rounded-[32px] font-black uppercase text-xs tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-[1.02] transition-all mt-4">
                    Parametreleri Güncelle & ROI Yeniden Hesapla
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}
