
import React, { useEffect, useState } from 'react';
import { supabase, logAuditEvent } from '../supabase';
import { ClinicalNote, Appointment, ClinicalTemplate } from '../types';
import { 
  ClipboardList, Plus, Save, Search, User, FileText, 
  CheckSquare, ArrowRight, Sparkles, AlertCircle, Printer, Calendar, CreditCard, X
} from 'lucide-react';

export default function ClinicalNotes() {
  const [notes, setNotes] = useState<ClinicalNote[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [templates, setTemplates] = useState<ClinicalTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedApt, setSelectedApt] = useState<string>('');
  const [selectedTemplate, setSelectedTemplate] = useState<ClinicalTemplate | null>(null);
  const [formData, setFormData] = useState<any>({});
  const [showNextSteps, setShowNextSteps] = useState(false);
  const [lastSavedId, setLastSavedId] = useState<string | null>(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  async function fetchInitialData() {
    setLoading(true);
    const { data: notesData } = await supabase.from('clinical_notes').select('*, patient:patients(*)').order('created_at', { ascending: false });
    const { data: aptsData } = await supabase.from('appointments').select('*, patient:patients(*)').eq('status', 'Muayenede');
    
    // Mock Templates
    const mockTemplates: ClinicalTemplate[] = [
      {
        id: 'temp1',
        name: 'Genel Dahiliye Muayenesi',
        branch: 'İç Hastalıkları',
        fields: [
          { id: 'f1', label: 'Ateş / Nabız Stabil', type: 'checkbox', required: true },
          { id: 'f2', label: 'Akciğer Sesleri Doğal', type: 'checkbox', required: true },
          { id: 'f3', label: 'Karın Hassasiyeti', type: 'select', required: false, options: ['Yok', 'Hafif', 'Belirgin'] },
          { id: 'f4', label: 'Ek Notlar', type: 'textarea', required: false }
        ],
        next_steps: [
          { type: 'control', label: '15 Gün Sonra Kontrol Planla' },
          { type: 'billing', label: 'Kan Tahlili Ekle (Faturalama)' },
          { type: 'instruction', label: 'Beslenme Talimatı Yazdır' }
        ]
      },
      {
        id: 'temp2',
        name: 'Kardiyolojik Kontrol',
        branch: 'Kardiyoloji',
        fields: [
          { id: 'k1', label: 'Efor Testi Sonucu', type: 'select', required: true, options: ['Normal', 'Pozitif', 'Şüpheli'] },
          { id: 'k2', label: 'EKG Bulgusu', type: 'textarea', required: true },
          { id: 'k3', label: 'Ödem Kontrolü', type: 'checkbox', required: false }
        ],
        next_steps: [
          { type: 'billing', label: 'EKO Randevusu Al' },
          { type: 'control', label: 'Aylık Takip Planla' }
        ]
      }
    ];

    setNotes(notesData || []);
    setAppointments(aptsData || []);
    setTemplates(mockTemplates);
    setLoading(false);
  }

  const handleTemplateChange = (templateId: string) => {
    const template = templates.find(t => t.id === templateId) || null;
    setSelectedTemplate(template);
    setFormData({}); // Reset fields when template changes
  };

  const handleSaveNote = async () => {
    if (!selectedApt) return alert("Lütfen bir randevu seçin.");
    
    const apt = appointments.find(a => a.id === selectedApt);
    const noteData = {
      appointment_id: selectedApt,
      patient_id: apt?.patient_id,
      doctor_id: 'demo-doctor',
      template_id: selectedTemplate?.id,
      form_data: formData,
      complaint: formData.f4 || formData.k2 || 'Standart Şablon Girişi',
      diagnosis: 'ICD-10 Tanı Bekleniyor',
      created_at: new Date().toISOString()
    };

    const { data, error } = await supabase.from('clinical_notes').insert([noteData]).select();
    if (!error) {
      await logAuditEvent('INSERT', 'clinical_note', data[0].id, noteData);
      setLastSavedId(data[0].id);
      setShowNextSteps(true);
      fetchInitialData();
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Klinik Standardizasyon</h1>
          <p className="text-slate-500 font-medium italic flex items-center gap-2">
            <Sparkles size={16} className="text-[#E4C19D]" /> 
            Hızlı Dokümantasyon & Prosedür Uyumu
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Input Column */}
        <div className="lg:col-span-2 space-y-8">
           <div className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm space-y-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Aktif Randevu</label>
                    <select 
                       className="w-full p-5 rounded-[24px] bg-slate-50 border-2 border-transparent outline-none font-bold text-[#07363c] focus:bg-white focus:border-[#07363c] transition-all"
                       value={selectedApt}
                       onChange={(e) => setSelectedApt(e.target.value)}
                    >
                       <option value="">İçerideki Hastayı Seçin...</option>
                       {appointments.map(a => (
                         <option key={a.id} value={a.id}>{a.patient?.first_name} {a.patient?.last_name}</option>
                       ))}
                    </select>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Muayene Şablonu</label>
                    <select 
                       className="w-full p-5 rounded-[24px] bg-slate-50 border-2 border-transparent outline-none font-bold text-[#07363c] focus:bg-white focus:border-[#07363c] transition-all"
                       onChange={(e) => handleTemplateChange(e.target.value)}
                    >
                       <option value="">Şablon Seçiniz (Opsiyonel)...</option>
                       {templates.map(t => (
                         <option key={t.id} value={t.id}>{t.name}</option>
                       ))}
                    </select>
                 </div>
              </div>

              {selectedTemplate ? (
                <div className="space-y-8 animate-in slide-in-from-top-4 duration-300">
                   <div className="flex items-center gap-3 text-indigo-600 bg-indigo-50 px-6 py-4 rounded-3xl border border-indigo-100">
                      <FileText size={20} />
                      <span className="text-xs font-black uppercase tracking-widest">{selectedTemplate.name} Uygulanıyor</span>
                   </div>
                   
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                      {selectedTemplate.fields.map(field => (
                        <div key={field.id} className="space-y-3">
                           <div className="flex items-center justify-between px-2">
                              <label className="text-sm font-bold text-slate-700">{field.label}</label>
                              {field.required && <span className="text-[9px] font-black text-rose-500 uppercase tracking-widest">Zorunlu</span>}
                           </div>
                           
                           {field.type === 'checkbox' && (
                             <button 
                                onClick={() => setFormData({...formData, [field.id]: !formData[field.id]})}
                                className={`w-full p-5 rounded-2xl border-2 flex items-center justify-between transition-all ${formData[field.id] ? 'bg-[#07363c] border-[#07363c] text-white' : 'bg-slate-50 border-transparent text-slate-400'}`}
                             >
                                <span className="font-bold text-sm">{formData[field.id] ? 'Evet / Pozitif' : 'İşaretle'}</span>
                                <CheckSquare size={20} />
                             </button>
                           )}

                           {field.type === 'select' && (
                             <select 
                                className="w-full p-5 rounded-2xl bg-slate-50 border-2 border-transparent outline-none font-bold text-slate-700 focus:bg-white focus:border-[#07363c] transition-all"
                                onChange={(e) => setFormData({...formData, [field.id]: e.target.value})}
                             >
                                <option value="">Seçiniz...</option>
                                {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                             </select>
                           )}

                           {field.type === 'textarea' && (
                             <textarea 
                                className="w-full p-5 rounded-2xl bg-slate-50 border-2 border-transparent outline-none font-bold text-slate-700 focus:bg-white focus:border-[#07363c] transition-all min-h-[120px]"
                                placeholder="Detayları buraya girin..."
                                onChange={(e) => setFormData({...formData, [field.id]: e.target.value})}
                             />
                           )}
                        </div>
                      ))}
                   </div>

                   <div className="pt-6">
                      <button 
                        onClick={handleSaveNote}
                        className="w-full py-6 bg-[#07363c] text-white rounded-[32px] font-black uppercase text-xs tracking-[0.2em] shadow-2xl shadow-[#07363c]/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3"
                      >
                         Muayene Notunu Kaydet & Bitir <ArrowRight size={20} />
                      </button>
                   </div>
                </div>
              ) : (
                <div className="py-20 border-4 border-dashed border-slate-100 rounded-[40px] flex flex-col items-center justify-center text-slate-300 gap-6">
                   <ClipboardList size={64} className="opacity-10" />
                   <p className="font-black text-xl text-slate-400">Veri Girişi İçin Şablon Seçin</p>
                </div>
              )}
           </div>
        </div>

        {/* Sidebar History Column */}
        <div className="space-y-6">
           <h2 className="text-xl font-black text-[#07363c] px-4">Son Muayene Notları</h2>
           <div className="space-y-4">
              {notes.slice(0, 5).map(note => (
                <div key={note.id} className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm hover:shadow-xl transition-all group cursor-pointer">
                   <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                         <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center group-hover:bg-[#E4C19D] transition-colors"><User size={20}/></div>
                         <div>
                            <p className="font-black text-[#07363c] text-sm">{note.patient?.first_name} {note.patient?.last_name}</p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{new Date(note.created_at).toLocaleDateString('tr-TR')}</p>
                         </div>
                      </div>
                   </div>
                   <p className="text-xs text-slate-500 font-medium leading-relaxed line-clamp-2 italic">"{note.complaint}"</p>
                </div>
              ))}
           </div>
           <button className="w-full py-5 border-2 border-dashed border-slate-200 rounded-[32px] text-slate-400 font-black uppercase text-[10px] tracking-widest hover:border-[#07363c] hover:text-[#07363c] transition-all">Tüm Arşivi Gör</button>
        </div>
      </div>

      {/* Next Steps Recommendation Modal */}
      {showNextSteps && (
        <div className="fixed inset-0 z-[110] bg-[#07363c]/90 backdrop-blur-xl flex items-center justify-center p-4">
           <div className="bg-white w-full max-w-2xl rounded-[48px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-10 bg-indigo-600 text-white relative">
                 <Sparkles className="absolute -right-10 -top-10 w-64 h-64 opacity-10 rotate-12" />
                 <div className="flex justify-between items-start mb-6">
                    <div className="p-3 bg-white/20 rounded-2xl"><Sparkles size={28} fill="currentColor" /></div>
                    <button onClick={() => setShowNextSteps(false)} className="text-white/40 hover:text-white transition-colors"><X size={32} /></button>
                 </div>
                 <h2 className="text-4xl font-black tracking-tighter mb-2">Kayıt Başarılı!</h2>
                 <p className="text-indigo-100 font-bold text-lg">Bu muayene için sistemin önerdiği sonraki adımlar:</p>
              </div>

              <div className="p-10 space-y-4">
                 {selectedTemplate?.next_steps?.map((step, i) => (
                   <button 
                      key={i} 
                      onClick={() => { alert(`${step.label} işlemi başlatıldı.`); setShowNextSteps(false); }}
                      className="w-full flex items-center justify-between p-6 rounded-[28px] border-2 border-slate-100 hover:border-indigo-600 hover:bg-indigo-50 group transition-all text-left"
                   >
                      <div className="flex items-center gap-5">
                         <div className="p-4 bg-slate-50 rounded-2xl group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                            {step.type === 'control' ? <Calendar size={24}/> : step.type === 'billing' ? <CreditCard size={24}/> : <Printer size={24}/>}
                         </div>
                         <span className="font-black text-[#07363c] text-lg">{step.label}</span>
                      </div>
                      <ArrowRight size={24} className="text-slate-200 group-hover:text-indigo-600 transition-colors" />
                   </button>
                 ))}
                 
                 <div className="pt-8 flex flex-col gap-3">
                    <button onClick={() => setShowNextSteps(false)} className="w-full py-5 bg-[#07363c] text-white rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl">Başka İşlem Yok, Muayeneyi Kapat</button>
                    <button onClick={() => setShowNextSteps(false)} className="w-full py-3 text-slate-400 font-bold text-[10px] uppercase tracking-widest hover:text-rose-500 transition-colors">Kritik Hata Bildir</button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}
