
import React from 'react';
import { 
  TrendingDown, TrendingUp, Users, Target, 
  BarChart2, MousePointer2, RefreshCw, Zap
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Cell, PieChart, Pie
} from 'recharts';

export default function NoShowDashboard() {
  const funnelData = [
    { name: 'Planlanan', value: 120, color: '#07363c' },
    { name: 'Onaylanan', value: 98, color: '#E4C19D' },
    { name: 'Gelen', value: 92, color: '#10b981' },
    { name: 'Geri Kazanılan', value: 4, color: '#f59e0b' }
  ];

  const recoveryData = [
    { name: 'Başarılı', value: 65, fill: '#10b981' },
    { name: 'Beklemede', value: 25, fill: '#cbd5e1' },
    { name: 'Kayıp', value: 10, fill: '#ef4444' }
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">No-Show Analiz & Optimizasyon</h1>
          <p className="text-slate-500 font-medium">Gelir kaybını önleme ve hasta geri kazanım metrikleri.</p>
        </div>
        <div className="flex items-center gap-3 bg-white p-2 rounded-2xl shadow-sm border border-slate-100">
           <div className="px-4 py-2 bg-[#E4C19D]/10 text-[#07363c] rounded-xl text-xs font-black uppercase">T-24 Onay: %82</div>
           <div className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-xs font-black uppercase">No-Show: %6.2</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-[#07363c] p-8 rounded-[40px] text-white relative overflow-hidden group">
           <Target className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10 group-hover:scale-110 transition-transform" />
           <p className="text-[10px] font-black uppercase tracking-[0.2em] mb-2 text-white/50">Hedef No-Show</p>
           <p className="text-4xl font-black tracking-tighter">&lt; %3.0</p>
           <div className="mt-4 flex items-center gap-2 text-emerald-400 text-xs font-bold">
              <TrendingDown size={16} /> Geçen aya göre -%1.4 iyileşme
           </div>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm">
           <p className="text-[10px] font-black uppercase tracking-[0.2em] mb-2 text-slate-400">Geri Kazanım</p>
           <p className="text-4xl font-black tracking-tighter text-[#07363c]">%18</p>
           <p className="text-xs font-medium text-slate-500 mt-2">No-show sonrası 24 saatte re-book.</p>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm">
           <p className="text-[10px] font-black uppercase tracking-[0.2em] mb-2 text-slate-400">Otomatik Onay</p>
           <p className="text-4xl font-black tracking-tighter text-[#07363c]">%64</p>
           <p className="text-xs font-medium text-slate-500 mt-2">Personel müdahalesi olmadan.</p>
        </div>
        <div className="bg-[#E4C19D] p-8 rounded-[40px] text-[#07363c] relative overflow-hidden group">
           <Zap className="absolute -right-6 -bottom-6 w-32 h-32 opacity-20 group-hover:scale-110 transition-transform" />
           <p className="text-[10px] font-black uppercase tracking-[0.2em] mb-2 text-[#07363c]/50">Korunan Gelir</p>
           <p className="text-3xl font-black tracking-tighter">18.400 ₺</p>
           <p className="text-xs font-bold mt-2">Doluluk optimizasyonuyla.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm">
           <h3 className="text-2xl font-black text-[#07363c] mb-8">Randevu Dönüşüm Hunisi</h3>
           <div className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={funnelData} layout="vertical" margin={{ left: 20 }}>
                   <XAxis type="number" hide />
                   <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 800, fill: '#07363c' }} />
                   <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '16px', border: 'none', fontWeight: 'bold' }} />
                   <Bar dataKey="value" radius={[0, 20, 20, 0]} barSize={40}>
                      {funnelData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                   </Bar>
                </BarChart>
              </ResponsiveContainer>
           </div>
           <div className="grid grid-cols-4 gap-4 mt-8 border-t pt-8">
              {funnelData.map((d, i) => (
                <div key={i} className="text-center">
                   <p className="text-[9px] font-black text-slate-400 uppercase mb-1">{d.name}</p>
                   <p className="text-xl font-black text-[#07363c]">{d.value}</p>
                </div>
              ))}
           </div>
        </div>

        <div className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm flex flex-col items-center">
           <h3 className="text-2xl font-black text-[#07363c] mb-10 w-full text-center">Geri Kazanım Performansı</h3>
           <div className="h-[250px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                   <Pie data={recoveryData} innerRadius={75} outerRadius={95} paddingAngle={8} dataKey="value">
                      {recoveryData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
                   </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                 <span className="text-3xl font-black text-[#07363c]">%65</span>
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Başarı Oranı</span>
              </div>
           </div>
           <div className="space-y-3 w-full mt-10">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                 <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                    <span className="text-xs font-bold text-slate-600 uppercase">Kazanılan Randevu</span>
                 </div>
                 <span className="font-black text-[#07363c]">12 Randevu</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                 <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                    <span className="text-xs font-bold text-slate-600 uppercase">Kalıcı Kayıp</span>
                 </div>
                 <span className="font-black text-[#07363c]">4 Randevu</span>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
