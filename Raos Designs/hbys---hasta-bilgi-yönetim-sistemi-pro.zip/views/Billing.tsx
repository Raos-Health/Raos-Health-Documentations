
import React, { useEffect, useState } from 'react';
import { supabase } from '../supabase';
import { Invoice } from '../types';
import { 
  CreditCard, 
  Search, 
  Plus, 
  Download, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  FileText
} from 'lucide-react';

export default function Billing() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInvoices();
  }, []);

  async function fetchInvoices() {
    setLoading(true);
    const { data, error } = await supabase
      .from('invoices')
      .select('*, patient:patients(*)')
      .order('created_at', { ascending: false });
    
    if (data) setInvoices(data);
    setLoading(false);
  }

  const getStatusStyle = (status: string) => {
    switch(status) {
      case 'ÖDENDİ': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'ÖDENMEDİ': return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'KISMİ': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  const handleNewInvoice = () => alert("Yeni fatura oluşturma sihirbazı açılıyor...");
  const handleExportExcel = () => alert("Finansal rapor Excel olarak hazırlandı.");

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-[#07363c] tracking-tight">Faturalama & Ödemeler</h1>
          <p className="text-slate-500 font-medium">Mali kayıtları ve tahsilatları merkezden yönetin.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={handleNewInvoice} className="flex items-center gap-2 bg-[#07363c] text-white px-6 py-4 rounded-2xl text-sm font-black uppercase tracking-widest hover:scale-105 transition-all shadow-xl shadow-[#07363c]/20">
            <Plus size={18} /> Hızlı Fatura (F)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-emerald-600 p-8 rounded-[32px] text-white shadow-2xl shadow-emerald-600/20 card-hover group overflow-hidden relative">
          <CheckCircle2 size={120} className="absolute -right-10 -bottom-10 opacity-10 group-hover:scale-110 transition-transform" />
          <p className="text-emerald-100 text-[10px] font-black uppercase tracking-widest mb-1">Toplam Tahsilat</p>
          <p className="text-4xl font-black mt-1">142.500 ₺</p>
          <span className="inline-block mt-4 text-[9px] font-black bg-white/20 px-3 py-1 rounded-full uppercase tracking-widest">Aylık Performans</span>
        </div>
        <div className="bg-rose-600 p-8 rounded-[32px] text-white shadow-2xl shadow-rose-600/20 card-hover group overflow-hidden relative">
          <Clock size={120} className="absolute -right-10 -bottom-10 opacity-10 group-hover:scale-110 transition-transform" />
          <p className="text-rose-100 text-[10px] font-black uppercase tracking-widest mb-1">Toplam Alacak</p>
          <p className="text-4xl font-black mt-1">28.450 ₺</p>
          <span className="inline-block mt-4 text-[9px] font-black bg-white/20 px-3 py-1 rounded-full uppercase tracking-widest">Bekleyen Tahsilat</span>
        </div>
        <div className="bg-indigo-600 p-8 rounded-[32px] text-white shadow-2xl shadow-indigo-600/20 card-hover group overflow-hidden relative">
          <FileText size={120} className="absolute -right-10 -bottom-10 opacity-10 group-hover:scale-110 transition-transform" />
          <p className="text-indigo-100 text-[10px] font-black uppercase tracking-widest mb-1">Fatura Sayısı</p>
          <p className="text-4xl font-black mt-1">12 Adet</p>
          <span className="inline-block mt-4 text-[9px] font-black bg-white/20 px-3 py-1 rounded-full uppercase tracking-widest">Bugünkü Kayıtlar</span>
        </div>
      </div>

      <div className="bg-white rounded-[40px] border-2 border-slate-100 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex flex-col md:flex-row gap-6">
          <div className="relative flex-1 group">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#07363c]" />
            <input 
              type="text" 
              placeholder="Fatura No veya Hasta Adı..."
              className="w-full pl-12 pr-6 py-4 rounded-2xl border-2 border-transparent focus:bg-white focus:border-[#07363c] bg-white outline-none text-sm font-bold transition-all shadow-inner"
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-6 py-4 text-xs font-black uppercase tracking-widest text-slate-600 bg-white border-2 border-slate-200 rounded-2xl hover:border-[#07363c] transition-all"><Filter size={18} /> Filtrele</button>
            <button onClick={handleExportExcel} className="flex items-center gap-2 px-6 py-4 text-xs font-black uppercase tracking-widest text-[#07363c] bg-white border-2 border-slate-200 rounded-2xl hover:border-[#07363c] transition-all"><Download size={18} /> Excel</button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Fatura No</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Hasta</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Tarih</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Tutar</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Durum</th>
                <th className="px-8 py-6 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-bold">
              {loading ? (
                Array(5).fill(0).map((_, i) => <tr key={i} className="h-20 animate-pulse"><td colSpan={6} className="bg-slate-50/10 px-8"></td></tr>)
              ) : invoices.length === 0 ? (
                <tr><td colSpan={6} className="px-8 py-12 text-center text-slate-400 font-medium italic">Henüz fatura kaydı bulunmuyor.</td></tr>
              ) : invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors group">
                  <td className="px-8 py-6 font-mono text-xs font-black text-indigo-600">#INV-{inv.id.substring(0, 6).toUpperCase()}</td>
                  <td className="px-8 py-6">
                    <p className="text-sm text-[#07363c]">{inv.patient?.first_name} {inv.patient?.last_name}</p>
                    <p className="text-[10px] text-slate-400 uppercase">{inv.patient?.tc_no}</p>
                  </td>
                  <td className="px-8 py-6 text-xs text-slate-500 tracking-tight">{new Date(inv.created_at).toLocaleDateString('tr-TR')}</td>
                  <td className="px-8 py-6 text-sm font-black text-[#07363c]">{inv.total_amount.toLocaleString('tr-TR')} ₺</td>
                  <td className="px-8 py-6">
                    <span className={`px-3 py-1 rounded-xl text-[10px] font-black border uppercase tracking-widest ${getStatusStyle(inv.status)}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <button onClick={() => alert("Fatura PDF olarak indiriliyor.")} className="text-[#07363c] hover:bg-[#E4C19D]/20 p-3 rounded-2xl transition-all" title="Faturayı İndir">
                      <Download size={20} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
