
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, Cell, LineChart, Line, Legend
} from 'recharts';
import { 
  Timer, Users, Zap, TrendingDown, Clock, 
  ChevronRight, Calendar, Filter, Download, ArrowUpRight
} from 'lucide-react';

export default function WaitingAnalytics() {
  const hourlyData = [
    { hour: '08:00', wait: 5, capacity: 10 },
    { hour: '09:00', wait: 12, capacity: 15 },
    { hour: '10:00', wait: 28, capacity: 20 },
    { hour: '11:00', wait: 35, capacity: 20 },
    { hour: '12:00', wait: 15, capacity: 10 },
    { hour: '13:00', wait: 8, capacity: 15 },
    { hour: '14:00', wait: 22, capacity: 20 },
    { hour: '15:00', wait: 14, capacity: 18 },
  ];

  const doctorPerformance = [
    { name: 'Dr. Selim', avg: 12, max: 20 },
    { name: 'Dr. Ahmet', avg: 18, max: 45 },
    { name: 'Dr. Canan', avg: 10, max: 15 },
    { name: 'Dr. Elif', avg: 22, max: 50 },
    { name: 'Dr. Murat', avg: 14, max: 25 },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Bekleme & Verimlilik Analizi</h1>
          <p className="text-slate-500 font-medium">Hizmet kalitesini artırın ve dar boğazları giderin.</p>
        </div>
        <div className="flex gap-3">
           <button className="px-6 py-4 bg-white border border-slate-200 text-[#07363c] rounded-2xl text-xs font-black uppercase tracking-widest shadow-sm hover:shadow-md transition-all flex items-center gap-2">
              <Download size={18} /> Rapor İndir
           </button>
           <button className="px-6 py-4 bg-[#07363c] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-[#07363c]/20 flex items-center gap-2">
              <Filter size={18} /> Filtrele
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
         <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm flex flex-col justify-between">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Ort. Bekleme</p>
            <div className="flex items-baseline gap-2">
               <span className="text-4xl font-black text-[#07363c]">14.2</span>
               <span className="text-xs font-bold text-slate-500">DK</span>
            </div>
            <p className="mt-4 text-emerald-500 text-[10px] font-black flex items-center gap-1">
               <TrendingDown size={14} /> %8 İyileşme
            </p>
         </div>
         <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm flex flex-col justify-between">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Max Bekleme</p>
            <div className="flex items-baseline gap-2">
               <span className="text-4xl font-black text-rose-600">52</span>
               <span className="text-xs font-bold text-slate-500">DK</span>
            </div>
            <p className="mt-4 text-slate-400 text-[10px] font-black">Pik Saat: 11:30</p>
         </div>
         <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm flex flex-col justify-between">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">SLA Başarısı</p>
            <div className="flex items-baseline gap-2">
               <span className="text-4xl font-black text-[#07363c]">%94</span>
            </div>
            <p className="mt-4 text-indigo-500 text-[10px] font-black uppercase tracking-widest">Hedef Üstü</p>
         </div>
         <div className="bg-[#E4C19D] p-8 rounded-[40px] text-[#07363c] shadow-2xl shadow-[#E4C19D]/20 flex flex-col justify-between">
            <p className="text-[#07363c]/50 text-[10px] font-black uppercase tracking-widest mb-1">Tahmini Memnuniyet</p>
            <div className="flex items-baseline gap-2">
               <span className="text-4xl font-black">4.8</span>
               <span className="text-xs font-bold opacity-60">/ 5.0</span>
            </div>
            <p className="mt-4 text-[10px] font-black uppercase tracking-widest">Canlı Skor</p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <div className="lg:col-span-2 bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm space-y-10">
            <div className="flex items-center justify-between">
               <h3 className="text-2xl font-black text-[#07363c] flex items-center gap-3"><Clock size={24} className="text-[#E4C19D]" /> Saatlik Bekleme Yoğunluğu</h3>
               <div className="flex gap-2">
                  <span className="flex items-center gap-1 text-[10px] font-black text-slate-400 uppercase tracking-widest"><div className="w-2 h-2 rounded-full bg-indigo-600"></div> Bekleme</span>
               </div>
            </div>
            <div className="h-[350px]">
               <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={hourlyData}>
                     <defs>
                        <linearGradient id="colorWait" x1="0" y1="0" x2="0" y2="1">
                           <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                           <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                        </linearGradient>
                     </defs>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                     <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#07363c' }} />
                     <YAxis hide />
                     <Tooltip contentStyle={{ borderRadius: '16px', border: 'none', fontWeight: 'bold' }} />
                     <Area type="monotone" dataKey="wait" stroke="#6366f1" strokeWidth={4} fillOpacity={1} fill="url(#colorWait)" />
                     <Area type="monotone" dataKey="capacity" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" fillOpacity={0} />
                  </AreaChart>
               </ResponsiveContainer>
            </div>
         </div>

         <div className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm space-y-10">
            <h3 className="text-2xl font-black text-[#07363c]">Dar Boğaz Analizi</h3>
            <div className="space-y-6">
               {doctorPerformance.map((dr, i) => (
                 <div key={i} className="space-y-2 group">
                    <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-widest">
                       <span>{dr.name}</span>
                       <span className={dr.avg > 15 ? 'text-rose-600' : 'text-[#07363c]'}>{dr.avg} DK Ort.</span>
                    </div>
                    <div className="h-3 bg-slate-100 rounded-full overflow-hidden flex">
                       <div 
                        className={`h-full rounded-full transition-all duration-1000 delay-${i*100} ${dr.avg > 15 ? 'bg-rose-500' : 'bg-[#07363c]'}`}
                        style={{ width: `${(dr.avg / 30) * 100}%` }}
                       ></div>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-black text-slate-400 uppercase">
                       <span>SLA Uyumu: %{100 - (dr.avg > 15 ? 15 : 5)}</span>
                       <span className="flex items-center gap-1">Pik Gecikme: {dr.max}dk</span>
                    </div>
                 </div>
               ))}
            </div>
            <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-100">
               <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                  <Zap size={14} className="text-[#E4C19D]" /> Sistem Önerisi
               </h4>
               <p className="text-xs font-medium text-slate-600 leading-relaxed">
                  Öğle saatlerinde (11:00-12:00) Kardiyoloji birimine 1 ek kayıt görevlisi atamak bekleme sürelerini <b>%22</b> düşürebilir.
               </p>
            </div>
         </div>
      </div>
    </div>
  );
}
