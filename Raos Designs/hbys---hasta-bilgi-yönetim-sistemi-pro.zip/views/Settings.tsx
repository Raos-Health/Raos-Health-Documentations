
import React, { useState, useEffect } from 'react';
import { Hospital, Shield, Bell, Eye, Save, Type, Volume2, Moon, Sun } from 'lucide-react';

export default function SettingsView() {
  const [activeTab, setActiveTab] = useState<'general' | 'security' | 'accessibility'>('general');
  const [loading, setLoading] = useState(false);
  
  // Accessibility States
  const [highContrast, setHighContrast] = useState(false);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [audioFeedback, setAudioFeedback] = useState(true);

  useEffect(() => {
    // Body sınıflarını güncelle
    document.body.classList.toggle('high-contrast', highContrast);
    document.body.classList.remove('font-large', 'font-xlarge');
    if (fontSize === 'large') document.body.classList.add('font-large');
    if (fontSize === 'xlarge') document.body.classList.add('font-xlarge');
  }, [highContrast, fontSize]);

  const handleSave = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      alert("Tüm tercihleriniz güvenle buluta kaydedildi.");
    }, 1000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-10 animate-in fade-in duration-500 pb-20">
      <div>
        <h1 className="text-3xl font-black text-[#07363c] tracking-tight">Sistem & Kişiselleştirme</h1>
        <p className="text-slate-500 font-medium">HBYS Pro deneyiminizi ihtiyacınıza göre optimize edin.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
        {/* Sidebar Nav */}
        <div className="md:col-span-1 space-y-3">
          {[
            { id: 'general', label: 'Genel Bilgiler', icon: Hospital },
            { id: 'security', label: 'Güvenlik', icon: Shield },
            { id: 'accessibility', label: 'Erişilebilirlik', icon: Eye },
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full text-left px-6 py-4 rounded-2xl font-bold flex items-center gap-3 transition-all ${
                activeTab === tab.id 
                ? 'bg-[#07363c] text-white shadow-xl scale-[1.02]' 
                : 'text-slate-500 hover:bg-white hover:text-[#07363c] border-2 border-transparent hover:border-slate-100'
              }`}
            >
              <tab.icon size={20}/> {tab.label}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="md:col-span-3 bg-white p-10 rounded-[48px] border-2 border-slate-100 shadow-sm space-y-10">
          {activeTab === 'general' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
              <h2 className="text-2xl font-black text-[#07363c] border-b pb-4">Hastane Bilgileri</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Kurum Adı</label>
                  <input className="w-full p-5 rounded-2xl bg-slate-50 border-2 border-transparent focus:border-[#07363c] outline-none font-bold" defaultValue="Özel HBYS Pro Polikliniği" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Vergi No</label>
                  <input className="w-full p-5 rounded-2xl bg-slate-50 border-2 border-transparent focus:border-[#07363c] outline-none font-bold" defaultValue="TR-9876543210" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'accessibility' && (
            <div className="space-y-10 animate-in slide-in-from-right-4 duration-300">
              <h2 className="text-2xl font-black text-[#07363c] border-b pb-4">Erişilebilirlik & Görünüm</h2>
              
              <div className="space-y-6">
                {/* Contrast Toggle */}
                <div className="flex items-center justify-between p-6 bg-slate-50 rounded-[32px] border-2 border-transparent hover:border-[#E4C19D] transition-all">
                  <div className="flex items-center gap-5">
                    <div className="p-4 bg-white rounded-2xl text-[#07363c] shadow-sm"><Eye size={24}/></div>
                    <div>
                      <p className="font-black text-[#07363c]">Yüksek Kontrast Modu</p>
                      <p className="text-xs font-medium text-slate-500">Metin ve butonların görünürlüğünü maksimize eder.</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setHighContrast(!highContrast)}
                    className={`w-14 h-8 rounded-full p-1 transition-all ${highContrast ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`w-6 h-6 bg-white rounded-full shadow-sm transform transition-all ${highContrast ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </button>
                </div>

                {/* Font Size Picker */}
                <div className="flex items-center justify-between p-6 bg-slate-50 rounded-[32px]">
                  <div className="flex items-center gap-5">
                    <div className="p-4 bg-white rounded-2xl text-[#07363c] shadow-sm"><Type size={24}/></div>
                    <div>
                      <p className="font-black text-[#07363c]">Font Ölçeği</p>
                      <p className="text-xs font-medium text-slate-500">Tüm arayüz metinlerinin boyutunu değiştirin.</p>
                    </div>
                  </div>
                  <div className="flex gap-2 p-1 bg-white rounded-2xl border border-slate-100">
                    {['normal', 'large', 'xlarge'].map(size => (
                      <button 
                        key={size}
                        onClick={() => setFontSize(size as any)}
                        className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${fontSize === size ? 'bg-[#07363c] text-white shadow-lg' : 'text-slate-400 hover:text-[#07363c]'}`}
                      >
                        {size === 'normal' ? 'Std' : size === 'large' ? 'Büyük' : 'Makro'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Audio Feedback */}
                <div className="flex items-center justify-between p-6 bg-slate-50 rounded-[32px]">
                  <div className="flex items-center gap-5">
                    <div className="p-4 bg-white rounded-2xl text-[#07363c] shadow-sm"><Volume2 size={24}/></div>
                    <div>
                      <p className="font-black text-[#07363c]">Sesli Bildirimler</p>
                      <p className="text-xs font-medium text-slate-500">Kritik işlemlerde sesli uyarı verilsin.</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setAudioFeedback(!audioFeedback)}
                    className={`w-14 h-8 rounded-full p-1 transition-all ${audioFeedback ? 'bg-indigo-600' : 'bg-slate-300'}`}
                  >
                    <div className={`w-6 h-6 bg-white rounded-full shadow-sm transform transition-all ${audioFeedback ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300 text-center py-16">
               <Shield size={80} className="mx-auto text-indigo-100 mb-4" />
               <p className="font-black text-[#07363c] text-xl">Güvenlik Merkezi</p>
               <p className="text-sm text-slate-500 max-w-sm mx-auto font-medium">İki faktörlü doğrulama ve IP kısıtlama ayarları BT departmanı tarafından yönetilir.</p>
            </div>
          )}

          <div className="pt-10 border-t flex justify-end">
            <button 
              onClick={handleSave}
              disabled={loading}
              className="px-12 py-5 bg-[#07363c] text-white font-black rounded-3xl hover:scale-[1.02] shadow-2xl shadow-[#07363c]/30 flex items-center gap-3 transition-all disabled:opacity-50"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <Save size={20}/>}
              Tüm Ayarları Kaydet
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
