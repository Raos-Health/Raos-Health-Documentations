
import React, { useState } from 'react';
import { 
  TrendingUp, TrendingDown, DollarSign, Zap, 
  ShieldCheck, FileText, Download, Calendar, 
  ArrowUpRight, Clock, Users, CheckCircle2,
  Sparkles, Info, ArrowRight
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, Cell, AreaChart, Area 
} from 'recharts';

const ROIMetricCard = ({ title, value, impact, description, icon: Icon, trend }: any) => (
  <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm hover:shadow-xl transition-all group overflow-hidden relative card-hover">
    <div className="absolute -right-4 -top-4 w-32 h-32 bg-slate-50 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-500"></div>
    <div className="flex justify-between items-start relative z-10 mb-6">
      <div className="p-4 bg-[#07363c] bg-opacity-10 rounded-2xl text-[#07363c]">
        <Icon size={24} />
      </div>
      <div className={`flex items-center gap-1 text-[10px] font-black px-2 py-1 rounded-full ${trend > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'} uppercase tracking-widest`}>
        {trend > 0 ? <ArrowUpRight size={14} /> : <TrendingDown size={14} />}
        {Math.abs(trend)}%
      </div>
    </div>
    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1 relative z-10">{title}</p>
    <div className="flex items-baseline gap-2 mb-2 relative z-10">
      <span className="text-3xl font-black text-[#07363c] tracking-tight">{value}</span>
    </div>
    <p className="text-xl font-black text-emerald-600 mb-4 relative z-10">+{impact.toLocaleString()} ₺ <span className="text-[10px] text-slate-400 uppercase font-black tracking-widest">Ek Gelir</span></p>
    <p className="text-xs text-slate-500 font-medium leading-relaxed relative z-10">{description}</p>
  </div>
);

export default function ROIAnalytics() {
  const [isExporting, setIsExporting] = useState(false);

  const chartData = [
    { name: 'Ocak', eski: 45000, yeni: 58000 },
    { name: 'Şubat', eski: 42000, yeni: 62000 },
    { name: 'Mart', eski: 48000, yeni: 75000 },
    { name: 'Nisan', eski: 51000, yeni: 84000 },
  ];

  const handleExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      alert("ROI Yönetim Özeti PDF olarak indirildi. Vercel üzerinde tüm özellikler aktif.");
    }, 1500);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="px-3 py-1 bg-emerald-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20">ROI Raporu</div>
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest italic">Yatırımın Geri Dönüş Analizi</span>
          </div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Finansal Kazanım Paneli</h1>
          <p className="text-slate-500 font-medium">STH Pro ile hastanenizin finansal sağlığını koruyun.</p>
        </div>
        <div className="flex items-center gap-4 bg-white p-2 rounded-[28px] border-2 border-slate-100 shadow-sm">
           <button 
            onClick={handleExport}
            disabled={isExporting}
            className="px-8 py-4 bg-[#07363c] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-105 transition-all flex items-center gap-3 disabled:opacity-50"
           >
              {isExporting ? <Zap className="animate-spin" size={18} /> : <Download size={18} />} 
              Yönetim Raporu Al (PDF)
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ROIMetricCard 
          title="Prevented No-Shows" value="42 Vaka" impact={50400} trend={18} icon={ShieldCheck}
          description="Otomatik hatırlatıcılar ve teyit aramalarıyla iptalden dönen randevular."
        />
        <ROIMetricCard 
          title="Gap-Fill Revenue" value="28 Slot" impact={33600} trend={12} icon={Zap}
          description="Akıllı bekleme listesi yönetimiyle doldurulan iptal edilmiş muayene saatleri."
        />
        <ROIMetricCard 
          title="Leakage Recovery" value="12 Temsil" impact={15000} trend={24} icon={DollarSign}
          description="Sızıntı tespit motoruyla yakalanan faturasız veya eksik tahsilatlı vakalar."
        />
        <ROIMetricCard 
          title="Efficiency Gain" value="142 Saat" impact={28400} trend={-30} icon={Clock}
          description="Doktor dokümantasyon ve personel operasyonel sürelerindeki net tasarruf."
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 bg-white p-10 rounded-[48px] border-2 border-slate-100 shadow-sm space-y-10">
           <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-black text-[#07363c] flex items-center gap-3">Kümülatif Gelir Artışı</h3>
                <p className="text-slate-400 text-[10px] font-black uppercase mt-1 italic tracking-widest">Baseline vs. STH Pro Performansı</p>
              </div>
              <div className="flex gap-4">
                 <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-slate-300"></div>
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Eski Düzen</span>
                 </div>
                 <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-[#10b981]"></div>
                    <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">STH Pro</span>
                 </div>
              </div>
           </div>
           <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                   <defs>
                      <linearGradient id="colorCurrent" x1="0" y1="0" x2="0" y2="1">
                         <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                         <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                   </defs>
                   <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                   <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#07363c' }} />
                   <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#07363c' }} tickFormatter={(val) => `${val/1000}k`} />
                   <Tooltip 
                    contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                    formatter={(value: any) => [`${value.toLocaleString()} ₺`, '']}
                   />
                   <Area type="monotone" dataKey="yeni" stroke="#10b981" strokeWidth={6} fillOpacity={1} fill="url(#colorCurrent)" />
                   <Area type="monotone" dataKey="eski" stroke="#cbd5e1" strokeWidth={3} strokeDasharray="12 12" fill="transparent" />
                </AreaChart>
              </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-[#07363c] p-10 rounded-[48px] text-white flex flex-col h-full relative overflow-hidden shadow-2xl">
           <Sparkles size={200} className="absolute -right-20 -bottom-20 opacity-[0.03] group-hover:rotate-12 transition-transform duration-1000" />
           <div className="relative z-10 mb-10">
              <h3 className="text-2xl font-black mb-2 flex items-center gap-3">
                 <Sparkles className="text-[#E4C19D]" size={28} /> Akıllı Verimlilik
              </h3>
              <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.2em]">YAPAY ZEKA ÖZETİ</p>
           </div>
           
           <div className="space-y-8 flex-1 relative z-10">
              <div className="flex gap-4 group">
                 <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/10 flex items-center justify-center shrink-0 group-hover:bg-[#E4C19D] group-hover:text-[#07363c] transition-all">
                    <TrendingUp size={24} />
                 </div>
                 <p className="text-sm font-medium leading-relaxed">
                   No-show oranınız <b>%12'den %5.4'e</b> gerileyerek bu ay <b>50.400 ₺</b> ek gelir sağladı.
                 </p>
              </div>
              <div className="flex gap-4 group">
                 <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/10 flex items-center justify-center shrink-0 group-hover:bg-[#E4C19D] group-hover:text-[#07363c] transition-all">
                    <CheckCircle2 size={24} />
                 </div>
                 <p className="text-sm font-medium leading-relaxed">
                   Akıllı slot bulucu sayesinde <b>22 hasta</b>, iptal olan slotlara saniyeler içinde yerleştirildi.
                 </p>
              </div>
              <div className="flex gap-4 group">
                 <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/10 flex items-center justify-center shrink-0 group-hover:bg-[#E4C19D] group-hover:text-[#07363c] transition-all font-black text-xl">
                    ₺
                 </div>
                 <p className="text-sm font-medium leading-relaxed">
                   Tahsilat hızlandırıcı ile ortalama ödeme süresi (DSO) <b>18 günden 11 güne</b> optimize edildi.
                 </p>
              </div>
           </div>

           <div className="mt-12 pt-8 border-t border-white/10 relative z-10">
              <div className="flex justify-between items-baseline mb-4">
                 <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">NET ROI ÇARPANI</span>
                 <span className="text-5xl font-black text-[#E4C19D]">14.2x</span>
              </div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Yazılım maliyeti vs. Net Kazanım oranı.</p>
           </div>
        </div>
      </div>
    </div>
  );
}
