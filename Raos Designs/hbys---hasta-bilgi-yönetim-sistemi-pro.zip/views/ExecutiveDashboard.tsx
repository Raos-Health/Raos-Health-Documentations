
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  TrendingUp, Zap, Clock, Banknote, Target, ShieldAlert, 
  ArrowRight, Users, Activity, BarChart3, Star, CheckCircle2
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

const KPICard = ({ title, value, subText, icon: Icon, color, actionLabel, onAction }: any) => (
  <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 group relative overflow-hidden card-hover">
    {/* Dekoratif Arka Plan Simgesi - ₺ olarak güncellendi */}
    <div className={`absolute -right-4 -top-4 w-32 h-32 opacity-[0.03] group-hover:scale-125 transition-transform duration-700 pointer-events-none flex items-center justify-center`}>
      <span className="text-9xl font-black">₺</span>
    </div>
    <div className="flex justify-between items-start mb-6">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-20 text-slate-700`}>
        <Icon size={28} className="text-[#07363c]" />
      </div>
      <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">Canlı</span>
    </div>
    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">{title}</p>
    <div className="flex items-baseline gap-2 mb-6">
      <span className="text-4xl font-black text-[#07363c] tracking-tighter">{value}</span>
      <span className="text-xs font-bold text-slate-500 uppercase">{subText}</span>
    </div>
    <button 
      onClick={onAction}
      className="w-full py-4 bg-slate-50 text-[#07363c] border border-slate-200 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-[#07363c] hover:text-white transition-all flex items-center justify-center gap-2 group/btn"
    >
      {actionLabel} <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
    </button>
  </div>
);

export default function ExecutiveDashboard() {
  const navigate = useNavigate();

  return (
    <div className="space-y-12 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
             <div className="px-3 py-1 bg-[#E4C19D] text-[#07363c] rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-[#E4C19D]/20">Yönetim Paneli</div>
             <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sistem Sağlık: %98</span>
          </div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Hastane Karlılık & Operasyon</h1>
          <p className="text-slate-500 font-medium">Gelir sızıntılarını durdurun ve kapasiteyi maksimize edin.</p>
        </div>
        <div className="flex items-center gap-4 bg-white p-2 rounded-[24px] border-2 border-slate-100 shadow-sm">
           <button onClick={() => alert("Haftalık analiz hazırlanıyor...")} className="px-6 py-3 bg-[#07363c] text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-[#07363c]/20 transition-all hover:scale-105">Haftalık Analiz</button>
           <button onClick={() => navigate('/ayarlar')} className="px-6 py-3 text-slate-400 font-black text-[10px] uppercase tracking-widest hover:text-[#07363c] transition-colors">Ayarlar</button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <KPICard 
          title="Kurtarılan Randevular" value="8" subText="Bugün" icon={Target} color="text-emerald-600" 
          actionLabel="No-Show Riskini Yönet" onAction={() => navigate('/raos')} 
        />
        <KPICard 
          title="Doldurulan Boşluklar" value="4" subText="Kapasite" icon={Zap} color="text-[#E4C19D]" 
          actionLabel="Bekleme Listesini Gör" onAction={() => navigate('/randevu-kontrol')} 
        />
        <KPICard 
          title="Kurtarılan Gelir" value="12.400 ₺" subText="Tahmini" icon={Banknote} color="text-indigo-600" 
          actionLabel="Sızıntı Listesini Gör" onAction={() => navigate('/sizinti')} 
        />
        <KPICard 
          title="Tahsilat Açığı" value="8.450 ₺" subText="Geciken" icon={ShieldAlert} color="text-rose-600" 
          actionLabel="Mali Takibi Başlat" onAction={() => navigate('/faturalama')} 
        />
        <KPICard 
          title="Ort. Bekleme Süresi" value="14.2" subText="Dakika" icon={Clock} color="text-slate-600" 
          actionLabel="Klinik Akışı Yönet" onAction={() => navigate('/akistakip')} 
        />
        <KPICard 
          title="Riskli Randevular" value="12" subText="Gelecek 24s" icon={Activity} color="text-amber-600" 
          actionLabel="Aksiyon Kuyruğunu Aç" onAction={() => navigate('/inbox')} 
        />
      </div>

      <div className="bg-white p-10 rounded-[48px] border-2 border-slate-100 shadow-sm">
           <div className="flex items-center justify-between mb-10">
              <h3 className="text-2xl font-black text-[#07363c] flex items-center gap-3"><BarChart3 size={24} className="text-[#E4C19D]" /> Gelir Sızıntısı Trendi (₺)</h3>
              <div className="flex gap-2">
                 <span className="flex items-center gap-1 text-[10px] font-black text-rose-600 uppercase tracking-widest bg-rose-50 px-3 py-1.5 rounded-lg border border-rose-100">Kritik: 3 Vaka</span>
              </div>
           </div>
           <div className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={[
                  { name: 'Pzt', kurtarılan: 2400 },
                  { name: 'Sal', kurtarılan: 1398 },
                  { name: 'Çar', kurtarılan: 9800 },
                  { name: 'Per', kurtarılan: 3908 },
                  { name: 'Cum', kurtarılan: 4800 },
                ]}>
                   <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                   <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#07363c' }} />
                   <YAxis hide />
                   <Tooltip 
                    formatter={(val) => `${val} ₺`}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }} 
                   />
                   <Area type="monotone" dataKey="kurtarılan" stroke="#10b981" strokeWidth={5} fillOpacity={0.1} fill="#10b981" />
                </AreaChart>
              </ResponsiveContainer>
           </div>
      </div>
    </div>
  );
}
