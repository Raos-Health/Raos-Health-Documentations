
import React, { useState } from 'react';
import { 
  Zap, Target, TrendingUp, AlertCircle, Clock, 
  MessageSquare, UserCheck, RefreshCw, BarChart3,
  Calendar, CheckCircle2, ArrowRight, UserPlus, ShieldAlert, Search
} from 'lucide-react';
import { 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, 
  Tooltip, Cell, PieChart, Pie, AreaChart, Area, CartesianGrid 
} from 'recharts';

export default function RAOSDashboard() {
  const [activeTab, setActiveTab] = useState<'overview' | 'waitlist' | 'risk'>('overview');

  const riskHeatmap = [
    { hour: '09:00', Pzt: 5, Sal: 2, Car: 8, Per: 3, Cum: 4 },
    { hour: '11:00', Pzt: 12, Sal: 15, Car: 18, Per: 14, Cum: 22 },
    { hour: '14:00', Pzt: 4, Sal: 3, Car: 2, Per: 5, Cum: 6 },
    { hour: '16:00', Pzt: 15, Sal: 24, Car: 12, Per: 18, Cum: 20 },
  ];

  const waitlistStats = [
    { name: 'Doldurulan', value: 28, fill: '#10b981' },
    { name: 'Kayıp Slot', value: 5, fill: '#ef4444' },
    { name: 'Bekleyen Teklif', value: 12, fill: '#cbd5e1' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="px-3 py-1 bg-indigo-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">RAOS v2.0</div>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Akıllı Slot Motoru Aktif</span>
          </div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight text-balance">No-Show Azaltma & Bekleme Listesi</h1>
          <p className="text-slate-500 font-medium">Otomasyonla kapasiteyi koruyun, personeli manuel aramalardan kurtarın.</p>
        </div>
        
        <div className="flex items-center gap-4 bg-white p-2 rounded-[28px] border-2 border-slate-100 shadow-sm">
           <button 
            onClick={() => setActiveTab('overview')}
            className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'overview' ? 'bg-[#07363c] text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
           >
              Performans
           </button>
           <button 
            onClick={() => setActiveTab('waitlist')}
            className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'waitlist' ? 'bg-[#07363c] text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
           >
              Waitlist
           </button>
           <button 
            onClick={() => setActiveTab('risk')}
            className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'risk' ? 'bg-[#07363c] text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
           >
              Risk Haritası
           </button>
        </div>
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-10 animate-in slide-in-from-bottom-4 duration-500">
           <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-[#07363c] p-8 rounded-[40px] text-white shadow-2xl relative overflow-hidden group card-hover">
                 <Target className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10 group-hover:scale-110 transition-transform" />
                 <p className="text-[10px] font-black text-white/50 uppercase tracking-widest mb-1">No-Show Oranı</p>
                 <p className="text-4xl font-black tracking-tighter">%5.2</p>
                 <p className="mt-4 text-emerald-400 text-xs font-bold flex items-center gap-1"><TrendingUp size={14}/> Geçen aya göre -%4 iyileşme</p>
              </div>
              <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm card-hover">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Onay Oranı (T-24)</p>
                 <p className="text-4xl font-black text-[#07363c] tracking-tighter">%92</p>
                 <p className="mt-4 text-slate-400 text-xs font-bold uppercase tracking-widest">Hedef: %95</p>
              </div>
              <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm card-hover">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Kurtarılan Slot</p>
                 <p className="text-4xl font-black text-emerald-600 tracking-tighter">28</p>
                 <p className="mt-4 text-slate-400 text-xs font-bold uppercase tracking-widest">BU HAFTA</p>
              </div>
              <div className="bg-[#E4C19D] p-8 rounded-[40px] text-[#07363c] shadow-2xl relative overflow-hidden group card-hover">
                 <Zap className="absolute -right-6 -bottom-6 w-32 h-32 opacity-20 group-hover:scale-110 transition-transform" />
                 <p className="text-[10px] font-black text-[#07363c]/50 uppercase tracking-widest mb-1">Ek Gelir (ROI)</p>
                 <p className="text-3xl font-black tracking-tighter">33.600 ₺</p>
                 <p className="mt-4 text-[#07363c] text-[10px] font-black uppercase tracking-widest">OTOMASYON KAZANIMI</p>
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              <div className="lg:col-span-2 bg-white p-10 rounded-[48px] border-2 border-slate-100 shadow-sm space-y-10">
                 <div className="flex items-center justify-between">
                    <h3 className="text-2xl font-black text-[#07363c] flex items-center gap-3">Kapasite & Onay Hunisi</h3>
                    <div className="flex gap-4">
                       <span className="flex items-center gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest"><div className="w-2 h-2 rounded-full bg-[#07363c]"></div> Planlanan</span>
                       <span className="flex items-center gap-2 text-[10px] font-black text-emerald-700 uppercase tracking-widest"><div className="w-2 h-2 rounded-full bg-[#10b981]"></div> Gelen</span>
                    </div>
                 </div>
                 <div className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                       <AreaChart data={[
                         { name: 'Pzt', p: 120, g: 110 },
                         { name: 'Sal', p: 140, g: 132 },
                         { name: 'Çar', p: 115, g: 108 },
                         { name: 'Per', p: 135, g: 128 },
                         { name: 'Cum', p: 150, g: 142 },
                       ]}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#07363c' }} />
                          <YAxis hide />
                          <Tooltip contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }} />
                          <Area type="monotone" dataKey="p" stroke="#07363c" strokeWidth={5} fillOpacity={0.05} fill="#07363c" />
                          <Area type="monotone" dataKey="g" stroke="#10b981" strokeWidth={5} fillOpacity={0.15} fill="#10b981" />
                       </AreaChart>
                    </ResponsiveContainer>
                 </div>
              </div>

              <div className="bg-white p-10 rounded-[48px] border-2 border-slate-100 shadow-sm flex flex-col items-center">
                 <h3 className="text-2xl font-black text-[#07363c] mb-10 w-full text-center">Waitlist Verimliliği</h3>
                 <div className="h-[250px] w-full relative">
                    <ResponsiveContainer width="100%" height="100%">
                       <PieChart>
                          <Pie data={waitlistStats} innerRadius={70} outerRadius={90} paddingAngle={8} dataKey="value">
                             {waitlistStats.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
                          </Pie>
                       </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                       <span className="text-3xl font-black text-[#07363c]">%84</span>
                       <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-1">Dolum Hızı</span>
                    </div>
                 </div>
                 <div className="space-y-4 w-full mt-10">
                    {waitlistStats.map(s => (
                      <div key={s.name} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border-2 border-transparent hover:border-slate-100 transition-all">
                         <div className="flex items-center gap-3">
                            <div className="w-3 h-3 rounded-full shadow-sm" style={{ backgroundColor: s.fill }}></div>
                            <span className="text-xs font-black text-slate-600 uppercase tracking-widest">{s.name}</span>
                         </div>
                         <span className="font-black text-[#07363c]">{s.value}</span>
                      </div>
                    ))}
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'waitlist' && (
        <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
           <div className="bg-white rounded-[48px] border-2 border-slate-100 overflow-hidden shadow-sm">
              <div className="p-8 border-b border-slate-100 bg-slate-50/30 flex flex-col sm:flex-row items-center justify-between gap-6">
                 <div className="relative w-full max-w-xl group">
                    <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#07363c]" size={20} />
                    <input className="w-full pl-16 pr-8 py-5 rounded-[28px] border-2 border-transparent bg-white shadow-inner outline-none font-bold text-lg focus:border-[#07363c] transition-all" placeholder="Waitlist içinde ara..." />
                 </div>
                 <button onClick={() => alert("Aday kayıt sihirbazı açıldı.")} className="flex items-center gap-2 bg-[#07363c] text-white px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-105 transition-all">
                    <UserPlus size={18} /> Aday Ekle
                 </button>
              </div>
              
              <div className="overflow-x-auto">
                 <table className="w-full text-left font-bold">
                    <thead>
                       <tr className="bg-slate-50 border-b border-slate-100">
                          <th className="px-10 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Aday / Hasta</th>
                          <th className="px-10 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Tercih Edilen Branş</th>
                          <th className="px-10 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Bekleme Süresi</th>
                          <th className="px-10 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Durum</th>
                          <th className="px-10 py-6 text-right text-[10px] font-black text-slate-500 uppercase tracking-widest">Aksiyon</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {[
                         { name: 'Selin Araz', branch: 'Dahiliye', days: 4, status: 'Aktif', dr: 'Herhangi' },
                         { name: 'Murat Yıldız', branch: 'Kardiyoloji', days: 12, status: 'Teklif Gönderildi', dr: 'Dr. Selim Akın' },
                         { name: 'Esra Bilgiç', branch: 'Genel Cerrahi', days: 2, status: 'Aktif', dr: 'Dr. Ahmet Demir' },
                       ].map((item, i) => (
                         <tr key={i} className="hover:bg-slate-50 transition-colors group">
                            <td className="px-10 py-6">
                               <p className="font-black text-[#07363c]">{item.name}</p>
                               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Müşteri Segmenti: A+</p>
                            </td>
                            <td className="px-10 py-6">
                               <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-lg text-[10px] font-black uppercase border border-indigo-200">{item.branch}</span>
                               <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-tighter">{item.dr}</p>
                            </td>
                            <td className="px-10 py-6">
                               <div className="flex items-center gap-2">
                                  <Clock size={14} className="text-[#E4C19D]" />
                                  <span className="text-sm font-black text-[#07363c]">{item.days} Gündür Bekliyor</span>
                               </div>
                            </td>
                            <td className="px-10 py-6">
                               <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase border ${item.status.includes('Teklif') ? 'bg-amber-100 text-amber-800 border-amber-200' : 'bg-emerald-100 text-emerald-800 border-emerald-200'}`}>
                                  {item.status}
                               </span>
                            </td>
                            <td className="px-10 py-6 text-right">
                               <button onClick={() => alert("Aday durumu güncellendi.")} className="p-3 bg-white border-2 border-slate-100 rounded-xl text-slate-400 hover:text-[#07363c] hover:border-[#07363c] transition-all shadow-sm">
                                  <RefreshCw size={18} />
                               </button>
                            </td>
                         </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'risk' && (
        <div className="space-y-10 animate-in slide-in-from-top-4 duration-500">
           <div className="bg-white p-10 rounded-[48px] border-2 border-slate-100 shadow-sm overflow-hidden">
              <h3 className="text-2xl font-black text-[#07363c] mb-10 flex items-center gap-3">
                 <ShieldAlert className="text-rose-600" size={28} /> No-Show Risk Haritası (DNA Analizi)
              </h3>
              
              <div className="overflow-x-auto">
                 <table className="w-full text-center">
                    <thead>
                       <tr>
                          <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest text-left">Saat Dilimi</th>
                          <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Pazartesi</th>
                          <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Salı</th>
                          <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Çarşamba</th>
                          <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Perşembe</th>
                          <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Cuma</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {riskHeatmap.map(row => (
                         <tr key={row.hour}>
                            <td className="px-6 py-8 text-sm font-black text-[#07363c] text-left">{row.hour}</td>
                            {[row.Pzt, row.Sal, row.Car, row.Per, row.Cum].map((val, i) => (
                              <td key={i} className="px-2">
                                 <div 
                                    className={`py-6 rounded-3xl font-black text-sm transition-transform hover:scale-110 cursor-help shadow-sm border-2 border-transparent ${
                                       val > 15 ? 'bg-rose-600 text-white shadow-rose-200' :
                                       val > 10 ? 'bg-amber-500 text-white' :
                                       'bg-emerald-100 text-emerald-800'
                                    }`}
                                    title={`No-show riski: %${val}`}
                                 >
                                    %{val}
                                 </div>
                              </td>
                            ))}
                         </tr>
                       ))}
                    </tbody>
                 </table>
              </div>

              <div className="mt-12 p-10 bg-slate-50 rounded-[40px] border-2 border-slate-100 flex flex-col md:flex-row items-center gap-10">
                 <div className="p-6 bg-[#E4C19D] rounded-3xl shadow-2xl"><TrendingUp size={36} className="text-[#07363c]" /></div>
                 <div className="flex-1 space-y-2">
                    <h4 className="text-2xl font-black text-[#07363c]">Stratejik Öneri</h4>
                    <p className="text-sm font-bold text-slate-600 leading-relaxed uppercase tracking-tight">
                       Analizimize göre <b className="text-rose-600">Cuma 16:00</b> randevuları en yüksek risk diliminde. Bu saatler için randevu teyitlerini <b>T-48 saat</b> öncesine çekmenizi öneririz.
                    </p>
                 </div>
                 <button onClick={() => alert("Sistem optimizasyon ayarları güncellendi.")} className="px-10 py-6 bg-[#07363c] text-white rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-105 transition-all">Sistemi Optimize Et</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}
