
import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
// LeakageEvent is now exported from types.ts
import { LeakageEvent } from '../types';
import { 
  Zap, ShieldAlert, AlertCircle, CheckCircle2, 
  Search, ArrowRight, TrendingUp, DollarSign
} from 'lucide-react';

export default function LeakageDetector() {
  /* Fix: Corrected state type to LeakageEvent[] */
  const [events, setEvents] = useState<LeakageEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeakages();
  }, []);

  async function fetchLeakages() {
    setLoading(true);
    // Simüle edilmiş sızıntı verileri
    setEvents([
      {
        id: 'L1',
        rule_code: 'MISSING_INVOICE',
        title: 'Faturasız Muayene Tespiti',
        description: 'Dün gerçekleşen muayene için fatura kesilmemiş.',
        patient: 'Ayşe Kaya',
        amount: '1.250 ₺',
        severity: 'HIGH',
        status: 'DETECTED'
      },
      {
        id: 'L2',
        rule_code: 'UNPAID_INVOICE',
        title: 'Tahsilat Açığı',
        description: 'Vadesi geçen faturada eksik bakiye mevcut.',
        patient: 'Mehmet Yılmaz',
        amount: '850 ₺',
        severity: 'MEDIUM',
        status: 'DETECTED'
      },
      {
        id: 'L3',
        rule_code: 'NOTE_WITHOUT_APPOINTMENT',
        title: 'Kayıtsız Klinik Not',
        description: 'Randevusu görünmeyen bir hasta için klinik not girişi yapılmış.',
        patient: 'Canan Can',
        amount: 'Bilinmiyor',
        severity: 'LOW',
        status: 'DETECTED'
      }
    ]);
    setLoading(false);
  }

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-[#07363c] tracking-tight">Gelir Sızıntısı Tespitçisi</h1>
          <p className="text-slate-500 font-medium">Operasyonel eksiklikleri bulur ve geliri korur.</p>
        </div>
        <button className="px-6 py-3 bg-[#07363c] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg shadow-[#07363c]/20 flex items-center gap-2">
           <Zap size={16} fill="currentColor" /> Taramayı Başlat
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-rose-600 p-8 rounded-[40px] text-white shadow-2xl shadow-rose-600/20 relative overflow-hidden">
           <ShieldAlert className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10" />
           <p className="text-rose-100 text-[10px] font-black uppercase tracking-widest mb-2">Engellenebilir Sızıntı</p>
           <p className="text-4xl font-black tracking-tighter">4.250 ₺</p>
           <div className="mt-4 flex items-center gap-2 text-rose-100 text-xs font-bold">
              <TrendingUp size={16} /> 3 Kritik Vaka
           </div>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm col-span-2 flex items-center justify-around">
           <div className="text-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Tespit Edilen</p>
              <p className="text-3xl font-black text-[#07363c]">12</p>
           </div>
           <div className="w-px h-12 bg-slate-100"></div>
           <div className="text-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Çözülen</p>
              <p className="text-3xl font-black text-emerald-600">9</p>
           </div>
           <div className="w-px h-12 bg-slate-100"></div>
           <div className="text-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Genel Sağlık Skoru</p>
              <p className="text-3xl font-black text-[#07363c]">%94</p>
           </div>
        </div>
      </div>

      <div className="space-y-6">
        <h2 className="text-xl font-black text-[#07363c] tracking-tight px-4">Aktif Sızıntı Kuyruğu</h2>
        <div className="space-y-4">
          {events.map((event) => (
            <div key={event.id} className="bg-white rounded-[32px] border border-slate-200 p-8 flex flex-col md:flex-row items-center gap-8 group hover:border-[#07363c] hover:shadow-2xl transition-all duration-300">
              <div className={`p-6 rounded-[24px] ${
                event.severity === 'HIGH' ? 'bg-rose-50 text-rose-600' : 'bg-slate-100 text-slate-400'
              }`}>
                <AlertCircle size={32} />
              </div>
              <div className="flex-1 space-y-2 text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-4">
                  <h3 className="text-xl font-black text-[#07363c]">{event.title}</h3>
                  <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black uppercase ${
                    event.severity === 'HIGH' ? 'bg-rose-600 text-white' : 'bg-slate-200 text-slate-600'
                  }`}>{event.severity}</span>
                </div>
                <p className="text-slate-500 font-medium">{event.description}</p>
                <div className="flex items-center justify-center md:justify-start gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <span>Hasta: {event.patient}</span>
                  <span>Potansiyel: {event.amount}</span>
                </div>
              </div>
              <div className="flex gap-2 w-full md:w-auto">
                 <button className="flex-1 md:flex-none px-8 py-4 bg-[#07363c] text-white font-black uppercase tracking-widest rounded-2xl shadow-xl shadow-[#07363c]/20 hover:scale-105 transition-all flex items-center justify-center gap-3 group/btn">
                    Giderme Görevi Aç <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                 </button>
                 <button className="p-4 bg-white border border-slate-200 text-slate-400 rounded-2xl hover:text-emerald-600 hover:border-emerald-200 transition-all">
                    <CheckCircle2 size={24} />
                 </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
