
import React, { useState, useEffect } from 'react';
import { 
  CreditCard, Send, Clock, Banknote, TrendingUp, 
  MessageSquare, Bell, Calendar, Zap,
  AlertCircle, Filter, Search, Share2
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function CollectionAccelerator() {
  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-[#07363c] tracking-tight">Tahsilat Hızlandırıcı</h1>
          <p className="text-slate-500 font-medium italic">Vadesi geçen alacakları (₺) otomatik takip edin.</p>
        </div>
        <div className="flex gap-3 bg-white p-2 rounded-2xl border-2 border-slate-100 shadow-sm">
           <div className="px-5 py-2 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-black uppercase border border-emerald-200">DSO: 14 GÜN</div>
           <div className="px-5 py-2 bg-indigo-100 text-indigo-800 rounded-xl text-xs font-black uppercase border border-indigo-200">BAŞARI: %92</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
         <div className="bg-[#07363c] p-8 rounded-[40px] text-white shadow-2xl relative overflow-hidden card-hover">
            <div className="absolute -right-4 -top-4 w-32 h-32 opacity-10 text-9xl font-black">₺</div>
            <p className="text-white/50 text-[10px] font-black uppercase tracking-widest mb-1">Geciken Toplam</p>
            <p className="text-4xl font-black tracking-tighter">84.200 ₺</p>
            <p className="text-[10px] font-black mt-4 flex items-center gap-1 text-emerald-400">
               <TrendingUp size={14} /> %12 İYİLEŞME
            </p>
         </div>
         <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm card-hover">
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Bekleyen Ödemeler</p>
            <p className="text-4xl font-black text-[#07363c] tracking-tighter">24 Vaka</p>
            <p className="text-[10px] font-bold mt-4 text-slate-400">Aktif takipte</p>
         </div>
         <div className="bg-white p-8 rounded-[40px] border-2 border-slate-100 shadow-sm card-hover">
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Dönüşüm Oranı</p>
            <p className="text-4xl font-black text-[#07363c] tracking-tighter">%88</p>
            <p className="text-[10px] font-black mt-4 text-emerald-600 uppercase">HEDEF ÜSTÜ</p>
         </div>
         <div className="bg-[#E4C19D] p-8 rounded-[40px] text-[#07363c] shadow-2xl card-hover">
            <p className="text-[#07363c]/60 text-[10px] font-black uppercase tracking-widest mb-1">Geri Kazanılan</p>
            <p className="text-3xl font-black tracking-tighter">12.500 ₺</p>
            <p className="text-[10px] font-black mt-4 uppercase">BU HAFTA</p>
         </div>
      </div>

      <div className="bg-white p-10 rounded-[48px] border-2 border-slate-200 shadow-sm">
         <h3 className="text-2xl font-black text-[#07363c] mb-10 flex items-center gap-3">Kritik Tahsilat Listesi</h3>
         <div className="space-y-4">
            {[
              { name: 'Mehmet Yılmaz', amount: '4.500', days: 12, status: 'Kritik' },
              { name: 'Ayşe Kaya', amount: '1.200', days: 8, status: 'Takipte' },
              { name: 'Murat Can', amount: '8.400', days: 3, status: 'Hatırlatıldı' }
            ].map((p, i) => (
              <div key={i} className="flex flex-col md:flex-row items-center justify-between p-6 bg-slate-50 rounded-[32px] border-2 border-transparent hover:border-[#E4C19D] transition-all group">
                 <div className="flex items-center gap-6">
                    <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center font-black text-indigo-600 shadow-sm">{p.name[0]}</div>
                    <div>
                       <p className="font-black text-[#07363c] text-lg">{p.name}</p>
                       <p className="text-xs font-bold text-slate-400 uppercase">{p.days} Gündür Bekliyor</p>
                    </div>
                 </div>
                 <div className="text-center md:text-right mt-4 md:mt-0">
                    <p className="text-2xl font-black text-[#07363c]">{p.amount} ₺</p>
                    <button 
                      onClick={() => alert("Güvenli ödeme linki hastaya WhatsApp üzerinden iletildi.")}
                      className="mt-2 text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:underline"
                    >
                      Ödeme Linki Gönder
                    </button>
                 </div>
              </div>
            ))}
         </div>
      </div>
    </div>
  );
}
