
import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
// Task is now exported from types.ts
import { Task, TaskType, AppointmentStatus } from '../types';
// Added Timer to imports
import { 
  Phone, CheckCircle, XCircle, Clock, AlertTriangle, 
  MessageSquare, User, Calendar, ShieldAlert, ChevronRight, PlayCircle, Zap, FileText,
  Inbox, DollarSign, Send, MoveHorizontal, BellRing, Timer
} from 'lucide-react';

export default function StaffInbox() {
  /* Fix: Corrected state type to Task[] */
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState<any | null>(null);

  useEffect(() => {
    fetchTasks();
  }, []);

  async function fetchTasks() {
    setLoading(true);
    /* Fix: Aligned demo data with Task interface */
    const mockTasks: Task[] = [
      {
        id: 't1',
        type: TaskType.CONFIRM_CALL,
        priority: 'Yüksek',
        status: 'Açık',
        due_at: new Date(Date.now() + 30 * 60000).toISOString(),
        created_at: new Date().toISOString(),
        appointment_id: 'apt1',
        appointment: {
          appointment_date: new Date(Date.now() + 86400000).toISOString(),
          patient: { first_name: 'Mehmet', last_name: 'Yılmaz', phone: '0532 000 00 01', tc_no: '12345678901' },
          doctor: { full_name: 'Dr. Canan Erçetin' },
          risk_score: 75,
          risk_reasons: ['Geçmişte 2 No-Show', 'T-24 Onayı Yok']
        } as any
      },
      {
        id: 't4',
        type: TaskType.DELAY_MANAGEMENT,
        priority: 'Acil',
        status: 'Açık',
        due_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
        appointment_id: 'apt4',
        appointment: {
          appointment_date: new Date().toISOString(),
          patient: { first_name: 'Selin', last_name: 'Araz', phone: '0505 555 55 55', tc_no: '55544433322' },
          doctor: { full_name: 'Dr. Ahmet Demir' },
          risk_score: 85,
          risk_reasons: ['25 dakikadır bekliyor', 'Doktor muayene süresini aştı']
        } as any
      },
      {
        id: 't2',
        type: TaskType.PAYMENT_FOLLOWUP,
        priority: 'Acil',
        status: 'Açık',
        due_at: new Date(Date.now() - 15 * 60000).toISOString(),
        created_at: new Date().toISOString(),
        appointment_id: 'apt2',
        appointment: {
          appointment_date: new Date(Date.now() - 864000000).toISOString(),
          patient: { first_name: 'Ayşe', last_name: 'Kaya', phone: '0544 111 22 33', tc_no: '98765432109' },
          doctor: { full_name: 'Finans Departmanı' },
          risk_score: 95,
          risk_reasons: ['12 gündür ödenmeyen fatura', 'Link tıklandı ama ödenmedi']
        } as any
      },
      {
        id: 't3',
        type: TaskType.LEAKAGE_FIX,
        priority: 'Normal',
        status: 'Açık',
        due_at: new Date(Date.now() + 120 * 60000).toISOString(),
        created_at: new Date().toISOString(),
        appointment_id: 'apt3',
        appointment: {
          appointment_date: new Date(Date.now() - 3600000).toISOString(),
          patient: { first_name: 'Can', last_name: 'Demir', phone: '0533 444 55 66', tc_no: '11122233344' },
          doctor: { full_name: 'Dr. Selim Akın' },
          risk_score: 40,
          risk_reasons: ['Muayene bitti ama fatura kesilmedi']
        } as any
      }
    ];
    setTasks(mockTasks);
    setLoading(false);
  }

  const handleOutcome = async (id: string, outcome: string) => {
    alert(`${outcome} işlemi kaydedildi. Görev kapatılıyor.`);
    setTasks(tasks.filter(t => t.id !== id));
    setSelectedTask(null);
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-120px)] gap-8 animate-in fade-in duration-500">
      <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-black text-[#07363c] tracking-tight">Görev Kutusu</h1>
            <p className="text-slate-500 font-medium">Operasyonu ayakta tutan günlük görevleriniz.</p>
          </div>
          <div className="flex gap-2">
             <div className="bg-white px-4 py-2 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{tasks.length} Bekleyen</span>
             </div>
          </div>
        </div>

        {tasks.map((task) => (
          <div 
            key={task.id} 
            onClick={() => setSelectedTask(task)}
            className={`bg-white p-6 rounded-[32px] border-2 transition-all cursor-pointer group flex items-center gap-6 ${
              selectedTask?.id === task.id ? 'border-[#07363c] shadow-2xl' : 'border-slate-100 hover:border-slate-300 shadow-sm'
            }`}
          >
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 ${
              task.priority === 'Acil' ? 'bg-rose-50 text-rose-600' : 
              task.priority === 'Yüksek' ? 'bg-amber-50 text-amber-600' : 'bg-[#07363c]/5 text-[#07363c]'
            }`}>
              {task.type === TaskType.CONFIRM_CALL ? <Phone size={28} /> : 
               task.type === TaskType.PAYMENT_FOLLOWUP ? <DollarSign size={28} /> : 
               task.type === TaskType.DELAY_MANAGEMENT ? <Timer size={28} /> : 
               task.type === TaskType.LEAKAGE_FIX ? <Zap size={28} /> : <FileText size={28} />}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{task.type}</span>
                <span className={`px-2 py-0.5 rounded-lg text-[8px] font-black uppercase ${
                  task.priority === 'Acil' ? 'bg-rose-600 text-white' : 'bg-slate-200 text-slate-600'
                }`}>{task.priority}</span>
              </div>
              <h3 className="text-xl font-black text-[#07363c] leading-none mb-2">
                {task.appointment?.patient?.first_name} {task.appointment?.patient?.last_name}
              </h3>
              <div className="flex items-center gap-4 text-xs font-bold text-slate-400">
                <div className="flex items-center gap-1"><Clock size={14} className="text-[#E4C19D]" /> {new Date(task.due_at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}</div>
                <div className="flex items-center gap-1"><User size={14} className="text-[#E4C19D]" /> {task.appointment?.doctor?.full_name}</div>
              </div>
            </div>

            <ChevronRight className="text-slate-200 group-hover:text-[#07363c] transition-colors" />
          </div>
        ))}
      </div>

      <div className="w-full lg:w-[450px] space-y-6">
        {selectedTask ? (
          <div className="bg-white rounded-[40px] border border-slate-200 shadow-2xl overflow-hidden sticky top-0 animate-in slide-in-from-right-8 duration-300">
             <div className={`p-8 ${selectedTask.priority === 'Acil' ? 'bg-rose-600' : 'bg-[#07363c]'} text-white`}>
                <div className="flex justify-between items-start mb-6">
                   <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md">
                     {selectedTask.type === TaskType.DELAY_MANAGEMENT ? <Clock size={24} className="text-[#E4C19D]" /> : <Zap size={24} className="text-[#E4C19D]" />}
                   </div>
                   <div className="text-right">
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Öncelik</p>
                      <p className="text-xl font-black">{selectedTask.priority}</p>
                   </div>
                </div>
                <h2 className="text-3xl font-black tracking-tight mb-2">{selectedTask.appointment.patient.first_name} {selectedTask.appointment.patient.last_name}</h2>
                <p className="text-[#E4C19D] font-bold text-lg">{selectedTask.appointment.patient.phone}</p>
             </div>

             <div className="p-8 space-y-8">
                <div className="space-y-4">
                   <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b pb-2">Görev Özeti & Neden</h4>
                   <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-sm text-slate-600 leading-relaxed">
                      {selectedTask.appointment.risk_reasons.map((r: string) => <p key={r} className="font-bold">• {r}</p>)}
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                   {selectedTask.type === TaskType.DELAY_MANAGEMENT ? (
                     <>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Özür SMSi Gönderildi')} className="col-span-2 p-5 bg-[#07363c] text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                           <MessageSquare size={20} /> Özür SMS'i Gönder
                        </button>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Doktor Değiştirildi')} className="p-5 bg-indigo-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-indigo-600/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                           <MoveHorizontal size={20} /> Doktor Değiştir
                        </button>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Randevu Ertelendi')} className="p-5 bg-slate-100 text-slate-600 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-slate-200 transition-all flex items-center justify-center gap-3">
                           <Calendar size={20} /> Ertele (VIP)
                        </button>
                     </>
                   ) : selectedTask.type === TaskType.PAYMENT_FOLLOWUP ? (
                     <>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Link Gönderildi')} className="col-span-2 p-5 bg-[#07363c] text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-[#07363c]/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                           <Send size={20} /> Ödeme Linki Tekrarla
                        </button>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Söz Alındı')} className="p-5 bg-emerald-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-emerald-600/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                           <CheckCircle size={20} /> Ödeme Sözü
                        </button>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Ulaşılamadı')} className="p-5 bg-slate-100 text-slate-600 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-slate-200 transition-all">
                           Ulaşılamadı
                        </button>
                     </>
                   ) : (
                     <>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Tamamlandı')} className="col-span-2 p-5 bg-emerald-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-emerald-600/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                           <CheckCircle size={20} /> Görevi Çözümle
                        </button>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Erteledi')} className="p-5 bg-amber-500 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-amber-500/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3">
                           <Clock size={20} /> Ertele
                        </button>
                        <button onClick={() => handleOutcome(selectedTask.id, 'Ulaşılamadı')} className="p-5 bg-slate-100 text-slate-600 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-slate-200 transition-all">
                           Ulaşılamadı
                        </button>
                     </>
                   )}
                </div>
             </div>
          </div>
        ) : (
          <div className="h-full bg-slate-100 rounded-[40px] border-4 border-dashed border-slate-200 flex flex-col items-center justify-center p-12 text-center text-slate-400 space-y-4">
             <Inbox size={64} className="opacity-20" />
             <h3 className="text-xl font-black text-slate-500">Görev Seçimi Bekleniyor</h3>
             <p className="text-sm font-medium">Listeden bir görevi seçerek aksiyon alın.</p>
          </div>
        )}
      </div>
    </div>
  );
}
