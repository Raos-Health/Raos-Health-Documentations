
import React, { useState, useEffect } from 'react';
import { supabase, logAuditEvent } from '../supabase';
import { Appointment, AppointmentStatus } from '../types';
import { 
  Activity, Clock, User, CheckCircle2, AlertCircle, 
  Timer, Users, ArrowRight, Play, Check, Send, MoveHorizontal, RefreshCcw, BellRing
} from 'lucide-react';

export default function ClinicalFlow() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTodayFlow();
    const interval = setInterval(fetchTodayFlow, 30000); // 30 saniyede bir güncelle
    return () => clearInterval(interval);
  }, []);

  async function fetchTodayFlow() {
    setLoading(true);
    // Mocking arrival times if they don't exist for demo
    const { data } = await supabase
      .from('appointments')
      .select('*, patient:patients(*), doctor:profiles(*), department:departments(*)')
      .order('appointment_date', { ascending: true });
    
    if (data) {
       const enriched = data.map(apt => ({
          ...apt,
          // Demo için: WAITING ise ve arrived_at yoksa geçmişe dönük ekle
          arrived_at: apt.status === AppointmentStatus.WAITING && !apt.arrived_at 
            ? new Date(Date.now() - (Math.random() * 25 * 60000)).toISOString() 
            : apt.arrived_at,
          started_at: apt.status === AppointmentStatus.IN_ROOM && !apt.started_at
            ? new Date(Date.now() - (Math.random() * 15 * 60000)).toISOString()
            : apt.started_at
       }));
       setAppointments(enriched);
    }
    setLoading(false);
  }

  const updateStatus = async (id: string, newStatus: AppointmentStatus) => {
    const updates: any = { status: newStatus };
    const now = new Date().toISOString();
    
    if (newStatus === AppointmentStatus.WAITING) updates.arrived_at = now;
    if (newStatus === AppointmentStatus.IN_ROOM) updates.started_at = now;
    if (newStatus === AppointmentStatus.COMPLETED) updates.completed_at = now;

    const { error } = await supabase.from('appointments').update(updates).eq('id', id);
    if (!error) {
      logAuditEvent('UPDATE_FLOW', 'appointment', id, updates);
      fetchTodayFlow();
    }
  };

  const getWaitTime = (arrivedAt?: string) => {
    if (!arrivedAt) return 0;
    const diff = Date.now() - new Date(arrivedAt).getTime();
    return Math.floor(diff / 60000);
  };

  const getDuration = (startedAt?: string) => {
    if (!startedAt) return 0;
    const diff = Date.now() - new Date(startedAt).getTime();
    return Math.floor(diff / 60000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-[#07363c] tracking-tight">Klinik Akış Ölçer</h1>
          <p className="text-slate-500 font-medium">Bekleme süreleri ve proaktif gecikme yönetimi.</p>
        </div>
        <div className="flex gap-4">
           <div className="px-6 py-3 bg-white border border-slate-200 rounded-2xl shadow-sm flex items-center gap-4">
              <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg"><CheckCircle2 size={18}/></div>
              <div className="flex flex-col">
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Ort. Bekleme</span>
                 <span className="text-sm font-black text-[#07363c]">12.4 Dakika</span>
              </div>
           </div>
           <button onClick={fetchTodayFlow} className="p-4 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-[#07363c] transition-all">
              <RefreshCcw size={20} />
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
         
         {/* WAITING COLUMN */}
         <div className="space-y-6">
            <div className="flex items-center justify-between px-4">
               <h2 className="text-xs font-black text-[#07363c] uppercase tracking-widest flex items-center gap-2">
                  <Clock size={16} /> Bekleyen Hastalar
               </h2>
               <span className="bg-[#E4C19D] text-[#07363c] px-3 py-1 rounded-xl text-[10px] font-black">
                 {appointments.filter(a => a.status === AppointmentStatus.WAITING).length} Kişi
               </span>
            </div>
            <div className="space-y-4 bg-slate-50/50 p-6 rounded-[40px] border border-slate-100 min-h-[600px]">
               {appointments.filter(a => a.status === AppointmentStatus.WAITING).map(apt => {
                 const waitTime = getWaitTime(apt.arrived_at);
                 const isDelayed = waitTime > 15;
                 
                 return (
                   <div key={apt.id} className={`bg-white p-6 rounded-[32px] border-2 shadow-sm space-y-4 transition-all hover:shadow-xl ${isDelayed ? 'border-rose-200' : 'border-slate-100'}`}>
                      <div className="flex justify-between items-start">
                         <div>
                            <h4 className="text-lg font-black text-[#07363c]">{apt.patient?.first_name} {apt.patient?.last_name}</h4>
                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">DR. {apt.doctor?.full_name}</p>
                         </div>
                         <div className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase ${isDelayed ? 'bg-rose-600 text-white animate-pulse' : 'bg-slate-100 text-slate-500'}`}>
                            {waitTime} DK
                         </div>
                      </div>

                      {isDelayed && (
                        <div className="bg-rose-50 p-4 rounded-2xl border border-rose-100 flex flex-col gap-3 animate-in slide-in-from-top-2">
                           <div className="flex items-center gap-2 text-rose-600 text-[10px] font-black uppercase">
                              <AlertCircle size={14} /> Gecikme Uyarısı
                           </div>
                           <div className="flex gap-2">
                              <button className="flex-1 py-2 bg-white border border-rose-200 rounded-xl text-[9px] font-black uppercase text-rose-600 hover:bg-rose-600 hover:text-white transition-all">Sms Gönder</button>
                              <button className="flex-1 py-2 bg-white border border-rose-200 rounded-xl text-[9px] font-black uppercase text-rose-600 hover:bg-rose-600 hover:text-white transition-all">Kaydır</button>
                           </div>
                        </div>
                      )}

                      <button 
                        onClick={() => updateStatus(apt.id, AppointmentStatus.IN_ROOM)}
                        className="w-full py-4 bg-[#07363c] text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-900 transition-all flex items-center justify-center gap-3 group"
                      >
                         Muayeneye Al <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                      </button>
                   </div>
                 );
               })}
            </div>
         </div>

         {/* IN ROOM COLUMN */}
         <div className="space-y-6">
            <div className="flex items-center justify-between px-4">
               <h2 className="text-xs font-black text-[#07363c] uppercase tracking-widest flex items-center gap-2 text-indigo-600">
                  <Activity size={16} /> Muayenedekiler
               </h2>
               <span className="bg-indigo-600 text-white px-3 py-1 rounded-xl text-[10px] font-black">
                 {appointments.filter(a => a.status === AppointmentStatus.IN_ROOM).length} Aktif
               </span>
            </div>
            <div className="space-y-4 bg-indigo-50/20 p-6 rounded-[40px] border border-indigo-100/30 min-h-[600px]">
               {appointments.filter(a => a.status === AppointmentStatus.IN_ROOM).map(apt => {
                 const duration = getDuration(apt.started_at);
                 const isOverTime = duration > (apt.duration_minutes || 20);

                 return (
                   <div key={apt.id} className="bg-white p-6 rounded-[32px] border-2 border-indigo-200 shadow-xl space-y-4 relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-3"><Timer size={20} className={`text-indigo-400 ${isOverTime ? 'text-rose-500 animate-pulse' : ''}`} /></div>
                      <div>
                         <h4 className="text-lg font-black text-[#07363c]">{apt.patient?.first_name} {apt.patient?.last_name}</h4>
                         <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">DR. {apt.doctor?.full_name}</p>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase">
                           <span>İlerleme</span>
                           <span className={isOverTime ? 'text-rose-600' : 'text-indigo-600'}>{duration} / {apt.duration_minutes} DK</span>
                        </div>
                        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                           <div 
                              className={`h-full transition-all duration-1000 ${isOverTime ? 'bg-rose-500' : 'bg-indigo-600'}`} 
                              style={{ width: `${Math.min(100, (duration / (apt.duration_minutes || 20)) * 100)}%` }}
                           ></div>
                        </div>
                      </div>

                      <button 
                        onClick={() => updateStatus(apt.id, AppointmentStatus.COMPLETED)}
                        className="w-full py-4 bg-emerald-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all flex items-center justify-center gap-3"
                      >
                         <Check size={18} strokeWidth={4} /> Muayeneyi Bitir
                      </button>
                   </div>
                 );
               })}
            </div>
         </div>

         {/* BOTTLENECK & STATS COLUMN */}
         <div className="space-y-6">
            <h2 className="text-xs font-black text-[#07363c] uppercase tracking-widest px-4">Süreç Analitiği</h2>
            <div className="bg-white p-8 rounded-[48px] border border-slate-200 shadow-sm space-y-10">
               <div className="space-y-4">
                  <div className="flex items-center gap-3 text-rose-600">
                     <AlertCircle size={20} />
                     <h4 className="text-xs font-black uppercase tracking-widest">Kritik Branş</h4>
                  </div>
                  <div className="p-5 bg-rose-50 rounded-3xl border border-rose-100">
                     <p className="text-lg font-black text-[#07363c]">Kardiyoloji</p>
                     <p className="text-[10px] font-bold text-rose-600 uppercase mt-1">Gecikme: 24.5 Dakika</p>
                     <p className="text-[10px] text-slate-500 mt-3 font-medium">Öneri: 14:00 randevusunu Dr. Murat'a kaydırın.</p>
                  </div>
               </div>

               <div className="space-y-4">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b pb-2">Canlı Verimlilik</h4>
                  <div className="space-y-4">
                     <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-600 uppercase">Giriş Hızı</span>
                        <span className="text-sm font-black text-emerald-600">Yüksek</span>
                     </div>
                     <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-600 uppercase">SLA Uyumu</span>
                        <span className="text-sm font-black text-[#07363c]">%92</span>
                     </div>
                     <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-600 uppercase">Hasta Memnuniyeti</span>
                        <span className="text-sm font-black text-[#E4C19D]">4.8 / 5.0</span>
                     </div>
                  </div>
               </div>

               <button className="w-full py-5 border-2 border-dashed border-slate-200 rounded-[32px] text-slate-400 font-black uppercase text-[10px] tracking-widest hover:border-[#07363c] hover:text-[#07363c] transition-all flex items-center justify-center gap-3">
                  <BellRing size={16} /> Tüm Yönetimi Uyar
               </button>
            </div>
         </div>
      </div>
    </div>
  );
}
